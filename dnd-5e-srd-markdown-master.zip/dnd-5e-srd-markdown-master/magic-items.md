# Magic Items

Magic items are gleaned from the hoards of felled monsters or discovered in long-lost vaults. Such items grant capabilities a character could rarely have otherwise, or they complement their owner's capabilities in wondrous ways.

## Magic Item Categories

Every magic item belongs to a category. The Magic Item Categories table lists the nine categories and provides examples. Rules for the categories appear after the table.

**Magic Item Categories**

<table>
  <thead>
    <tr>
      <th>Category</th>
      <th>Examples</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Armor</td>
      <td>+1 Leather Armor, +1 Shield</td>
    </tr>
    <tr>
      <td>Potions</td>
      <td>Potion of Healing</td>
    </tr>
    <tr>
      <td>Rings</td>
      <td>Ring of Invisibility</td>
    </tr>
    <tr>
      <td>Rods</td>
      <td>Immovable Rod</td>
    </tr>
    <tr>
      <td>Scrolls</td>
      <td>Spell Scroll</td>
    </tr>
    <tr>
      <td>Staffs</td>
      <td>Staff of Striking</td>
    </tr>
    <tr>
      <td>Wands</td>
      <td>Wand of Fireballs</td>
    </tr>
    <tr>
      <td>Weapons</td>
      <td>+1 Ammunition, +1 Longsword</td>
    </tr>
    <tr>
      <td>Wondrous Items</td>
      <td>Bag of Holding, Boots of Elvenkind</td>
    </tr>
  </tbody>
</table>

### Armor

An item in the Armor category is typically a magical version of armor from "Equipment." Unless an armor's description notes otherwise, the armor must be worn for its magic to function.

Some suits of magic armor specify the type of armor they are, such as Chain Mail or Plate Armor. If no type is specified, choose the type or determine it randomly.

### Potions

An item in the Potion category might be a magical brew that must be imbibed or an oil that must be applied to a creature or an object. A typical potion consists of 1 ounce of liquid in a vial.

_Using a Potion._ Potions are consumable items. Drinking a potion or administering it to another creature requires a Bonus Action. Applying an oil might take longer as specified in its description. Once used, a potion takes effect immediately, and it is used up.

_Mixing Potions._ A character might drink one potion while still under the effects of another or pour several potions into a single container. The strange ingredients used in creating potions can result in unpredictable interactions.

When a character mixes two potions together, roll on the Potion Miscibility table. If more than two are combined, roll again for each subsequent potion, combining the results. Unless the effects are immediately obvious, reveal them only when they become evident.

**Potion Miscibility**

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01</td>
      <td>Both potions lose their effects, and the mixture creates a magical explosion in a 5-foot-radius Sphere centered on itself. Each creature in that area takes 4d10 Force damage.</td>
    </tr>
    <tr>
      <td>02–08</td>
      <td>Both potions lose their effects, and the mixture becomes an ingested poison of your choice (see Poison in Gameplay Toolbox).</td>
    </tr>
    <tr>
      <td>09–15</td>
      <td>Both potions lose their effects.</td>
    </tr>
    <tr>
      <td>16–25</td>
      <td>One potion loses its effect.</td>
    </tr>
    <tr>
      <td>26–35</td>
      <td>Both potions work, but with their numerical effects and durations halved. If a potion has no numerical effect and no duration, it instead loses its effect.</td>
    </tr>
    <tr>
      <td>36–90</td>
      <td>Both potions work normally.</td>
    </tr>
    <tr>
      <td>91–99</td>
      <td>Both potions work, but the numerical effects and duration of one potion are doubled. If neither potion has anything to double in this way, they work normally.</td>
    </tr>
    <tr>
      <td>00</td>
      <td>Only one potion works, but its effects are permanent. Choose the simplest effect to make permanent or the one that seems the most fun. For example, a Potion of Healing might increase the drinker's Hit Point maximum by 2d4 + 2, or a Potion of Invisibility might give the drinker the Invisible condition indefinitely. At your discretion, a Dispel Magic spell or similar magic might end this lasting effect.</td>
    </tr>
  </tbody>
</table>

### Rings

For its magic to function, an item in the Ring category must be worn on a finger or a similar digit unless its description notes otherwise.

### Rods

An item in the Rod category is a scepter usually made of metal, wood, or bone. A typical rod weighs 2 to 5 pounds.

Unless its description notes otherwise, a rod can be used as an Arcane Focus.

### Scrolls

An item in the Scroll category is a roll of paper or parchment, sometimes attached to wooden rods and typically kept safe in a tube of ivory, jade, leather, metal, or wood. The most prevalent scroll is the _Spell Scroll_, a spell stored in written form.

_Using a Scroll_. Scrolls are consumable items. Unleashing the magic in a scroll requires the user to read the scroll. When its magic has been invoked, the scroll can't be used again. Its words fade, or it crumbles into dust.

Any creature that can understand a written language can read a scroll and attempt to activate it unless its description notes otherwise.

### Staffs

Items in the Staff category vary widely in appearance: some are of nearly equal diameter throughout and smooth, others are gnarled and twisted, some are made of wood, and others are composed of polished metal or crystal. A staff weighs between 2 and 7 pounds and serves well as a walking stick or cane.

Unless its description notes otherwise, a staff can be used as a nonmagical Quarterstaff and an Arcane Focus.

### Wands

An item in the Wand category is typically 12 to 15 inches long and crafted of metal, bone, or wood. It is tipped with metal, crystal, stone, or some other material.

Unless its description notes otherwise, a wand can be used as an Arcane Focus.

### Weapons

A magic weapon is typically a magical version of a weapon from "Equipment." Some magic weapons specify the type of weapon they are in their descriptions, such as a Longsword or Longbow. If no weapon type is specified, you may choose the type or determine it randomly.

_Ammunition_. If a magic weapon has the Ammunition property, ammunition fired from it is considered magical for the purpose of any rule that cares whether a weapon is magical or not.

### Wondrous Items

Wondrous Items include wearable items such as boots, belts, capes, amulets, brooches, and circlets. Bags, carpets, figurines, horns, musical instruments, and more also fall into this category.

## Magic Item Rules

Rules for identifying, attuning to, and using magic items appear in "Equipment." Additional rules are presented below.

_Attunement Prerequisites_. If a magic item has a class prerequisite, a creature must be a member of that class to attune to the item. If a creature must be a spellcaster to attune to an item, the creature qualifies if it can cast at least one spell using its traits or features, not by using a magic item or the like.

_Items Made for Specific Creatures_. Magic items that are meant to be worn tend to magically adjust themselves to the wearer. However, you can decide that a magic item doesn't adjust its size to fit any wearer. For example, a particular armorer might make items usable only by folk who are sized and shaped like dwarves.

_Unusual Anatomy_. Use your discretion to decide whether a creature can wear an item not made for its anatomy. A ring placed on a tentacle might work, but a yuan-ti with a snakelike tail instead of legs can't wear magic boots.

_Paired Items_. You can allow exceptions to the rule that paired items must both be worn. For example, a character with only one arm might be able to use a single _Glove of Missile Snaring_ so long as the matching glove is on their person.

## Magic Item Rarity

Every magic item has a rarity, which provides a rough measure of an item's power relative to other magic items. The rarities are shown in the Magic Item Rarities and Values table.

Common magic items, such as a _Potion of Healing_, are the most plentiful. Artifacts, such as the _Dragon Orb_, are priceless, unique, and difficult to acquire.

### Magic Item Values by Rarity

Common magic items can often be bought in a town or city. Uncommon and Rare magic items are usually found only in cities, and rarer magic items might be sold only in wondrous locations, such as a city on another plane of existence. If you allow characters to buy and sell magic items in your campaign, rarity can help you set prices for those items. Gold Piece values are provided in the Magic Item Rarities and Values table, though a seller might ask for a service rather than coin as payment.

If a magic item incorporates an item that has a purchase cost in "Equipment" (such as a weapon or a suit of armor), add that item's cost to the magic item's value. For example, _+1 Armor_ (Plate Armor)
has a value of 5,500 GP, which is the sum of a Rare magic item's value (4,000 GP) and the cost of Plate Armor (1,500 GP).

**Magic Item Rarities and Values**

<table>
  <thead>
    <tr>
      <th>Rarity</th>
      <th>Value*</th>
      <th>Rarity</th>
      <th>Value*</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Common</td>
      <td>100 GP</td>
      <td>Very Rare</td>
      <td>40,000 GP</td>
    </tr>
    <tr>
      <td>Uncommon</td>
      <td>400 GP</td>
      <td>Legendary</td>
      <td>200,000 GP</td>
    </tr>
    <tr>
      <td>Rare</td>
      <td>4,000 GP</td>
      <td>Artifact</td>
      <td>Priceless</td>
    </tr>
  </tbody>
</table>

\*Halve the value for a consumable item other than a _Spell Scroll_. The value of a _Spell Scroll_ is double what it costs to scribe the scroll (as specified in the "Scribing Spell Scrolls" section of "Equipment").

## Activating a Magic Item

It usually takes a Magic action to activate a magic item. The item's user might also need to do something special. The description of each item category or individual item details how an item is activated. Certain items use the following rules for their activation.

### Command Word

A command word is a word or short phrase that must be spoken or signed for an item to work. Spoken command words must be audible and fail to work in areas where all sound is suppressed, as in the area of the _Silence_ spell.

### Consumable Items

Some items are consumed—used up, in other words—when they are activated. A _Potion of Healing_ must be swallowed, for example, while the writing vanishes from a scroll when it is read. Once used, a consumable item loses its magic.

#### Spells Cast from Items

Some magic items allow the user to cast a spell from the item. The spell is cast at the lowest possible spell and caster level, doesn't expend any of the user's spell slots, and requires no components unless the item's description notes otherwise. The spell uses its normal casting time, range, and duration, and the user of the item must concentrate if the spell requires Concentration. Many items, such as Potions, bypass the casting of a spell and confer the spell's effects with its usual duration. Certain items make exceptions to these rules, changing the casting time, duration, or other parts of a spell.

A magic item may require the user to use their own spellcasting ability when casting a spell from the item. If the user has more than one spellcasting ability, the user chooses which one to use with the item. If the user doesn't have a spellcasting ability,

their spellcasting ability modifier is +0 for the item, and the user's Proficiency Bonus applies.

#### Charges

Some magic items have charges that must be expended to activate their properties. The number of charges an item has remaining is revealed when the _Identify_ spell is cast on it. A creature attuned to an item knows how many charges the item has and how many it regains.

## "The Next Dawn"

Magic items often have charges or properties that recharge at the next dawn or some other specified time. If such an item is on a world or plane of existence where the specified event doesn't occur, the GM determines when the item recharges.

## Cursed Items

A magic item's description specifies whether it bears a curse. Most methods of identifying items, including the _Identify_ spell, fail to reveal such a curse.

Attunement to a cursed item can't be ended voluntarily unless the curse is broken first, such as with a _Remove Curse_ spell.

## Magic Item Resilience

A magic item is at least as durable as a nonmagical item of its kind. Most magic items, other than Potions and Scrolls, have Resistance to all damage.

An Artifact can be destroyed only in some special way. Otherwise, it is impervious to damage. Learning how to destroy an Artifact usually requires research or the completion of a quest.

## Crafting Magic Items

"Equipment" contains rules on brewing _Potions of Healing_ and scribing _Spell Scrolls_. To create other magic items, follow the rules below. In these rules, "you" refers to the character crafting the magic item.

### Arcana Proficiency

To craft a magic item, you and any assistants must have proficiency in the Arcana skill.

### Tools

The Magic Item Tools table lists which tool is required to make a magic item of each category. You must use the required tool to make an item and have proficiency with that tool. Any assistants must also have proficiency with it. For more information on the tools, see "Equipment."

**Magic Item Tools**

<table>
  <thead>
    <tr>
      <th>Item Category</th>
      <th>Required Tool</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Armor</td>
      <td>Leatherworker's Tools, Smith's Tools, or Weaver's Tools depending on the kind of armor as noted in the tools' descriptions</td>
    </tr>
    <tr>
      <td>Potion</td>
      <td>Alchemist's Supplies or Herbalism Kit</td>
    </tr>
    <tr>
      <td>Ring</td>
      <td>Jeweler's Tools</td>
    </tr>
    <tr>
      <td>Rod</td>
      <td>Woodcarver's Tools</td>
    </tr>
    <tr>
      <td>Scroll</td>
      <td>Calligrapher's Supplies</td>
    </tr>
    <tr>
      <td>Staff</td>
      <td>Woodcarver's Tools</td>
    </tr>
    <tr>
      <td>Wand</td>
      <td>Woodcarver's Tools</td>
    </tr>
    <tr>
      <td>Weapon</td>
      <td>Leatherworker's Tools, Smith's Tools, or Woodcarver's Tools depending on the kind of weapon as noted in the tools' descriptions</td>
    </tr>
    <tr>
      <td>Wondrous Item</td>
      <td>Tinker's Tools or the tool required to make the nonmagical item on which the magic item is based</td>
    </tr>
  </tbody>
</table>

#### Spells

If a magic item allows its user to cast any spells from it, you must have all those spells prepared every day you spend crafting the item.

## Time and Cost

Crafting a magic item takes an amount of time and money based on the item's rarity as shown in the Magic Item Crafting Time and Cost table.

_Work per Day._ For each day of crafting, you must work for 8 hours. If an item requires multiple days, those days needn't be consecutive.

_Assistants._ Characters can combine their efforts to shorten the crafting time. Divide the time needed to create an item by the number of characters working on it. Normally, only one other character can assist you, but the GM might allow more assistants.

_Raw Materials._ The cost in the table represents the raw materials needed to make a magic item. The GM determines whether appropriate raw materials are available. In a city, there is a 75 percent chance that the materials are available, and in any other settlement, that chance is 25 percent. If materials aren't available, you must wait at least 7 days before checking on the availability again.

If a magic item incorporates an item that has a purchase cost (such as a weapon or a suit of armor), you must also pay that entire cost or craft that item using the rules in "Equipment." For example, to make _+1 Armor_ (Plate Armor), you must pay 3,500 GP or pay 2,000 GP and craft the armor.

**Magic Item Crafting Time and Cost**

<table>
  <thead>
    <tr>
      <th>Item Rarity</th>
      <th>Time*</th>
      <th>Cost*</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Common</td>
      <td>5 days</td>
      <td>50 GP</td>
    </tr>
    <tr>
      <td>Uncommon</td>
      <td>10 days</td>
      <td>200 GP</td>
    </tr>
    <tr>
      <td>Rare</td>
      <td>50 days</td>
      <td>2,000 GP</td>
    </tr>
    <tr>
      <td>Very Rare</td>
      <td>125 days</td>
      <td>20,000 GP</td>
    </tr>
    <tr>
      <td>Legendary</td>
      <td>250 days</td>
      <td>100,000 GP</td>
    </tr>
  </tbody>
</table>

\*The time and cost are halved for a consumable item other than a _Spell Scroll_, whose crafting time and cost are given in "Equipment."

## Sentient Magic Items

Some magic items have sentience and personality. Such an item might be possessed, haunted by the spirit of a previous owner, or self-aware thanks to the magic used to create it. A sentient item might be a cherished ally to its wielder or a continual thorn in the side.

Most sentient items are weapons, but other kinds of items can manifest sentience. Single-use items such as potions and scrolls are never sentient.

The GM controls sentient magic items and their activated properties. A bearer who maintains a good relationship with the item can access those properties. If the relationship is strained, a conflict can ensue (see "Conflict" below).

## Sentient Magic Item Traits

When you make a sentient magic item, you create the item's persona much as you would create an NPC, with these exceptions.

### Abilities

A sentient magic item has Intelligence, Wisdom, and Charisma scores. Choose the item's abilities, or determine them randomly as follows: roll 4d6 for each one, dropping the lowest roll and totaling the rest.

### Alignment

A sentient magic item has an alignment. Its creator or nature might suggest an alignment. Otherwise, pick an alignment or roll on the Sentient Item's Alignment table.

### Communication

A sentient item communicates by sharing its emotions, broadcasting its thoughts telepathically, or speaking aloud. You can choose how it communicates or roll on the Sentient Item's Communication table.

### Senses

A sentient item can perceive its surroundings out to a limited range. You can choose its senses or roll on the Sentient Item's Senses table.

## Special Purpose

You can give a sentient item an objective it pursues, perhaps to the exclusion of all else. As long as the wielder's use of the item aligns with that special purpose, the item remains cooperative. Deviating from this course might cause conflict between the wielder and the item (see "Conflict" below). You can pick a special purpose or roll on the Sentient Item's Special Purpose table.

**Sentient Item's Alignment**

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Alignment</th>
      <th>1d100</th>
      <th>Alignment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–15</td>
      <td>Lawful Good</td>
      <td>74–85</td>
      <td>Chaotic Neutral</td>
    </tr>
    <tr>
      <td>16–35</td>
      <td>Neutral Good</td>
      <td>86–89</td>
      <td>Lawful Evil</td>
    </tr>
    <tr>
      <td>36–50</td>
      <td>Chaotic Good</td>
      <td>90–96</td>
      <td>Neutral Evil</td>
    </tr>
    <tr>
      <td>51–63</td>
      <td>Lawful Neutral</td>
      <td>97–00</td>
      <td>Chaotic Evil</td>
    </tr>
    <tr>
      <td>64–73</td>
      <td>Neutral</td>
      <td colspan="2"></td>
    </tr>
  </tbody>
</table>

**Sentient Item's Communication**

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Communication</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1–6</td>
      <td>The item communicates by transmitting emotion to the creature carrying or wielding it.</td>
    </tr>
    <tr>
      <td>7–9</td>
      <td>The item speaks one or more languages.</td>
    </tr>
    <tr>
      <td>10</td>
      <td>The item speaks one or more languages. In addition, the item can communicate telepathically with any creature that carries or wields it.</td>
    </tr>
  </tbody>
</table>

**Sentient Item's Senses**

<table>
  <thead>
    <tr>
      <th>1d4</th>
      <th>Senses</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Hearing and standard vision out to 30 feet</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Hearing and standard vision out to 60 feet</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Hearing and standard vision out to 120 feet</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Hearing and Darkvision out to 120 feet</td>
    </tr>
  </tbody>
</table>

**Sentient Item's Special Purpose**

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Special Purpose</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Aligned. The item seeks to defeat or destroy those of a diametrically opposed alignment. Such an item is never Neutral.</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Bane. The item seeks to thwart or destroy creatures of a particular type, such as Constructs, Fiends, or Undead.</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Creator Seeker. The item seeks its creator and wants to understand why it was created.</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Destiny Seeker. The item believes it and its bearer have key roles to play in future events.</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Destroyer. The item craves destruction and goads its user to fight arbitrarily.</td>
    </tr>
    <tr>
      <td>6</td>
      <td>Glory Seeker. The item seeks renown as the greatest magic item in the world by winning fame or notoriety for its user.</td>
    </tr>
    <tr>
      <td>7</td>
      <td>Lore Seeker. The item craves knowledge or is determined to solve a mystery, learn a secret, or unravel a cryptic prophecy.</td>
    </tr>
    <tr>
      <td>8</td>
      <td>Protector. The item seeks to defend a particular kind of creature, such as elves or werewolves.</td>
    </tr>
    <tr>
      <td>9</td>
      <td>Soulmate Seeker. The item seeks another sentient magic item, perhaps one that is similar to itself.</td>
    </tr>
    <tr>
      <td>10</td>
      <td>Templar. The item seeks to defend the servants and interests of a particular deity.</td>
    </tr>
  </tbody>
</table>

#### Conflict

When the bearer of a sentient item acts in a manner opposed to the item's alignment or purpose, conflict can arise. When such a conflict occurs, the item's bearer makes a Charisma saving throw (DC 12 plus the item's Charisma modifier). On a failed save, the item makes one or more of the following demands:

**Chase My Dreams.** The item demands that its bearer pursue the item's goals to the exclusion of all other goals.

**Get Rid of It.** The item demands that its bearer dispose of anything the item finds repugnant.

**It's Time for a Change.** The item demands to be given to someone else.

**Keep Me Close.** The item insists on being carried or worn at all times.

If its bearer refuses to comply with the item's demands, the item can do any of the following:

- Make it impossible for its bearer to attune to it.
- Suppress one or more of its activated properties.
- Attempt to take control of its bearer, whereupon the bearer makes a Charisma saving throw (DC 12 plus the item's Charisma modifier). On a failed save, the bearer has the Charmed condition for 1d12 hours. While Charmed in this way, the bearer must try to follow the item's commands. If the bearer takes damage, it repeats the save, ending the effect on a success. Whether or not the attempt to control its bearer succeeds, the item can't use this power again until the next dawn.

## Magic Items A–Z

Magic items are presented in alphabetical order.

If a magic item description capitalizes a creature's name and presents it in **bold** type, that's a visual cue pointing you to the creature's stat block. Unless the text states otherwise, the stat block is in "Monsters." How to read and use a stat block is explained in "Monsters."

#### Adamantine Armor

_Armor (Any Medium or Heavy, Except Hide Armor), Uncommon_

This suit of armor is reinforced with adamantine, one of the hardest substances in existence. While you're wearing it, any Critical Hit against you becomes a normal hit.

#### Ammunition, +1, +2, or +3

_Weapon (Any Ammunition), Uncommon (+1), Rare (+2), or Very Rare (+3)_

You have a bonus to attack rolls and damage rolls made with this piece of magic ammunition. The bonus is determined by the rarity of the ammunition. Once it hits a target, the ammunition is no longer magical.

This ammunition is typically found or sold in quantities of ten or twenty pieces. Ten pieces of this ammunition are equivalent in value to a potion of the same rarity.

#### Ammunition of Slaying

_Weapon (Any Ammunition), Very Rare_

This magic ammunition is meant to slay creatures of a particular type, which the GM chooses or determines randomly by rolling on the table below. If a creature of that type takes damage from the ammunition, the creature makes a DC 17 Constitution saving throw, taking an extra 6d10 Force damage on a failed save or half as much extra damage on a successful one.

After dealing its extra damage to a creature, the ammunition becomes nonmagical.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Creature Type</th>
      <th>1d100</th>
      <th>Creature Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–10</td>
      <td>Aberrations</td>
      <td>51–60</td>
      <td>Fey</td>
    </tr>
    <tr>
      <td>11–15</td>
      <td>Beasts</td>
      <td>61–70</td>
      <td>Fiends</td>
    </tr>
    <tr>
      <td>16–20</td>
      <td>Celestials</td>
      <td>71–75</td>
      <td>Giants</td>
    </tr>
    <tr>
      <td>21–25</td>
      <td>Constructs</td>
      <td>76–80</td>
      <td>Monstrosities</td>
    </tr>
    <tr>
      <td>26–35</td>
      <td>Dragons</td>
      <td>81–85</td>
      <td>Oozes</td>
    </tr>
    <tr>
      <td>36–45</td>
      <td>Elementals</td>
      <td>86–90</td>
      <td>Plants</td>
    </tr>
    <tr>
      <td>46–50</td>
      <td>Humanoids</td>
      <td>91–00</td>
      <td>Undead</td>
    </tr>
  </tbody>
</table>

#### Amulet of Health

_Wondrous Item, Rare (Requires Attunement)_

Your Constitution is 19 while you wear this amulet. It has no effect on you if your Constitution is 19 or higher without it.

#### Amulet of Proof against Detection and Location

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this amulet, you can't be targeted by Divination spells or perceived through magical scrying sensors unless you allow it.

#### Amulet of the Planes

_Wondrous Item, Very Rare (Requires Attunement)_

While wearing this amulet, you can take a Magic action to name a location that you are familiar with on another plane of existence. Then make a DC 15 Intelligence (Arcana) check. On a successful check, you cast _Plane Shift_. On a failed check, you and each creature and object within 15 feet of you travel to a random destination determined by rolling 1d100 and consulting the following table.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Destination</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–60</td>
      <td>Random location on the plane you named</td>
    </tr>
    <tr>
      <td>61–70</td>
      <td>Random location on an Inner Plane determined by rolling 1d6: on a 1, the Plane of Air; on a 2, the Plane of Earth; on a 3, the Plane of Fire; on a 4, the Plane of Water; on a 5, the Feywild; on a 6, the Shadowfell</td>
    </tr>
    <tr>
      <td>71–80</td>
      <td>Random location on an Outer Plane determined by rolling 1d8: on a 1, Arborea; on a 2, Arcadia; on a 3, the Beastlands; on a 4, Bytopia; on a 5, Elysium; on a 6, Mechanus; on a 7, Mount Celestia; on an 8, Ysgard</td>
    </tr>
    <tr>
      <td>81–90</td>
      <td>Random location on an Outer Plane determined by rolling 1d8: on a 1, the Abyss; on a 2, Acheron; on a 3, Carceri; on a 4, Gehenna; on a 5, Hades; on a 6, Limbo; on a 7, the Nine Hells; on an 8, Pandemonium</td>
    </tr>
    <tr>
      <td>91–00</td>
      <td>Random location on the Astral Plane</td>
    </tr>
  </tbody>
</table>

#### Animated Shield

_Armor (Shield), Very Rare (Requires Attunement)_

While holding this Shield, you can take a Bonus Action to cause it to animate. The Shield leaps into the air and hovers in your space to protect you as if you were wielding it, leaving your hands free. The Shield remains animate for 1 minute, until you take a Bonus Action to end this effect, or until you die or have the Incapacitated condition, at which point the Shield falls to the ground or into your hand if you have one free.

#### Apparatus of the Crab

_Wondrous Item, Legendary_

This item first appears to be a sealed iron barrel weighing 500 pounds. The barrel has a hidden catch, which can be found with a successful DC 20 Intelligence (Investigation) check. Releasing the catch unlocks a hatch at one end of the barrel, allowing two Medium or smaller creatures to crawl inside. Ten levers are set in a row at the far end, each in a neutral position, able to move up or down. When certain levers are used, the apparatus transforms to resemble a giant lobster.

The _Apparatus of the Crab_ is a Large object with the following statistics: AC 20; HP 200; Speed 30 ft., Swim 30 ft. (or 0 ft. for both if the legs aren't extended); Immunity to Poison and Psychic damage.

To be used as a vehicle, the apparatus requires one pilot. While the apparatus's hatch is closed, the compartment is airtight and watertight. The compartment holds enough air for 10 hours of breathing, divided by the number of breathing creatures inside.

The apparatus floats on water. It can also go underwater to a depth of 900 feet. Below that, the vehicle takes 2d6 Bludgeoning damage each minute from pressure.

A creature in the compartment can take a Utilize action to move as many as two of the apparatus's levers up or down. After each use, a lever goes back to its neutral position. Each lever, from left to right, functions as shown in the Apparatus of the Crab Levers table.

**Apparatus of the Crab Levers**

<table>
  <thead>
    <tr>
      <th>Lever</th>
      <th>Up</th>
      <th>Down</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Legs extend, allowing the apparatus to walk and swim.</td>
      <td>Legs retract, reducing the apparatus's Speed and Swim Speed to 0 and making it unable to benefit from bonuses to speed.</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Forward window shutter opens.</td>
      <td>Forward window shutter closes.</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Side window shutters open (two per side).</td>
      <td>Side window shutters close (two per side).</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Two claws extend from the front side of the apparatus.</td>
      <td>The claws retract.</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Each extended claw makes the following melee attack: +8 to hit, reach 5 ft. Hit: 7 (2d6) Bludgeoning damage.</td>
      <td>Each extended claw makes the following melee attack: +8 to hit, reach 5 ft. Hit: The target has the Grappled condition (escape DC 15).</td>
    </tr>
    <tr>
      <td>6</td>
      <td>The apparatus walks or swims forward provided its legs are extended.</td>
      <td>The apparatus walks or swims backward provided its legs are extended.</td>
    </tr>
    <tr>
      <td>7</td>
      <td>The apparatus turns 90 degrees counterclockwise provided its legs are extended.</td>
      <td>The apparatus turns 90 degrees clockwise provided its legs are extended.</td>
    </tr>
    <tr>
      <td>8</td>
      <td>Eyelike fixtures emit Bright Light in a 30-foot radius and Dim Light for an additional 30 feet.</td>
      <td>The light turns off.</td>
    </tr>
    <tr>
      <td>9</td>
      <td>The apparatus sinks up to 20 feet if it's in liquid.</td>
      <td>The apparatus rises up to 20 feet if it's in liquid.</td>
    </tr>
    <tr>
      <td>10</td>
      <td>The rear hatch unseals and opens.</td>
      <td>The rear hatch closes and seals.</td>
    </tr>
  </tbody>
</table>

#### Armor, +1, +2, or +3

_Armor (Any Light, Medium, or Heavy), Rare (+1), Very Rare (+2), or Legendary (+3)_

You have a bonus to Armor Class while wearing this armor. The bonus is determined by its rarity.

#### Armor of Invulnerability

_Armor (Plate Armor), Legendary (Requires Attunement)_

You have Resistance to Bludgeoning, Piercing, and Slashing damage while you wear this armor.

**_Metal Shell._** You can take a Magic action to give yourself Immunity to Bludgeoning, Piercing, and Slashing damage for 10 minutes or until you are no longer wearing the armor. Once this property is used, it can't be used again until the next dawn.

#### Armor of Resistance

_Armor (Any Light, Medium, or Heavy), Rare (Requires Attunement)_

You have Resistance to one type of damage while you wear this armor. The GM chooses the type or determines it randomly by rolling on the following table.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Damage Type</th>
      <th>1d10</th>
      <th>Damage Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Acid</td>
      <td>6</td>
      <td>Necrotic</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Cold</td>
      <td>7</td>
      <td>Poison</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Fire</td>
      <td>8</td>
      <td>Psychic</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Force</td>
      <td>9</td>
      <td>Radiant</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Lightning</td>
      <td>10</td>
      <td>Thunder</td>
    </tr>
  </tbody>
</table>

#### Armor of Vulnerability

_Armor (Any Light, Medium, or Heavy), Rare (Requires Attunement)_

While wearing this armor, you have Resistance to one of the following damage types: Bludgeoning, Piercing, or Slashing. The GM chooses the type or determines it randomly.

_Curse._ This armor is cursed, a fact that is revealed only when the _Identify_ spell is cast on the armor or you attune to it. Attuning to the armor curses you until you are targeted by a _Remove Curse_ spell or similar magic; removing the armor fails to end the curse. While cursed, you have Vulnerability to two of the three damage types associated with the armor (not the one to which it grants Resistance).

#### Arrow-Catching Shield

_Armor (Shield), Rare (Requires Attunement)_

You gain a +2 bonus to Armor Class against ranged attack rolls while you wield this Shield. This bonus is in addition to the Shield's normal bonus to AC.

Whenever an attacker makes a ranged attack roll against a target within 5 feet of you, you can take a Reaction to become the target of the attack instead.

#### Bag of Beans

_Wondrous Item, Rare_

This heavy cloth bag contains 3d4 dry beans when found. The bag weighs half a pound regardless of how many beans it contains and becomes a non-magical item when it no longer contains any beans.

If you dump one or more beans out of the bag, they explode in a 10-foot-radius Sphere centered on them. All the dumped beans are destroyed in the explosion, and each creature in the Sphere, including you, makes a DC 15 Dexterity saving throw, taking 5d4 Force damage on a failed save or half as much damage on a successful one.

If you remove a bean from the bag, plant it in dirt or sand, and then water it, the bean disappears as it produces an effect 1 minute later from the ground where it was planted. The GM can choose an effect from the following table or determine it randomly.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01</td>
      <td>5d4 toadstools sprout. If a creature eats a toadstool, roll any die. On an odd roll, the eater must succeed on a DC 15 Constitution saving throw or take 5d6 Poison damage and have the Poisoned condition for 1 hour. On an even roll, the eater gains 5d6 Temporary Hit Points for 1 hour.</td>
    </tr>
    <tr>
      <td>02–10</td>
      <td>A geyser erupts and spouts water, beer, mayonnaise, tea, vinegar, wine, or oil (GM's choice) 30 feet into the air for 1d4 minutes.</td>
    </tr>
    <tr>
      <td>11–20</td>
      <td>A Treant sprouts. Roll any die. On an odd roll, the treant is Chaotic Evil. On an even roll, the treant is Chaotic Good.</td>
    </tr>
    <tr>
      <td>21–30</td>
      <td>An animate but immobile stone statue in your likeness rises and makes verbal threats against you. If you leave it and others come near, it describes you as the most heinous of villains and directs the newcomers to find and attack you. If you are on the same plane of existence as the statue, it knows where you are. The statue becomes inanimate after 24 hours.</td>
    </tr>
    <tr>
      <td>31–40</td>
      <td>A campfire with green flames springs forth and burns for 24 hours or until it is extinguished.</td>
    </tr>
    <tr>
      <td>41–50</td>
      <td>Three Shrieker Fungi sprout.</td>
    </tr>
    <tr>
      <td>51–60</td>
      <td>1d4 + 4 bright-pink toads crawl forth. Whenever a toad is touched, it transforms into a Large or smaller monster of the GM's choice that acts in accordance with its alignment and nature. The monster remains for 1 minute, then disappears in a puff of bright-pink smoke.</td>
    </tr>
    <tr>
      <td>61–70</td>
      <td>A hungry Bulette burrows up and attacks.</td>
    </tr>
    <tr>
      <td>71–80</td>
      <td>A fruit tree grows. It has 1d10 + 20 fruit, 1d8 of which act as randomly determined potions. The tree vanishes after 1 hour. Picked fruit remains, retaining any magic for 30 days.</td>
    </tr>
    <tr>
      <td>81–90</td>
      <td>A nest of 1d4 + 3 rainbow-colored eggs springs up. Any creature that eats an egg makes a DC 20 Constitution saving throw. On a successful save, a creature permanently increases its lowest ability score by 1, randomly choosing among equally low scores. On a failed save, the creature takes 10d6 Force damage from an internal explosion.</td>
    </tr>
    <tr>
      <td>91–95</td>
      <td>A pyramid with a 60-foot-square base bursts upward. Inside is a burial chamber containing a Mummy, a Mummy Lord, or some other Undead of the GM's choice. Its sarcophagus contains treasure of the GM's choice.</td>
    </tr>
    <tr>
      <td>96–00</td>
      <td>A giant beanstalk sprouts, growing to a height of the GM's choice. The top leads where the GM chooses, such as to a great view, a cloud giant's castle, or another plane of existence.</td>
    </tr>
  </tbody>
</table>

#### Bag of Devouring

_Wondrous Item, Very Rare_

This bag resembles a _Bag of Holding_ but is a feeding orifice for a gigantic extradimensional creature. Turning the bag inside out closes the orifice.

The extradimensional creature attached to the bag can sense whatever is placed inside the bag. Animal or vegetable matter placed wholly in the bag is devoured and lost forever. When part of a living creature is placed in the bag, as happens when someone reaches inside it, there is a 50 percent chance that the creature is pulled inside the bag. A creature inside the bag can take an action to try to escape, doing so with a successful DC 15 Strength (Athletics) check. Another creature can take an action to reach into the bag to pull a creature out, doing so with a successful DC 20 Strength (Athletics) check, provided the puller isn't pulled inside the bag first. Any creature that starts its turn inside the bag is devoured, its body destroyed.

Inanimate objects can be stored in the bag, which can hold a cubic foot of such material. However, once each day, the bag swallows any objects inside it and spits them out into another plane of existence. The GM determines the time and plane.

If the bag is pierced or torn, it is destroyed, and anything contained within it is transported to a random location on the Astral Plane.

#### Bag of Holding

_Wondrous Item, Uncommon_

This bag has an interior space considerably larger than its outside dimensions—roughly 2 feet square and 4 feet deep on the inside. The bag can hold up to 500 pounds, not exceeding a volume of 64 cubic feet. The bag weighs 5 pounds, regardless of its contents. Retrieving an item from the bag requires a Utilize action.

If the bag is overloaded, pierced, or torn, it is destroyed, and its contents are scattered in the Astral Plane. If the bag is turned inside out, its contents spill forth unharmed, but the bag must be put right before it can be used again. The bag holds enough air for 10 minutes of breathing, divided by the number of breathing creatures inside.

Placing a _Bag of Holding_ inside an extradimensional space created by a _Handy Haversack_, _Portable Hole_, or similar item instantly destroys both items and opens a gate to the Astral Plane. The gate originates where the one item was placed inside the other. Any creature within a 10-foot-radius Sphere centered on the gate is sucked through it to a random location on the Astral Plane. The gate then closes. The gate is one-way and can't be reopened.

#### Bag of Tricks

_Wondrous Item, Uncommon_

This bag made from gray, rust, or tan cloth appears empty. Reaching inside the bag, however, reveals the presence of a small, fuzzy object.

You can take a Magic action to pull the fuzzy object from the bag and throw it up to 20 feet. When the object lands, it transforms into a creature you determine by rolling on the table that corresponds to the bag's color. See "Monsters" for the creature's stat block. The creature vanishes at the next dawn or when it is reduced to 0 Hit Points.

The creature is Friendly to you and your allies, and it acts immediately after you on your Initiative count. You can take a Bonus Action to command how the creature moves and what action it takes on its next turn, such as attacking an enemy. In the absence of such orders, the creature acts in a fashion appropriate to its nature.

Once three fuzzy objects have been pulled from the bag, the bag can't be used again until the next dawn.

**Gray Bag of Tricks**

<table>
  <thead>
    <tr>
      <th>1d8</th>
      <th>Creature</th>
      <th>1d8</th>
      <th>Creature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Weasel</td>
      <td>5</td>
      <td>Panther</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Giant Rat</td>
      <td>6</td>
      <td>Giant Badger</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Badger</td>
      <td>7</td>
      <td>Dire Wolf</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Boar</td>
      <td>8</td>
      <td>Giant Elk</td>
    </tr>
  </tbody>
</table>

**Rust Bag of Tricks**

<table>
  <thead>
    <tr>
      <th>1d8</th>
      <th>Creature</th>
      <th>1d8</th>
      <th>Creature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Rat</td>
      <td>5</td>
      <td>Giant Goat</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Owl</td>
      <td>6</td>
      <td>Giant Boar</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Mastiff</td>
      <td>7</td>
      <td>Lion</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Goat</td>
      <td>8</td>
      <td>Brown Bear</td>
    </tr>
  </tbody>
</table>

**Tan Bag of Tricks**

<table>
  <thead>
    <tr>
      <th>1d8</th>
      <th>Creature</th>
      <th>1d8</th>
      <th>Creature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Jackal</td>
      <td>5</td>
      <td>Black Bear</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Ape</td>
      <td>6</td>
      <td>Giant Weasel</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Baboon</td>
      <td>7</td>
      <td>Giant Hyena</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Axe Beak</td>
      <td>8</td>
      <td>Tiger</td>
    </tr>
  </tbody>
</table>

#### Bead of Force

_Wondrous Item, Rare_

This small black sphere measures 3/4 of an inch in diameter and weighs an ounce. Typically, 1d4 + 4 _Beads of Force_ are found together.

You can take a Magic action to throw the bead up to 60 feet. The bead explodes in a 10-foot-radius Sphere on impact and is destroyed. Each creature
in the Sphere must succeed on a DC 15 Dexterity saving throw or take 5d4 Force damage. A sphere of transparent force then encloses the area for 1 minute. Any creature that failed the save and is completely within the area is trapped inside this sphere. Creatures that succeeded on the save or are partially within the area are pushed away from the center of the sphere until they are no longer inside it. Only breathable air can pass through the sphere's wall. No attack or other effect can pass through.

An enclosed creature can take a Utilize action to push against the sphere's wall, moving the sphere up to half the creature's Speed. The sphere can be picked up, and its magic causes it to weigh only 1 pound, regardless of the weight of creatures inside.

#### Bead of Nourishment

_Wondrous Item, Common_

This flavorless, gelatinous bead dissolves on your tongue and provides as much nourishment as 1 day of Rations.

#### Belt of Dwarvenkind

_Wondrous Item, Rare (Requires Attunement)_

While wearing this belt, you gain the following benefits:

**Dwarvish.** You know Dwarvish.

**Friend of Dwarvenkind.** You have Advantage on Charisma (Persuasion) checks made to interact with dwarves and duergar.

**Toughness.** Your Constitution increases by 2, to a maximum of 20.

In addition, while attuned to the belt, you have a 50 percent chance each day at dawn of growing a full beard if you can grow one, or a thicker beard if you already have one.

If you aren't a dwarf or duergar, you gain the following additional benefits while wearing the belt:

**Darkvision.** You have Darkvision with a range of 60 feet.

**Resilience.** You have Resistance to Poison damage. You also have Advantage on saving throws you make to avoid or end the Poisoned condition.

#### Belt of Giant Strength

_Wondrous Item, Rarity Varies (Requires Attunement)_

While wearing this belt, your Strength changes to a score granted by the belt. The type of giant determines the score (see the table below). The item has no effect on you if your Strength without the belt is equal to or greater than the belt's score.

<table>
  <thead>
    <tr>
      <th>Belt</th>
      <th>Str.</th>
      <th>Rarity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Belt of Giant Strength (hill)</td>
      <td>21</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>Belt of Giant Strength (frost or stone)</td>
      <td>23</td>
      <td>Very Rare</td>
    </tr>
    <tr>
      <td>Belt of Giant Strength (fire)</td>
      <td>25</td>
      <td>Very Rare</td>
    </tr>
    <tr>
      <td>Belt of Giant Strength (cloud)</td>
      <td>27</td>
      <td>Legendary</td>
    </tr>
    <tr>
      <td>Belt of Giant Strength (storm)</td>
      <td>29</td>
      <td>Legendary</td>
    </tr>
  </tbody>
</table>

#### Berserker Axe

_Weapon (Battleaxe, Greataxe, or Halberd), Rare (Requires Attunement)_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon. In addition, while you are attuned to this weapon, your Hit Point maximum increases by 1 for each level you have attained.

_Curse._ This weapon is cursed, and becoming attuned to it extends the curse to you. As long as you remain cursed, you are unwilling to part with the weapon, keeping it within reach at all times. You also have Disadvantage on attack rolls with weapons other than this one.

Whenever another creature damages you while the weapon is in your possession, you must succeed on a DC 15 Wisdom saving throw or go berserk. This berserk state ends when you start your turn and there are no creatures within 60 feet of you that you can see or hear.

While berserk, you regard the creature nearest to you that you can see or hear as your enemy. If there are multiple possible creatures, choose one at random. On each of your turns, you must move as close to the creature as possible and take the Attack action, targeting the creature. If you're unable to get close enough to the creature to attack it with the weapon, your turn ends after you've used up all your available movement. If the creature dies or can no longer be seen or heard by you, the next nearest creature that you can see or hear becomes your new target.

#### Boots of Elvenkind

_Wondrous Item, Uncommon_

While you wear these boots, your steps make no sound, regardless of the surface you are moving across. You also have Advantage on Dexterity (Stealth) checks.

#### Boots of Levitation

_Wondrous Item, Rare (Requires Attunement)_

While you wear these boots, you can cast _Levitate_ on yourself.

#### Boots of Speed

_Wondrous Item, Rare (Requires Attunement)_

While you wear these boots, you can take a Bonus Action to click the boots' heels together. If you do, the boots double your Speed, and any creature that makes an Opportunity Attack against you has Disadvantage on the attack roll. If you click your heels together again, you end the effect.

When you've used the boots' property for a total of 10 minutes, the magic ceases to function for you until you finish a Long Rest.

#### Boots of Striding and Springing

_Wondrous Item, Uncommon (Requires Attunement)_

While you wear these boots, your Speed becomes 30 feet unless your Speed is higher, and your Speed isn't reduced by you carrying weight in excess of your carrying capacity or wearing Heavy Armor.

Once on each of your turns, you can jump up to 30 feet by spending only 10 feet of movement.

#### Boots of the Winterlands

_Wondrous Item, Uncommon (Requires Attunement)_

These furred boots are snug and feel warm. While wearing them, you gain the following benefits.

_Cold Resistance._ You have Resistance to Cold damage and can tolerate temperatures of 0 degrees Fahrenheit or lower without any additional protection.

_Winter Strider._ You ignore Difficult Terrain created by ice or snow.

#### Bowl of Commanding Water Elementals

_Wondrous Item, Rare_

While this bowl is filled with water and you are within 5 feet of it, you can take a Magic action to summon a Water Elemental. The elemental appears in an unoccupied space as close to the bowl as possible, understands your languages, obeys your commands, and takes its turn immediately after you on your Initiative count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The bowl can't be used this way again until the next dawn.

The bowl is about 1 foot in diameter and half as deep. It holds about 3 gallons.

#### Bracers of Archery

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing these bracers, you have proficiency with the Longbow and Shortbow, and you gain a +2 bonus to damage rolls made with such weapons.

#### Bracers of Defense

_Wondrous Item, Rare (Requires Attunement)_

While wearing these bracers, you gain a +2 bonus to Armor Class if you are wearing no armor and using no Shield.

#### Brazier of Commanding Fire Elementals

_Wondrous Item, Rare_

While you are within 5 feet of this brazier, you can take a Magic action to summon a Fire Elemental. The elemental appears in an unoccupied space as close to the brazier as possible, understands your languages, obeys your commands, and takes its turn immediately after you on your Initiative count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The brazier can't be used this way again until the next dawn.

#### Brooch of Shielding

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this brooch, you have Resistance to Force damage, and you have Immunity to damage from the _Magic Missile_ spell.

#### Broom of Flying

_Wondrous Item, Uncommon (Requires Attunement)_

This wooden broom functions like a mundane broom until you stand astride it and take a Magic action to make it hover beneath you, at which time it can be ridden in the air. It has a Fly Speed of 50 feet. It can carry up to 400 pounds, but its Fly Speed becomes 30 feet while carrying over 200 pounds. The broom stops hovering when you land or when you're no longer riding it.

As a Magic action, you can send the broom to travel alone to a destination within 1 mile of you if you name the location and are familiar with it. The broom comes back to you when you take a Magic action and use a command word if the broom is still within 1 mile of you.

#### Candle of Invocation

_Wondrous Item, Very Rare (Requires Attunement)_

This candle's magic is activated when the candle is lit, which requires a Magic action. After burning for 4 hours, the candle is destroyed. You can snuff it out early for use at a later time. Deduct the time it burned in increments of 1 minute from its total burn time.

While lit, the candle sheds Dim Light in a 30-foot radius. While you are within that light, you have Advantage on D20 Tests. In addition, a Cleric or Druid in the light can cast level 1 spells they have prepared without expending spell slots.

Alternatively, when you light the candle for the first time, you can cast _Gate_ with it. Doing so destroys the candle. The portal created by the spell
links to a particular Outer Plane chosen by the GM or determined by rolling on the following table.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Outer Plane</th>
      <th>1d100</th>
      <th>Outer Plane</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–05</td>
      <td>Abyss</td>
      <td>55–59</td>
      <td>Gehenna</td>
    </tr>
    <tr>
      <td>06–10</td>
      <td>Acheron</td>
      <td>60–64</td>
      <td>Hades</td>
    </tr>
    <tr>
      <td>11–17</td>
      <td>Arborea</td>
      <td>65–69</td>
      <td>Limbo</td>
    </tr>
    <tr>
      <td>18–25</td>
      <td>Arcadia</td>
      <td>70–77</td>
      <td>Mechanus</td>
    </tr>
    <tr>
      <td>26–33</td>
      <td>Beastlands</td>
      <td>78–85</td>
      <td>Mount Celestia</td>
    </tr>
    <tr>
      <td>34–41</td>
      <td>Bytopia</td>
      <td>86–90</td>
      <td>Nine Hells</td>
    </tr>
    <tr>
      <td>42–46</td>
      <td>Carceri</td>
      <td>91–95</td>
      <td>Pandemonium</td>
    </tr>
    <tr>
      <td>47–54</td>
      <td>Elysium</td>
      <td>96–00</td>
      <td>Ysgard</td>
    </tr>
  </tbody>
</table>

#### Cape of the Mountebank

_Wondrous Item, Rare_

This cape smells faintly of brimstone. While wearing it, you can use it to cast _Dimension Door_ as a Magic action. This property can't be used again until the next dawn.

When you teleport with that spell, you leave behind a cloud of smoke. The space you left is Lightly Obscured by that smoke until the end of your next turn.

#### Carpet of Flying

_Wondrous Item, Very Rare_

You can make this carpet hover and fly by taking a Magic action and using the carpet's command word. It moves according to your directions if you are within 30 feet of it.

Four sizes of _Carpet of Flying_ exist. The GM chooses the size of a given carpet or determines it randomly by rolling on the following table. A carpet can carry up to twice the weight shown on the table, but its Fly Speed is halved if it carries more than its normal capacity.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Size</th>
      <th>Capacity</th>
      <th>Fly Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–20</td>
      <td>3 ft. × 5 ft.</td>
      <td>200 lb.</td>
      <td>80 feet</td>
    </tr>
    <tr>
      <td>21–55</td>
      <td>4 ft. × 6 ft.</td>
      <td>400 lb.</td>
      <td>60 feet</td>
    </tr>
    <tr>
      <td>56–80</td>
      <td>5 ft. × 7 ft.</td>
      <td>600 lb.</td>
      <td>40 feet</td>
    </tr>
    <tr>
      <td>81–00</td>
      <td>6 ft. × 9 ft.</td>
      <td>800 lb.</td>
      <td>30 feet</td>
    </tr>
  </tbody>
</table>

#### Censer of Controlling Air Elementals

_Wondrous Item, Rare_

While gently swinging this censer, you can take a Magic action to summon an Air Elemental. The elemental appears in an unoccupied space as close to the censer as possible, understands your languages, obeys your commands, and takes its turn immediately after you on your Initiative count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The censer can't be used this way again until the next dawn.

#### Chime of Opening

_Wondrous Item, Rare_

This hollow metal tube measures about 1 foot long and weighs 1 pound. As a Magic action, you can strike the chime to cast _Knock_. The spell's customary knocking sound is replaced by the clear, ringing tone of the chime, which is audible out to 300 feet.

The chime can be used 10 times. After the tenth time, it cracks and becomes useless.

#### Circlet of Blasting

_Wondrous Item, Uncommon_

While wearing this circlet, you can cast _Scorching Ray_ with it (+5 to hit). The circlet can't cast this spell again until the next dawn.

#### Cloak of Arachnida

_Wondrous Item, Very Rare (Requires Attunement)_

This fine garment is made of black silk interwoven with faint, silvery threads. While wearing it, you gain the following benefits.

_Poison Resistance._ You have Resistance to Poison damage.

_Spider Climb._ You have a Climb Speed equal to your Speed and can move up, down, and across vertical surfaces and along ceilings, while leaving your hands free.

_Spider Walk._ You can't be caught in webs of any sort and can move through webs as if they were Difficult Terrain.

_Web._ You can cast _Web_ (save DC 13). The web created by the spell fills twice its normal area. Once used, this property can't be used again until the next dawn.

#### Cloak of Displacement

_Wondrous Item, Rare (Requires Attunement)_

While you wear this cloak, it magically projects an illusion that makes you appear to be standing in a place near your actual location, causing any creature to have Disadvantage on attack rolls against you. If you take damage, the property ceases to function until the start of your next turn. This property is suppressed while your Speed is 0.

#### Cloak of Elvenkind

_Wondrous Item, Uncommon (Requires Attunement)_

While you wear this cloak, Wisdom (Perception) checks made to perceive you have Disadvantage, and you have Advantage on Dexterity (Stealth) checks.

#### Cloak of Invisibility

_Wondrous Item, Legendary (Requires Attunement)_

This cloak has 3 charges and regains 1d3 expended charges daily at dawn. While wearing the cloak, you can take a Magic action to pull its hood over your
head and expend 1 charge to give yourself the Invisible condition for 1 hour. The effect ends early if you pull the hood down (no action required) or cease wearing the cloak.

#### Cloak of Protection

_Wondrous Item, Uncommon (Requires Attunement)_

You gain a +1 bonus to Armor Class and saving throws while you wear this cloak.

#### Cloak of the Bat

_Wondrous Item, Rare (Requires Attunement)_

While wearing this cloak, you have Advantage on Dexterity (Stealth) checks. In an area of Dim Light or Darkness, you can grip the edges of the cloak and use it to gain a Fly Speed of 40 feet. If you ever fail to grip the cloak's edges while flying in this way, or if you are no longer in Dim Light or Darkness, you lose this Fly Speed.

While wearing the cloak in an area of Dim Light or Darkness, you can cast _Polymorph_ on yourself, shape-shifting into a Bat. While in that form, you retain your Intelligence, Wisdom, and Charisma scores. The cloak can't be used this way again until the next dawn.

#### Cloak of the Manta Ray

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this cloak, you can breathe underwater, and you have a Swim Speed of 60 feet.

#### Crystal Ball

_Wondrous Item, Very Rare (Requires Attunement)_

While touching this crystal orb, you can cast _Scrying_ (save DC 17) with it.

#### Crystal Ball of Mind Reading

_Wondrous Item, Legendary (Requires Attunement)_

While touching this crystal orb, you can cast _Scrying_ (save DC 17) with it. In addition, you can cast _Detect Thoughts_ (save DC 17) targeting creatures you can see within 30 feet of the spell's sensor. You don't need to concentrate on this _Detect Thoughts_ spell to maintain it during its duration, but it ends if the _Scrying_ spell ends.

#### Crystal Ball of Telepathy

_Wondrous Item, Legendary (Requires Attunement)_

While touching this crystal orb, you can cast _Scrying_ (save DC 17) with it. In addition, you can communicate telepathically with creatures you can see within 30 feet of the spell's sensor. You can also cast _Suggestion_ (save DC 17) through the sensor on one of those creatures. You don't need to concentrate on this _Suggestion_ to maintain it during its duration, but it ends if _Scrying_ ends. You can't cast _Suggestion_ in this way again until the next dawn.

#### Crystal Ball of True Seeing

_Wondrous Item, Legendary (Requires Attunement)_

While touching this crystal orb, you can cast _Scrying_ (save DC 17) with it. In addition, you have Truesight with a range of 120 feet centered on the spell's sensor.

#### Cube of Force

_Wondrous Item, Rare (Requires Attunement)_

This cube is about an inch across. Each face has a distinct marking on it. You can press one of those faces, expend the number of charges required for it, and thereby cast the spell associated with it (save DC 17), as shown in the Cube of Force Faces table.

The cube starts with 10 charges, and it regains 1d6 expended charges daily at dawn.

**Cube of Force Faces**

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mage Armor</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Shield</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Tiny Hut</td>
      <td>3</td>
    </tr>
    <tr>
      <td>Private Sanctum</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Resilient Sphere</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Wall of Force</td>
      <td>5</td>
    </tr>
  </tbody>
</table>

#### Cubic Gate

_Wondrous Item, Legendary_

This cube is 3 inches across and radiates palpable magical energy. The six sides of the cube are each keyed to a different plane of existence, one of which is the Material Plane. The other sides are linked to planes determined by the GM.

The cube has 3 charges and regains 1d3 expended charges daily at dawn. As a Magic action, you can expend 1 of the cube's charges to cast one of the following spells using the cube.

_Gate._ Pressing one side of the cube, you cast _Gate_, opening a portal to the plane of existence keyed to that side.

_Plane Shift._ Pressing one side of the cube twice, you cast _Plane Shift_, transporting the targets to the plane of existence keyed to that side.

#### Dagger of Venom

_Weapon (Dagger), Rare_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon.

You can take a Bonus Action to magically coat the blade with poison. The poison remains for 1 minute or until an attack using this weapon hits a creature. That creature must succeed on a DC 15 Constitution saving throw or take 2d10 Poison damage and have the Poisoned condition for 1 minute. The weapon can't be used this way again until the next dawn.

#### Dancing Sword

_Weapon (Greatsword, Longsword, Rapier, Scimitar, or Shortsword), Very Rare (Requires Attunement)_

You can take a Bonus Action to toss this magic weapon into the air. When you do so, the weapon begins to hover, flies up to 30 feet, and attacks one creature of your choice within 5 feet of itself. The weapon uses your attack roll and adds your ability modifier to damage rolls.

While the weapon hovers, you can take a Bonus Action to cause it to fly up to 30 feet to another spot within 30 feet of you. As part of the same Bonus Action, you can cause the weapon to attack one creature within 5 feet of the weapon.

After the hovering weapon attacks for the fourth time, it flies back to you and tries to return to your hand. If you have no hand free, the weapon falls to the ground in your space. If the weapon has no unobstructed path to you, it moves as close to you as it can and then falls to the ground. It also ceases to hover if you grasp it or are more than 30 feet away from it.

#### Decanter of Endless Water

_Wondrous Item, Uncommon_

This stoppered flask sloshes when shaken, as if it contains water. The decanter weighs 2 pounds.

You can take a Magic action to remove the stopper and issue one of three command words, whereupon an amount of fresh water or salt water (your choice) pours out of the flask. The water stops pouring out at the start of your next turn. Choose from the following command words:

**Splash.** The decanter produces 1 gallon of water.
**Fountain.** The decanter produces 5 gallons of water.
**Geyser.** The decanter produces 30 gallons of water that gushes forth in a Line 30 feet long and 1 foot wide. If you're holding the decanter, you can aim the geyser in one direction (no action required). One creature of your choice in the Line must succeed on a DC 13 Strength saving throw or take 1d4 Bludgeoning damage and have the Prone condition. Instead of a creature, you can target one object in the Line that isn't being worn or carried and that weighs no more than 200 pounds. The object is knocked over by the geyser.

#### Deck of Illusions

_Wondrous Item, Uncommon_

This box contains a set of cards. A full deck has 34 cards: 32 depicting specific creatures and two with a mirrored surface. A deck found as treasure is usually missing 1d20 − 1 cards.

The magic of the deck functions only if its cards are drawn at random. You can take a Magic action to draw a card at random from the deck and throw it to the ground at a point within 30 feet of yourself. An illusion of a creature, determined by rolling on the Deck of Illusions table, forms over the thrown card and remains until dispelled. The illusory creature created by the card looks and behaves like a real creature of its kind, except that it can do no harm. While you are within 120 feet of the illusory creature and can see it, you can take a Magic action to move it anywhere within 30 feet of its card.

Any physical interaction with the illusory creature reveals it to be false, because objects pass through it. A creature that takes a Study action to visually inspect the illusory creature identifies it as an illusion with a successful DC 15 Intelligence (Investigation) check. The illusion lasts until its card is moved or the illusion is dispelled (using a _Dispel Magic_ spell or a similar effect). When the illusion ends, the image on its card disappears, and that card can't be used again.

**Deck of Illusions**

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Illusion*</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–03</td>
      <td>Adult Red Dragon</td>
    </tr>
    <tr>
      <td>04–06</td>
      <td>Archmage</td>
    </tr>
    <tr>
      <td>07–09</td>
      <td>Assassin</td>
    </tr>
    <tr>
      <td>10–12</td>
      <td>Bandit Captain</td>
    </tr>
    <tr>
      <td>13–15</td>
      <td>Basilisk</td>
    </tr>
    <tr>
      <td>16–18</td>
      <td>Berserker</td>
    </tr>
    <tr>
      <td>19–21</td>
      <td>Bugbear Warrior</td>
    </tr>
    <tr>
      <td>22–24</td>
      <td>Cloud Giant</td>
    </tr>
    <tr>
      <td>25–27</td>
      <td>Druid</td>
    </tr>
    <tr>
      <td>28–30</td>
      <td>Erinyes</td>
    </tr>
    <tr>
      <td>31–33</td>
      <td>Ettin</td>
    </tr>
    <tr>
      <td>34–36</td>
      <td>Fire Giant</td>
    </tr>
    <tr>
      <td>37–39</td>
      <td>Frost Giant</td>
    </tr>
    <tr>
      <td>40–42</td>
      <td>Gnoll Warrior</td>
    </tr>
    <tr>
      <td>43–45</td>
      <td>Goblin Warrior</td>
    </tr>
    <tr>
      <td>46–48</td>
      <td>Guardian Naga</td>
    </tr>
    <tr>
      <td>49–51</td>
      <td>Hill Giant</td>
    </tr>
    <tr>
      <td>52–54</td>
      <td>Hobgoblin Warrior</td>
    </tr>
    <tr>
      <td>55–57</td>
      <td>Incubus</td>
    </tr>
    <tr>
      <td>58–60</td>
      <td>Iron Golem</td>
    </tr>
    <tr>
      <td>61–63</td>
      <td>Knight</td>
    </tr>
    <tr>
      <td>64–66</td>
      <td>Kobold Warrior</td>
    </tr>
    <tr>
      <td>67–69</td>
      <td>Lich</td>
    </tr>
    <tr>
      <td>70–72</td>
      <td>Medusa</td>
    </tr>
    <tr>
      <td>73–75</td>
      <td>Night Hag</td>
    </tr>
    <tr>
      <td>76–78</td>
      <td>Ogre</td>
    </tr>
    <tr>
      <td>79–81</td>
      <td>Oni</td>
    </tr>
    <tr>
      <td>82–84</td>
      <td>Priest</td>
    </tr>
    <tr>
      <td>85–87</td>
      <td>Succubus</td>
    </tr>
    <tr>
      <td>88–90</td>
      <td>Troll</td>
    </tr>
    <tr>
      <td>91–93</td>
      <td>Veteran Warrior</td>
    </tr>
    <tr>
      <td>94–96</td>
      <td>Wyvern</td>
    </tr>
    <tr>
      <td>97–00</td>
      <td>The card drawer</td>
    </tr>
  </tbody>
</table>

\*Stat blocks for these creatures (except the card drawer) appear in "Monsters."

#### Defender

_Weapon (Any Melee Weapon), Legendary (Requires Attunement)_

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon.

The first time you attack with the weapon on each of your turns, you can transfer some or all of the weapon's bonus to your Armor Class. For example, you could reduce the bonus to your attack rolls and damage rolls to +1 and gain a +2 bonus to Armor Class. The adjusted bonuses remain in effect until the start of your next turn, although you must hold the weapon to gain a bonus to AC from it.

#### Demon Armor

_Armor (Any Light, Medium, or Heavy), Very Rare (Requires Attunement)_

While wearing this armor, you gain a +1 bonus to Armor Class, and you know Abyssal. In addition, the armor's clawed gauntlets allow your Unarmed Strikes to deal 1d8 Slashing damage instead of the usual Bludgeoning damage, and you gain a +1 bonus to the attack and damage rolls of your Unarmed Strikes.

_Curse._ Once you don this cursed armor, you can't doff it unless you are targeted by a _Remove Curse_ spell or similar magic. While wearing the armor, you have Disadvantage on attack rolls against demons and on saving throws against their spells and special abilities.

#### Dimensional Shackles

_Wondrous Item, Rare_

You can take a Utilize action to place these shackles on a creature that has the Incapacitated condition. The shackles adjust to fit a creature of Small to Large size. The shackles prevent a creature bound by them from using any method of extradimensional movement, including teleportation or travel to a different plane of existence. They don't prevent the creature from passing through an interdimensional portal.

You and any creature you designate when you use the shackles can take a Utilize action to remove them. Once every 30 days, the bound creature can make a DC 30 Strength (Athletics) check. On a successful check, the creature breaks free and destroys the shackles.

#### Dragon Orb

_Wondrous Item, Artifact (Requires Attunement)_

An orb is an etched crystal globe about 10 inches in diameter. When used, it grows to about 20 inches in diameter, and mist swirls inside it.

While attuned to an orb, you can take a Magic action to peer into the orb's depths. You must then make a DC 15 Charisma saving throw. On a successful save, you control the orb for as long as you remain attuned to it. On a failed save, the orb imposes the Charmed condition on you for as long as you remain attuned to it.

While you are Charmed by the orb, you can't voluntarily end your Attunement to it, and the orb casts _Suggestion_ on you at will (save DC 18), urging you to work toward the evil ends it desires. The dragon essence within the orb might want many things: the annihilation of a particular society or organization, freedom from the orb, to spread suffering in the world, to advance the worship of Tiamat, or something else the GM decides.

_Spells._ The orb has 7 charges and regains 1d4 + 3 expended charges daily at dawn. If you control the orb, you can cast one of the spells on the following table from it. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Cure Wounds (level 9 version)</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Daylight</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Death Ward</td>
      <td>2</td>
    </tr>
    <tr>
      <td>Detect Magic</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Scrying (save DC 18)</td>
      <td>3</td>
    </tr>
  </tbody>
</table>

_Call Dragons._ While you control the orb, you can take a Magic action to cause the orb to issue a telepathic call that extends in all directions for 40 miles. Chromatic dragons in range feel compelled to come to the orb as soon as possible by the most direct route. Dragon deities such as Tiamat are unaffected by this call. Chromatic dragons drawn to the orb might be Hostile toward you for compelling them against their will. Once you have used this property, it can't be used again for 1 hour.

_Destroying an Orb._ A _Dragon Orb_ has AC 20 and is destroyed if it takes damage from a +3 _Weapon_ or a _Disintegrate_ spell. Nothing else can harm it.

#### Dragon Scale Mail

_Armor (Scale Mail), Very Rare (Requires Attunement)_

Dragon Scale Mail is made of the scales of one kind of dragon. Sometimes dragons collect their cast-off
scales and gift them. Other times, hunters carefully preserve the hide of a dead dragon. In either case, _Dragon Scale Mail_ is highly valued.

While wearing this armor, you gain a +1 bonus to Armor Class, you have Advantage on saving throws against the breath weapons of Dragons, and you have Resistance to one damage type determined by the kind of dragon that provided the scales (see the accompanying table).

Additionally, you can focus your senses as a Magic action to discern the distance and direction to the closest dragon within 30 miles of yourself that is of the same type as the armor. This action can't be used again until the next dawn.

<table>
  <thead>
    <tr>
      <th>Dragon</th>
      <th>Resistance</th>
      <th>Dragon</th>
      <th>Resistance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Black</td>
      <td>Acid</td>
      <td>Gold</td>
      <td>Fire</td>
    </tr>
    <tr>
      <td>Blue</td>
      <td>Lightning</td>
      <td>Green</td>
      <td>Poison</td>
    </tr>
    <tr>
      <td>Brass</td>
      <td>Fire</td>
      <td>Red</td>
      <td>Fire</td>
    </tr>
    <tr>
      <td>Bronze</td>
      <td>Lightning</td>
      <td>Silver</td>
      <td>Cold</td>
    </tr>
    <tr>
      <td>Copper</td>
      <td>Acid</td>
      <td>White</td>
      <td>Cold</td>
    </tr>
  </tbody>
</table>

#### Dragon Slayer

_Weapon (Any Simple or Martial), Rare_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon.

The weapon deals an extra 3d6 damage of the weapon's type if the target is a Dragon.

#### Dust of Disappearance

_Wondrous Item, Uncommon_

This powder resembles fine sand. There is enough of it for one use. When you take a Utilize action to throw the dust into the air, you and each creature and object within a 10-foot Emanation originating from you have the Invisible condition for 2d4 minutes. The duration is the same for all subjects, and the dust is consumed when its magic takes effect. Immediately after an affected creature makes an attack roll, deals damage, or casts a spell, the Invisible condition ends for that creature.

#### Dust of Dryness

_Wondrous Item, Uncommon_

This small packet contains 1d6 + 4 pinches of dust. As a Utilize action, you can sprinkle a pinch of the dust over water, turning up to a 15-foot Cube of water into one marble-sized pellet, which floats or rests near where the dust was sprinkled. The pellet's weight is negligible. A creature can take a Utilize action to smash the pellet against a hard surface, causing the pellet to shatter and release the water the dust absorbed. Doing so destroys the pellet and ends its magic.

As a Utilize action, you can sprinkle a pinch of the dust on an Elemental within 5 feet of yourself that is composed mostly of water (such as a **Water Elemental**). Such a creature exposed to a pinch of the dust makes a DC 13 Constitution saving throw, taking 10d6 Necrotic damage on a failed save or half as much damage on a successful one.

#### Dust of Sneezing and Choking

_Wondrous Item, Uncommon_

Found in a small container, this powder resembles _Dust of Disappearance_, and _Identify_ reveals it to be such. There is enough of it for one use.

As a Utilize action, you can throw the dust into the air, forcing yourself and every creature in a 30-foot Emanation originating from you to make a DC 15 Constitution saving throw. Constructs, Elementals, Oozes, Plants, and Undead succeed on the save automatically.

On a failed save, a creature begins sneezing uncontrollably; it has the Incapacitated condition and is suffocating. The creature repeats the save at the end of each of its turns, ending the effect on itself on a success. The effect also ends on any creature targeted by a _Lesser Restoration_ spell.

#### Dwarven Plate

_Armor (Half Plate Armor or Plate Armor), Very Rare_

While wearing this armor, you gain a +2 bonus to Armor Class. In addition, if an effect moves you against your will along the ground, you can take a Reaction to reduce the distance you are moved by up to 10 feet.

#### Dwarven Thrower

_Weapon (Warhammer), Very Rare (Requires Attunement by a Dwarf or a Creature Attuned to a Belt of Dwarvenkind)_

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon. It has the Thrown property with a normal range of 20 feet and a long range of 60 feet. When you hit with a ranged attack using this weapon, it deals an extra 1d8 Force damage, or an extra 2d8 Force damage if the target is a Giant. Immediately after hitting or missing, the weapon flies back to your hand.

#### Efficient Quiver

_Wondrous Item, Uncommon_

Each of the quiver's three compartments connects to an extradimensional space that allows the quiver to hold numerous items while never weighing more than 2 pounds. The shortest compartment can hold up to 60 Arrows, Bolts, or similar objects. The midsize compartment holds up to 18 Javelins or similar objects. The longest compartment holds up to 6 long objects, such as bows, Quarterstaffs, or Spears.

You can draw any item the quiver contains as if doing so from a regular quiver or scabbard.

#### Efreeti Bottle

_Wondrous Item, Very Rare_

When you take a Magic action to remove the stopper of this painted brass bottle, a cloud of thick smoke flows out of it. At the end of your turn, the smoke disappears with a flash of harmless fire, and an **Efreeti** appears in an unoccupied space within 30 feet of you.

The first time the bottle is opened, the GM rolls on the following table to determine what happens.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>The efreeti attacks you. After fighting for 5 rounds, the efreeti disappears, and the bottle loses its magic.</td>
    </tr>
    <tr>
      <td>2–9</td>
      <td>The efreeti understands your languages and obeys your commands for 1 hour, after which it returns to the bottle, and a new stopper contains it. The stopper can't be removed for 24 hours. The next two times the bottle is opened, the same effect occurs. If the bottle is opened a fourth time, the efreeti escapes and disappears, and the bottle loses its magic.</td>
    </tr>
    <tr>
      <td>10</td>
      <td>The efreeti understands your languages and can cast Wish once for you. It disappears when it grants the wish or after 1 hour, and the bottle loses its magic.</td>
    </tr>
  </tbody>
</table>

#### Elemental Gem

_Wondrous Item, Uncommon_

This gem contains a mote of elemental energy. When you take a Utilize action to break the gem, an elemental is summoned (see "Monsters" for its stat block), and the gem ceases to be magical. The elemental appears in an unoccupied space as close to the broken gem as possible, understands your languages, obeys your commands, and takes its turn immediately after you on your Initiative count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The type of gem determines the elemental, as shown in the following table.

<table>
  <thead>
    <tr>
      <th>Gem</th>
      <th>Summoned Elemental</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Blue sapphire</td>
      <td>Air Elemental</td>
    </tr>
    <tr>
      <td>Emerald</td>
      <td>Water Elemental</td>
    </tr>
    <tr>
      <td>Red corundum</td>
      <td>Fire Elemental</td>
    </tr>
    <tr>
      <td>Yellow diamond</td>
      <td>Earth Elemental</td>
    </tr>
  </tbody>
</table>

#### Elixir of Health

_Potion, Rare_

When you drink this potion, you are cured of all magical contagions. In addition, the following conditions end on you: Blinded, Deafened, Paralyzed, and Poisoned.

The clear, red liquid has tiny bubbles of light in it.

#### Elven Chain

_Armor (Chain Mail or Chain Shirt), Rare_

You gain a +1 bonus to Armor Class while you wear this armor. You are considered trained with this armor even if you lack training with Medium or Heavy armor.

#### Energy Bow

_Weapon (Longbow or Shortbow), Very Rare (Requires Attunement)_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon, which has no string. Each time you pull your arm back in a firing motion, a magical arrow made of golden energy appears nocked and ready to fire. An arrow produced by this weapon deals Force damage instead of Piercing damage on a hit, and it disappears after it hits or misses its target. Until it disappears, the arrow emits Bright Light in a 20-foot radius and Dim Light for an additional 20 feet.

This weapon has the following additional properties.

_Arrow of Restraint._ Whenever you use this weapon to make a ranged attack against a creature, you can try to restrain the target instead of dealing damage to it. If the arrow hits, the target must succeed on a DC 15 Strength saving throw or have the Restrained condition for 1 minute. As an action, a creature Restrained by an arrow can make a DC 20 Strength (Athletics) check to try to break the restraint, ending the effect on itself on a successful check.

_Arrow of Transport._ As a Magic action, you can fire one energy arrow from this weapon at a target you can see within 60 feet of yourself. The target can be either a willing Medium or smaller creature or an object that isn't being worn or carried, provided the object is small enough to fit inside a 5-foot Cube. The arrow teleports the target to an unoccupied space you can see within 10 feet of you.

_Energy Ladder._ As a Magic action, you can loose a flurry of energy arrows from this weapon at a wall up to 60 feet away from yourself. The arrows become glowing rungs that stick out of the wall, forming a magical ladder up to 60 feet long on the wall. This ladder lasts for 1 minute before disappearing.

#### Eversmoking Bottle

_Wondrous Item, Uncommon_

As a Magic action, you can open or close this bottle. Opening the bottle causes thick smoke to billow out, forming a cloud that fills a 60-foot Emanation originating from the bottle. The area within the smoke is Heavily Obscured.

Each minute the bottle remains open, the size of the Emanation increases by 10 feet until it reaches its maximum size of 120 feet.
Closing the bottle causes the cloud to become fixed in place until it disperses after 10 minutes. A strong wind (such as that created by the _Gust of Wind_ spell) disperses the cloud after 1 minute.

#### Eyes of Charming

_Wondrous Item, Uncommon (Requires Attunement)_

These crystal lenses fit over the eyes. They have 3 charges. While wearing them, you can expend 1 or more charges to cast _Charm Person_ (save DC 13). For 1 charge, you cast the level 1 version of the spell. You increase the spell's level by one for each additional charge you expend. The lenses regain all expended charges daily at dawn.

#### Eyes of Minute Seeing

_Wondrous Item, Uncommon_

These crystal lenses fit over the eyes. While wearing them, your vision improves significantly out to a range of 1 foot, granting you Darkvision within that range and Advantage on Intelligence (Investigation) checks made to examine something within that range.

#### Eyes of the Eagle

_Wondrous Item, Uncommon_

These crystal lenses fit over the eyes. While wearing them, you have Advantage on Wisdom (Perception) checks that rely on sight. In conditions of clear visibility, you can make out details of even extremely distant creatures and objects as small as 2 feet across.

#### Feather Token

_Wondrous Item, Rarity Varies_

This object looks like a feather. Different types of feather tokens exist, each with a different single-use effect. The GM chooses the kind of token or determines it randomly by rolling on the Feather Tokens table. The type of token determines its rarity.

_Anchor (Uncommon)._ You can take a Magic action to touch the token to a boat or ship. For the next 24 hours, the vessel can't be moved by any means. Touching the token to the vessel again ends the effect. When the effect ends, the token disappears.

_Bird (Rare)._ You can take a Magic action to toss the token 5 feet into the air. The token disappears and an enormous, multicolored bird takes its place. The bird has the statistics of a **Roc**, but it can't attack. It obeys your simple commands and can carry up to 500 pounds while flying at its maximum speed (16 miles per hour for a maximum of 144 miles per day, with a 1-hour rest for every 3 hours of flying) or 1,000 pounds at half that speed. The bird disappears after flying its maximum distance for a day or if it drops to 0 Hit Points. You can dismiss the bird as a Magic action.

_Fan (Uncommon)._ If you are on a boat or ship, you can take a Magic action to toss the token up to 10 feet in the air. The token disappears, and a giant flapping fan takes its place. The fan floats and creates a strong wind. This wind can fill the sails of one ship, increasing its speed by 5 miles per hour for 8 hours. You can dismiss the fan as a Magic action.

_Swan Boat (Rare)._ You can take a Magic action to touch the token to a body of water at least 60 feet in diameter. The token disappears, and a 50-foot-long, 20-foot-wide boat shaped like a swan takes its place. The boat is self-propelled and moves across water at a speed of 6 miles per hour. You can take a Magic action while on the boat to command it to move or to turn up to 90 degrees. The boat remains for 24 hours and then disappears. You can dismiss the boat as a Magic action.

_Tree (Uncommon)._ You must be outdoors to use this token. You can take a Magic action to touch it to an unoccupied space on the ground. The token disappears, and in its place a nonmagical oak tree springs into existence. The tree is 60 feet tall and has a 5-foot-diameter trunk, and its branches at the top spread out in a 20-foot radius.

_Whip (Rare)._ You can take a Magic action to throw the token to a point within 10 feet of yourself. The token disappears, and a floating whip takes its place. You can then take a Bonus Action to make a melee spell attack against a creature within 10 feet of the whip, with an attack bonus of +9. On a hit, the target takes 1d6 + 5 Force damage.

As a Bonus Action, you can direct the whip to fly up to 20 feet and repeat the attack against a creature within 10 feet of the whip. The whip disappears after 1 hour, when you take a Magic action to dismiss it, or when you die or have the Incapacitated condition.

**Feather Tokens**

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Token</th>
      <th>Rarity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–20</td>
      <td>Anchor</td>
      <td>Uncommon</td>
    </tr>
    <tr>
      <td>21–35</td>
      <td>Bird</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>36–50</td>
      <td>Fan</td>
      <td>Uncommon</td>
    </tr>
    <tr>
      <td>51–65</td>
      <td>Swan boat</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>66–90</td>
      <td>Tree</td>
      <td>Uncommon</td>
    </tr>
    <tr>
      <td>91–00</td>
      <td>Whip</td>
      <td>Rare</td>
    </tr>
  </tbody>
</table>

#### Figurine of Wondrous Power

_Wondrous Item, Rarity Varies_

A _Figurine of Wondrous Power_ is a statuette small enough to fit in a pocket. If you take a Magic action to throw the figurine to a point on the ground within 60 feet of yourself, the figurine becomes a living creature specified in the figurine's description below. If the space where the creature would appear is occupied by other creatures or objects, or
if there isn't enough space for the creature, the figurine doesn't become a creature.

The creature is Friendly to you and your allies. It understands your languages, obeys your commands, and takes its turn immediately after you on your Initiative count. If you issue no commands, the creature defends itself but takes no other actions.

The creature exists for a duration specific to each figurine. At the end of the duration, the creature reverts to its figurine form. It reverts to a figurine early if its creature form drops to 0 Hit Points or if you take a Magic action while touching the creature to make it revert to figurine form. When the creature becomes a figurine again, its property can't be used again until a certain amount of time has passed, as specified in the figurine's description.

**Bronze Griffon (Rare).** This bronze statuette is of a griffon rampant. It can become a **Griffon** for up to 6 hours. Once it has been used, it can't be used again until 5 days have passed.

**Ebony Fly (Rare).** This ebony statuette, carved in the likeness of a horsefly, can become a **Giant Fly** (see the accompanying stat block) for up to 12 hours and can be ridden as a mount. Once it has been used, it can't be used again until 2 days have passed.

#### Giant Fly

_Large Beast, Unaligned_

**AC** 11 **Initiative** +1 (11)
**HP** 19 (3d10 + 3)
**Speed** 30 ft., Fly 60 ft.

<table>
  <thead>
    <tr>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th colspan="3"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>STR</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
      <td>DEX</td>
      <td>13</td>
      <td>+1</td>
      <td>+1</td>
      <td>CON</td>
      <td>13</td>
      <td>+1</td>
      <td>+1</td>
    </tr>
    <tr>
      <td>INT</td>
      <td>2</td>
      <td>−4</td>
      <td>−4</td>
      <td>WIS</td>
      <td>10</td>
      <td>+0</td>
      <td>+0</td>
      <td>CHA</td>
      <td>3</td>
      <td>−4</td>
      <td>−4</td>
    </tr>
  </tbody>
</table>

**Senses** Darkvision 60 ft., Passive Perception 10
**Languages** None
**CR** 0 (XP 0; PB +2)

**Golden Lions (Rare).** These gold statuettes of lions are always created in pairs. You can use one figurine or both simultaneously. Each can become a **Lion** for up to 1 hour. Once a lion has been used, it can't be used again until 7 days have passed.

**Ivory Goats (Rare).** These ivory statuettes of goats are always created in sets of three. Each goat looks unique and functions differently from the others. Their properties are as follows:

**Goat of Terror.** This figurine can become a **Giant Goat** for up to 3 hours. The goat can't attack, but you can (harmlessly) remove its horns and use them as weapons. One horn becomes a _+1 Lance_, and the other becomes a _+2 Longsword_. Removing a horn requires a Magic action, and the weapons disappear and the horns return when the goat reverts to figurine form. While you ride the goat, any Hostile creature that starts its turn within

a 30-foot Emanation originating from the goat must succeed on a DC 15 Wisdom saving throw or have the Frightened condition for 1 minute, until you are no longer riding the goat, or until the goat reverts to figurine form. The Frightened creature repeats the save at the end of each of its turns, ending the effect on itself on a success. Once it succeeds on the save, a creature is immune to this effect for the next 24 hours. Once the figurine has been used, it can't be used again until 15 days have passed.

**Goat of Traveling.** This figurine can become a Large goat with the same statistics as a **Riding Horse**. It has 24 charges, and each hour or portion thereof it spends in goat form costs 1 charge. While it has charges, you can use it as often as you wish. When it runs out of charges, it reverts to a figurine and can't be used again until 7 days have passed, when it regains all expended charges.

**Goat of Travail.** This figurine can become a Giant **Goat** for up to 3 hours. Once it has been used, it can't be used again until 30 days have passed.

**Marble Elephant (Rare).** This marble statuette resembles a trumpeting elephant. It can become an **Elephant** for up to 24 hours. Once it has been used, it can't be used again until 7 days have passed.

**Obsidian Steed (Very Rare).** This polished obsidian horse can become a **Nightmare** for up to 24 hours. The nightmare fights only to defend itself. Once it has been used, it can't be used again until 5 days have passed.

The figurine has a 10 percent chance each time you use it to ignore your orders, including a command to revert to figurine form. If you mount the nightmare while it is ignoring your orders, you and the nightmare are instantly transported to a random location on the plane of Hades, where the nightmare reverts to figurine form.

**Onyx Dog (Rare).** This onyx statuette of a dog can become a **Mastiff** for up to 6 hours. The mastiff has an Intelligence of 8 and can speak Common. It also has Blindsight with a range of 60 feet. Once it has been used, it can't be used again until 7 days have passed.

**Serpentine Owl (Rare).** This serpentine statuette of an owl can become a **Giant Owl** for up to 8 hours. The owl can communicate telepathically with you at any range if you and it are on the same plane of existence. Once it has been used, it can't be used again until 2 days have passed.

**Silver Raven (Uncommon).** This silver statuette of a raven can become a **Raven** for up to 12 hours. Once it has been used, it can't be used again until 2 days have passed. While in raven form, the figurine grants you the ability to cast _Animal Messenger_ on it.

#### Flame Tongue

_Weapon (Any Melee Weapon), Rare (Requires Attunement)_

While holding this magic weapon, you can take a Bonus Action and use a command word to cause flames to engulf the damage-dealing part of the weapon. These flames shed Bright Light in a 40-foot radius and Dim Light for an additional 40 feet. While the weapon is ablaze, it deals an extra 2d6 Fire damage on a hit. The flames last until you take a Bonus Action to issue the command again or until you drop, stow, or sheathe the weapon.

#### Folding Boat

_Wondrous Item, Rare_

This object appears as a wooden box that measures 12 inches long, 6 inches wide, and 6 inches deep. It weighs 4 pounds and floats. It can be opened to store items inside. This item also has three command words, each requiring a Magic action to use:

**First Command Word.** The box unfolds into a Rowboat.

**Second Command Word.** The box unfolds into a Keelboat.

**Third Command Word.** The _Folding Boat_ folds back into a box if no creatures are aboard. Any objects in the vessel that can't fit inside the box remain outside the box as it folds. Any objects in the vessel that can fit inside the box do so.

When the box becomes a vessel, its weight becomes that of a normal vessel its size, and anything that was stored in the box remains in the boat.

Statistics for the Rowboat and Keelboat appear in "Equipment." If either vessel is reduced to 0 Hit Points, the _Folding Boat_ is destroyed.

#### Frost Brand

_Weapon (Glaive, Greatsword, Longsword, Rapier, Scimitar, or Shortsword), Very Rare (Requires Attunement)_

When you hit with an attack roll using this magic weapon, the target takes an extra 1d6 Cold damage. In addition, while you hold the weapon, you have Resistance to Fire damage.

In freezing temperatures, the weapon sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet.

When you draw this weapon, you can extinguish all nonmagical flames within 30 feet of yourself. Once used, this property can't be used again for 1 hour.

#### Gauntlets of Ogre Power

_Wondrous Item, Uncommon (Requires Attunement)_

Your Strength is 19 while you wear these gauntlets. They have no effect on you if your Strength is 19 or higher without them.

#### Gem of Brightness

_Wondrous Item, Uncommon_

This prism has 50 charges. While you are holding it, you can take a Magic action and use one of three command words to cause one of the following effects:

**First Command Word.** The gem sheds Bright Light in a 30-foot radius and Dim Light for an additional 30 feet. This effect doesn't expend a charge. It lasts until you take a Bonus Action to repeat the command word or until you use another function of the gem.

**Second Command Word.** You expend 1 charge and cause the gem to fire a brilliant beam of light at one creature you can see within 60 feet of yourself. The creature must succeed on a DC 15 Constitution saving throw or have the Blinded condition for 1 minute. The creature repeats the save at the end of each of its turns, ending the effect on itself on a success.

**Third Command Word.** You expend 5 charges and cause the gem to flare with intense light in a 30-foot Cone. Each creature in the Cone makes a saving throw as if struck by the beam created with the second command word.

When all of the gem's charges are expended, the gem becomes a nonmagical jewel worth 50 GP.

#### Gem of Seeing

_Wondrous Item, Rare (Requires Attunement)_

This gem has 3 charges. As a Magic action, you can expend 1 charge. For the next 10 minutes, you have Truesight out to 120 feet when you peer through the gem.

The gem regains 1d3 expended charges daily at dawn.

#### Giant Slayer

_Weapon (Any Simple or Martial), Rare_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon.

When you hit a Giant with this weapon, the Giant takes an extra 2d6 damage of the weapon's type and must succeed on a DC 15 Strength saving throw or have the Prone condition.

#### Glamoured Studded Leather

_Armor (Studded Leather Armor), Rare_

While wearing this armor, you gain a +1 bonus to Armor Class. You can also take a Bonus Action to
cause the armor to assume the appearance of a normal set of clothing or some other kind of armor. You decide what it looks like—including color, style, and accessories—but the armor retains its normal bulk and weight. The illusory appearance lasts until you use this property again or doff the armor.

#### Gloves of Missile Snaring

_Wondrous Item, Uncommon (Requires Attunement)_

If you're hit by an attack roll made with a Ranged or Thrown weapon while wearing these gloves, you can take a Reaction to reduce the damage by 1d10 plus your Dexterity modifier if you have a free hand. If you reduce the damage to 0, you can catch the ammunition or weapon if it is small enough for you to hold in that hand.

#### Gloves of Swimming and Climbing

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing these gloves, you have a Climb Speed and a Swim Speed equal to your Speed, and you gain a +5 bonus to Strength (Athletics) checks made to climb or swim.

#### Gloves of Thievery

_Wondrous Item, Uncommon_

These gloves are imperceptible while worn. While wearing them, you gain a +5 bonus to Dexterity (Sleight of Hand) checks.

#### Goggles of Night

_Wondrous Item, Uncommon_

While wearing these dark lenses, you have Darkvision out to 60 feet. If you already have Darkvision, wearing the goggles increases its range by 60 feet.

#### Hammer of Thunderbolts

_Weapon (Maul or Warhammer), Legendary (Requires Attunement)_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon.

The weapon has 5 charges. You can expend 1 charge and make a ranged attack with the weapon, hurling it as if it had the Thrown property with a normal range of 20 feet and a long range of 60 feet. If the attack hits, the weapon unleashes a thunderclap audible out to 300 feet. The target and every creature within 30 feet of it other than you must succeed on a DC 17 Constitution saving throw or have the Stunned condition until the end of your next turn. Immediately after hitting or missing, the weapon flies back to your hand. The weapon regains 1d4 + 1 expended charges daily at dawn.

_Giant's Bane._ While you are attuned to the weapon and wearing either a _Belt of Giant Strength_ or _Gauntlets of Ogre Power_ to which you are also attuned, you gain the following benefits:

_Giants' Bane._ When you roll a 20 on the d20 for an attack roll made with this weapon against a Giant, the creature must succeed on a DC 17 Constitution saving throw or die.

_Might of Giants._ The Strength score bestowed by your _Belt of Giant Strength_ or _Gauntlets of Ogre Power_ increases by 4, to a maximum of 30.

#### Handy Haversack

_Wondrous Item, Rare_

This backpack has a central pouch and two side pouches, each of which is an extradimensional space. Each side pouch can hold up to 200 pounds of material, not exceeding a volume of 25 cubic feet. The central pouch can hold up to 500 pounds of material, not exceeding a volume of 64 cubic feet. The haversack always weighs 5 pounds, regardless of its contents.

Retrieving an item from the haversack requires a Utilize action or a Bonus Action (your choice). When you reach into the haversack for a specific item, the item is always magically on top.

If any of its pouches is overloaded, pierced, or torn, the haversack ruptures and is destroyed. If the haversack is destroyed, its contents are lost forever, although an Artifact always turns up again somewhere. If the haversack is turned inside out, its contents spill forth unharmed, and the haversack must be put right before it can be used again.

Each pouch of the haversack holds enough air for 10 minutes of breathing, divided by the number of breathing creatures inside.

Placing the haversack inside an extradimensional space created by a _Bag of Holding_, _Portable Hole_, or similar item instantly destroys both items and opens a gate to the Astral Plane. The gate originates where the one item was placed inside the other. Any creature within 10 feet of the gate and not behind Total Cover is sucked through it and deposited in a random location on the Astral Plane. The gate then closes. The gate is one-way only and can't be reopened.

#### Hat of Disguise

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this hat, you can cast the _Disguise Self_ spell. The spell ends if the hat is removed.

#### Hat of Many Spells

_Wondrous Item, Very Rare (Requires Attunement by a Wizard)_

This pointed hat has the following properties.

_Spellcasting Focus._ While holding the hat, you can use it as a Spellcasting Focus for your Wizard spells. Any spell you cast using the hat gains a special Somatic component: you must reach into the hat and "pull" the spell out of it.
_Unknown Spell._ While holding the hat, you can try to cast a level 1+ spell you don't know. The spell must be on the Wizard spell list, it must be of a level you can cast, and it can't have Material components costing more than 1,000 GP. Once you decide on the spell, you must expend a spell slot of the spell's level. Then, to determine whether you cast the spell, make an Intelligence (Arcana) check (DC 10 plus the spell's level). On a successful check, you cast the spell using its normal casting time, and you can't use this property again until you finish a Short or Long Rest. On a failed check, you fail to cast the spell and a random effect occurs instead, determined by rolling on the following table.

Any spell you cast from the hat uses your spell save DC and spell attack bonus.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–50</td>
      <td>You cast a random spell determined by rolling 1d10: on a **1**, *Enlarge/Reduce* (enlarge effect); on a **2**, *Enlarge/Reduce* (reduce effect); on a **3**, *Faerie Fire*; on a **4**, *Fireball*; on a **5**, *Gust of Wind*; on a **6**, *Invisibility* (cast on yourself); on a **7**, *Lightning Bolt*; on an **8**, *Phantasmal Force*; on a **9**, *Polymorph*; on a **10**, *Stinking Cloud*.</td>
    </tr>
    <tr>
      <td>51–55</td>
      <td>You have the Stunned condition until the end of your next turn, believing something awesome just happened.</td>
    </tr>
    <tr>
      <td>56–60</td>
      <td>A harmless swarm of butterflies fills a 10-foot Cube within 30 feet of yourself. The swarm disperses after 1 minute.</td>
    </tr>
    <tr>
      <td>61–65</td>
      <td>You pull a nonmagical object out of the hat. Roll 1d4 to determine the object: on a **1**, a vial of Acid; on a **2**, a flask of Alchemist's Fire; on a **3**, a Crowbar; on a **4**, a lit Torch.</td>
    </tr>
    <tr>
      <td>66–70</td>
      <td>You suffer a bout of magic sickness and have the Poisoned condition for 1 hour.</td>
    </tr>
    <tr>
      <td>71–75</td>
      <td>You have the Petrified condition until the end of your next turn.</td>
    </tr>
    <tr>
      <td>76–80</td>
      <td>You pull a nonmagical object out of the hat. Roll 1d4 to determine the object: on a **1**, a Dagger; on a **2**, a Rope with a Grappling Hook tied to one end; on a **3**, a bag of Caltrops; on a **4**, a gem worth 50 GP.</td>
    </tr>
    <tr>
      <td>81–85</td>
      <td>A creature appears in an unoccupied space as close to you as possible. The creature isn't under your control and acts as it normally would, and it disappears after 1 hour or when it drops to 0 Hit Points. Roll 1d4 to determine the creature: on a **1**, a **Camel**; on a **2**, a **Constrictor Snake**; on a **3**, an **Elephant**; on a **4**, a **Mule**.</td>
    </tr>
    <tr>
      <td>86–90</td>
      <td>A Hostile **Swarm of Bats** flies out of the hat, occupies your space, and attacks you.</td>
    </tr>
    <tr>
      <td>91–95</td>
      <td>A vertical, 10-foot-diameter, two-way portal to another plane of existence opens in an unoccupied space within 30 feet of you and remains open until the end of your next turn. The GM determines where it leads.</td>
    </tr>
    <tr>
      <td>96–00</td>
      <td>You pull a magic item out of the hat. Roll 1d6 to determine the item's rarity: on a **1–3**, Common; on a **4–5**, Uncommon; on a **6**, Rare. The GM chooses the item, which disappears after 1 hour if it's not consumed or destroyed before then.</td>
    </tr>
  </tbody>
</table>

#### Headband of Intellect

_Wondrous Item, Uncommon (Requires Attunement)_

Your Intelligence is 19 while you wear this headband. It has no effect on you if your Intelligence is 19 or higher without it.

#### Helm of Brilliance

_Wondrous Item, Very Rare (Requires Attunement)_

This helm is set with 1d10 diamonds, 2d10 rubies, 3d10 fire opals, and 4d10 opals. Any gem pried from the helm crumbles to dust. When all the gems are removed or destroyed, the helm loses its magic.

You gain the following benefits while wearing the helm.

_Diamond Light._ As long as it has at least one diamond, the helm emits a 30-foot Emanation. When at least one Undead is within that area, the Emanation is filled with Dim Light. Any Undead that starts its turn in that area takes 1d6 Radiant damage.

_Fire Opal Flames._ As long as the helm has at least one fire opal, you can take a Magic action to cause one weapon you are holding to burst into flames. The flames emit Bright Light in a 10-foot radius and Dim Light for an additional 10 feet. The flames are harmless to you and the weapon. When you hit with an attack using the blazing weapon, the target takes an extra 1d6 Fire damage. The flames last until you take a Bonus Action to extinguish them or until you drop or stow the weapon.

_Ruby Resistance._ As long as the helm has at least one ruby, you have Resistance to Fire damage.

_Spells._ You can cast one of the following spells (save DC 18), using one of the helm's gems of the specified type as a component: _Daylight_ (opal), _Fireball_ (fire opal), _Prismatic Spray_ (diamond), or _Wall of Fire_ (ruby). The gem is destroyed when the spell is cast and disappears from the helm.

_Taking Fire Damage._ Roll 1d20 if you are wearing the helm and take Fire damage as a result of failing
a saving throw against a spell. On a roll of 1, the helm emits beams of light from its remaining gems and is then destroyed. Each creature within a 60-foot Emanation originating from you must succeed on a DC 17 Dexterity saving throw or be struck by a beam, taking Radiant damage equal to the number of gems in the helm.

#### Helm of Comprehending Languages

_Wondrous Item, Uncommon_

While wearing this helm, you can cast _Comprehend Languages_ from it.

#### Helm of Telepathy

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this helm, you have telepathy with a range of 30 feet, and you can cast _Detect Thoughts_ or _Suggestion_ (save DC 13) from the helm. Once either spell is cast from the helm, that spell can't be cast from it again until the next dawn.

#### Helm of Teleportation

_Wondrous Item, Rare (Requires Attunement)_

This helm has 3 charges. While wearing it, you can expend 1 charge to cast _Teleport_ from it. The helm regains 1d3 expended charges daily at dawn.

#### Holy Avenger

_Weapon (Any Simple or Martial), Legendary (Requires Attunement by a Paladin)_

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon. When you hit a Fiend or an Undead with it, that creature takes an extra 2d10 Radiant damage.

While you hold the drawn weapon, it creates a 10-foot Emanation originating from you. You and all creatures Friendly to you in the Emanation have Advantage on saving throws against spells and other magical effects. If you have 17 or more levels in the Paladin class, the size of the Emanation increases to 30 feet.

#### Horn of Blasting

_Wondrous Item, Rare_

You can take a Magic action to blow the horn, which emits a thunderous blast in a 30-foot Cone that is audible out to 600 feet. Each creature in the Cone makes a DC 15 Constitution saving throw. On a failed save, a creature takes 5d8 Thunder damage and has the Deafened condition for 1 minute. On a successful save, a creature takes half as much damage only. Glass or crystal objects in the Cone that aren't being worn or carried take 10d8 Thunder damage.

Each use of the horn's magic has a 20 percent chance of causing the horn to explode. The explosion deals 10d6 Force damage to the user and destroys the horn.

#### Horn of Valhalla

_Wondrous Item, Rare (Silver or Brass), Very Rare (Bronze), or Legendary (Iron)_

You can take a Magic action to blow this horn. In response, warrior spirits from the plane of Ysgard appear in unoccupied spaces within 60 feet of you. Each spirit uses the **Berserker** stat block and returns to Ysgard after 1 hour or when it drops to 0 Hit Points. The spirits look like living, breathing warriors, and they have Immunity to the Charmed and Frightened conditions. Once you use the horn, it can't be used again until 7 days have passed.

Four types of _Horn of Valhalla_ are known to exist, each made of a different metal. The horn's type determines how many spirits it summons, as well as the requirement for its use. The GM chooses the horn's type or determines it randomly by rolling on the following table.

If you blow the horn without meeting its requirement, the summoned spirits attack you. If you meet the requirement, they are Friendly to you and your allies and follow your commands.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Horn Type</th>
      <th>Spirits</th>
      <th>Requirement</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–40</td>
      <td>Silver</td>
      <td>2</td>
      <td>None</td>
    </tr>
    <tr>
      <td>41–75</td>
      <td>Brass</td>
      <td>3</td>
      <td>Proficiency with all Simple weapons</td>
    </tr>
    <tr>
      <td>76–90</td>
      <td>Bronze</td>
      <td>4</td>
      <td>Training with all Medium armor</td>
    </tr>
    <tr>
      <td>91–00</td>
      <td>Iron</td>
      <td>5</td>
      <td>Proficiency with all Martial weapons</td>
    </tr>
  </tbody>
</table>

#### Horseshoes of a Zephyr

_Wondrous Item, Very Rare_

These horseshoes come in a set of four. As a Magic action, you can touch one of the horseshoes to the hoof of a horse or similar creature, whereupon the horseshoe affixes itself to the hoof. Removing a horseshoe also takes a Magic action.

While all four shoes are affixed to the hooves of a horse or similar creature, they allow the creature to move normally while floating 4 inches above a surface. This effect means the creature can cross or stand above nonsolid or unstable surfaces, such as water or lava. The creature leaves no tracks and ignores Difficult Terrain. In addition, the creature can travel for up to 12 hours a day without gaining Exhaustion levels from extended travel.

#### Horseshoes of Speed

_Wondrous Item, Rare_

These horseshoes come in a set of four. As a Magic action, you can touch one of the horseshoes to the hoof of a horse or similar creature, whereupon the horseshoe affixes itself to the hoof. Removing a horseshoe also takes a Magic action.

While all four horseshoes are attached to the same creature, its Speed is increased by 30 feet.

#### Immovable Rod

_Rod, Uncommon_

This iron rod has a button on one end. You can take a Utilize action to press the button, which causes the rod to become magically fixed in place. Until you or another creature takes a Utilize action to push the button again, the rod doesn't move, even if it defies gravity. The rod can hold up to 8,000 pounds of weight. More weight causes the rod to deactivate and fall. A creature can take a Utilize action to make a DC 30 Strength (Athletics) check, moving the fixed rod up to 10 feet on a successful check.

#### Instant Fortress

_Wondrous Item, Rare (Requires Attunement)_

As a Magic action, you can place this 1-inch adamantine statuette on the ground and, using a command word, cause it to grow rapidly into a square adamantine tower. Repeating the command word causes the tower to revert to statuette form, which works only if the tower is empty. Each creature in the area where the tower appears is pushed to an unoccupied space outside but next to the tower. Objects in the area that aren't being worn or carried are also pushed clear of the tower.

The tower is 20 feet on a side and 30 feet high, with arrow slits on all sides and a battlement atop it. Its interior is divided into two floors, with a ladder, staircase, or ramp (your choice) connecting them. This ladder, staircase, or ramp ends at a trapdoor leading to the roof. When created, the tower has a single door at ground level on the side facing you. The door opens only at your command, which you can issue as a Bonus Action. It is immune to the _Knock_ spell and similar magic.

Magic prevents the tower from being tipped over. The roof, the door, and the walls each have AC 20; HP 100; Immunity to Bludgeoning, Piercing, and Slashing damage except that which is dealt by siege equipment; and Resistance to all other damage.

Shrinking the tower back down to statuette form doesn't repair damage to the tower. Only a _Wish_ spell can repair the tower (this use of the spell counts as replicating a spell of level 8 or lower). Each casting of _Wish_ causes the tower to regain all its Hit Points.

#### Ioun Stone

_Wondrous Item, Rarity Varies (Requires Attunement)_

Roughly marble sized, _Ioun Stones_ are named after Ioun, a god of knowledge and prophecy revered on some worlds. Many types of _Ioun Stones_ exist, each type a distinct combination of shape and color.

When you take a Magic action to toss an _Ioun Stone_ into the air, the stone orbits your head at a distance of 1d3 feet, conferring its benefit to you while doing so. You can have up to three _Ioun Stones_ orbiting your head at the same time.

Each _Ioun Stone_ orbiting your head is considered to be an object you are wearing. The orbiting stone avoids contact with other creatures and objects, adjusting its orbit to avoid collisions and thwarting all attempts by other creatures to attack or snatch it.

As a Utilize action, you can seize and stow any number of _Ioun Stones_ orbiting your head. If your Attunement to an _Ioun Stone_ ends while it's orbiting your head, the stone falls as though you had dropped it.

The type of stone determines its rarity and effects.

_Absorption (Very Rare)_. While this pale lavender ellipsoid orbits your head, you can take a Reaction to cancel a spell of level 4 or lower cast by a creature you can see. A canceled spell has no effect, and any resources used to cast it are wasted. Once the stone has canceled 20 levels of spells, it burns out, turns dull gray, and loses its magic.

_Agility (Very Rare)_. Your Dexterity increases by 2, to a maximum of 20, while this deep-red sphere orbits your head.

_Awareness (Rare)_. While this dark-blue rhomboid orbits your head, you have Advantage on Initiative rolls and Wisdom (Perception) checks.

_Fortitude (Very Rare)_. Your Constitution increases by 2, to a maximum of 20, while this pink rhomboid orbits your head.

_Greater Absorption (Legendary)_. While this marbled lavender and green ellipsoid orbits your head, you can take a Reaction to cancel a spell of level 8 or lower cast by a creature you can see. A canceled spell has no effect, and any resources used to cast it are wasted. Once the stone has canceled 20 levels of spells, it burns out, turns dull gray, and loses its magic.

_Insight (Very Rare)_. Your Wisdom increases by 2, to a maximum of 20, while this incandescent blue sphere orbits your head.

_Intellect (Very Rare)_. Your Intelligence increases by 2, to a maximum of 20, while this marbled scarlet and blue sphere orbits your head.

_Leadership (Very Rare)_. Your Charisma increases by 2, to a maximum of 20, while this marbled pink and green sphere orbits your head.
_Mastery (Legendary)._ Your Proficiency Bonus increases by 1 while this pale green prism orbits your head.

_Protection (Rare)._ You gain a +1 bonus to Armor Class while this dusty-rose prism orbits your head.

_Regeneration (Legendary)._ You regain 15 Hit Points at the end of each hour this pearly white spindle orbits your head if you have at least 1 Hit Point.

_Reserve (Rare)._ This vibrant purple prism stores spells cast into it, holding them until you use them. The stone can store up to 4 levels of spells at a time. When found, it contains 1d4 levels of stored spells chosen by the GM.

Any creature can cast a spell of level 1 through 4 into the stone by touching it as the spell is cast. The spell has no effect, other than to be stored in the stone. If the stone can't hold the spell, the spell is expended without effect. The level of the slot used to cast the spell determines how much space it uses.

While this stone orbits your head, you can cast any spell stored in it. The spell uses the slot level, spell save DC, spell attack bonus, and spellcasting ability of the original caster but is otherwise treated as if you cast the spell. The spell cast from the stone is no longer stored in it, freeing up space.

_Strength (Very Rare)._ Your Strength increases by 2, to a maximum of 20, while this pale blue rhomboid orbits your head.

_Sustenance (Rare)._ You don't need to eat or drink while this clear spindle orbits your head.

#### Iron Bands

_Wondrous Item, Rare_

This rusty iron sphere measures 3 inches in diameter and weighs 1 pound. You can take a Magic action to throw the sphere at a Huge or smaller creature you can see within 60 feet of yourself. As the sphere moves through the air, it opens into a tangle of metal bands.

Make a ranged attack roll with an attack bonus equal to your Dexterity modifier plus your Proficiency Bonus. On a hit, the target has the Restrained condition until you take a Bonus Action to issue a command that releases it. Doing so or missing with the attack causes the bands to contract and become a sphere once more.

A creature that can touch the bands, including the one Restrained, can take an action to make a DC 20 Strength (Athletics) check to break the iron bands. On a successful check, the item is destroyed, and the Restrained creature is freed. On a failed check, any further attempts made by that creature automatically fail until 24 hours have elapsed.

Once the bands are used, they can't be used again until the next dawn.

#### Iron Flask

_Wondrous Item, Legendary_

While holding this brass-stoppered iron flask, you can take a Magic action to target a creature that you can see within 60 feet of yourself. If the flask is empty and the target is native to a plane of existence other than the one you're on, the target must succeed on a DC 17 Wisdom saving throw or be trapped in the flask. If the target has been trapped by the flask before, it has Advantage on the save. Once trapped, a creature remains in the flask until released. The flask can hold only one creature at a time. A creature trapped in the flask doesn't age and doesn't need to breathe, eat, or drink.

You can take a Magic action to remove the flask's stopper and release the creature in the flask. The creature then obeys your commands for 1 hour, understanding those commands even if it doesn't know the language in which the commands are given. If you issue no commands or give the creature a command that is likely to result in its death or imprisonment, it defends itself but otherwise takes no actions. At the end of the duration, the creature acts in accordance with its normal disposition and alignment.

An _Identify_ spell reveals if the flask contains a creature, but the only way to determine the type of creature is to open the flask. A newly discovered _Iron Flask_ might already contain a creature chosen by the GM.

#### Javelin of Lightning

_Weapon (Javelin), Uncommon_

Each time you make an attack roll with this magic weapon and hit, you can have it deal Lightning damage instead of Piercing damage.

_Lightning Bolt._ When you throw this weapon at a target no farther than 120 feet from you, you can forgo making a ranged attack roll and instead turn the weapon into a bolt of lightning. This bolt forms a 5-foot-wide Line between you and the target. The target and each other creature in the Line (excluding you) makes a DC 13 Dexterity saving throw, taking 4d6 Lightning damage on a failed save or half as much damage on a successful one. Immediately after dealing this damage, the weapon reappears in your hand. This property can't be used again until the next dawn.

#### Lantern of Revealing

_Wondrous Item, Uncommon_

While lit, this hooded lantern burns for 6 hours on 1 pint of oil, shedding Bright Light in a 30-foot radius and Dim Light for an additional 30 feet. Invisible creatures and objects are visible as long as they are in the lantern's Bright Light. You can take a Utilize
action to lower the hood, reducing the lantern's light to Dim Light in a 5-foot radius.

#### Luck Blade

_Weapon (Glaive, Greatsword, Longsword, Rapier, Scimitar, Sickle, or Shortsword), Legendary (Requires Attunement)_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon. While the weapon is on your person, you also gain a +1 bonus to saving throws.

_Luck._ If the weapon is on your person, you can call on its luck (no action required) to reroll one failed D20 Test if you don't have the Incapacitated condition. You must use the second roll. Once used, this property can't be used again until the next dawn.

_Wish._ The weapon has 1d3 charges. While holding it, you can expend 1 charge and cast _Wish_ from it. Once used, this property can't be used again until the next dawn. The weapon loses this property if it has no charges.

#### Mace of Disruption

_Weapon (Mace), Rare (Requires Attunement)_

When you hit a Fiend or an Undead with this magic weapon, that creature takes an extra 2d6 Radiant damage. If the target has 25 Hit Points or fewer after taking this damage, it must succeed on a DC 15 Wisdom saving throw or be destroyed. On a successful save, the creature has the Frightened condition until the end of your next turn.

_Light._ While you hold this weapon, it sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet.

#### Mace of Smiting

_Weapon (Mace), Rare_

You gain a +1 bonus to attack rolls and damage rolls made with this magic weapon. The bonus increases to +3 when you use the weapon to attack a Construct.

When you roll a 20 on an attack roll made with this weapon, the target takes an extra 7 Bludgeoning damage, or 14 Bludgeoning damage if it's a Construct. If a Construct has 25 Hit Points or fewer after taking this damage, it is destroyed.

#### Mace of Terror

_Weapon (Mace), Rare (Requires Attunement)_

This magic weapon has 3 charges and regains 1d3 expended charges daily at dawn. While holding the weapon, you can take a Magic action and expend 1 charge to release a wave of terror from it. Each creature of your choice within 30 feet of you must succeed on a DC 15 Wisdom saving throw or have the Frightened condition for 1 minute. While

Frightened in this way, a creature must spend its turns trying to move as far away from you as it can, and it can't make Opportunity Attacks. For its action, it can use only the Dash action or try to escape from an effect that prevents it from moving. If it has nowhere it can move, the creature can take the Dodge action. At the end of each of its turns, a creature repeats the save, ending the effect on itself on a success.

#### Mantle of Spell Resistance

_Wondrous Item, Rare (Requires Attunement)_

You have Advantage on saving throws against spells while you wear this cloak.

#### Manual of Bodily Health

_Wondrous Item, Very Rare_

This book contains health and nutrition tips, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Constitution increases by 2, to a maximum of 30. The manual then loses its magic but regains it in a century.

#### Manual of Gainful Exercise

_Wondrous Item, Very Rare_

This book describes fitness exercises, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Strength increases by 2, to a maximum of 30. The manual then loses its magic but regains it in a century.

#### Manual of Golems

_Wondrous Item, Very Rare_

This tome contains information and incantations necessary to make a particular type of golem. The GM chooses the type or determines it randomly by rolling on the accompanying table. To decipher and use the manual, you must be a spellcaster with at least two level 5 spell slots. A creature that can't use a _Manual of Golems_ and attempts to read it takes 6d6 Psychic damage.

To create a golem, you must spend the time shown on the table, working without interruption with the manual at hand and resting no more than 8 hours per day. You must also pay the specified cost to purchase supplies.

Once you finish creating the golem, the book is consumed in eldritch flames. The golem becomes animate when the ashes of the manual are sprinkled on it. See "Monsters" for the golem's stat block. The golem is under your control, and it understands and obeys your commands.

<table>
  <thead>
    <tr>
      <th>1d20</th>
      <th>Golem</th>
      <th>Time</th>
      <th>Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1–5</td>
      <td>Clay Golem</td>
      <td>30 days</td>
      <td>65,000 GP</td>
    </tr>
    <tr>
      <td>6–17</td>
      <td>Flesh Golem</td>
      <td>60 days</td>
      <td>50,000 GP</td>
    </tr>
    <tr>
      <td>18</td>
      <td>Iron Golem</td>
      <td>120 days</td>
      <td>100,000 GP</td>
    </tr>
    <tr>
      <td>19–20</td>
      <td>Stone Golem</td>
      <td>90 days</td>
      <td>80,000 GP</td>
    </tr>
  </tbody>
</table>

#### Manual of Quickness of Action

_Wondrous Item, Very Rare_

This book contains coordination and balance exercises, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Dexterity increases by 2, to a maximum of 30. The manual then loses its magic but regains it in a century.

#### Marvelous Pigments

_Wondrous Item, Very Rare_

This fine wooden box contains 1d4 pots of pigment and a brush (weighing 1 pound in total).

Using the brush and expending 1 pot of pigment, you can paint any number of three-dimensional objects and terrain features (such as walls, doors, trees, flowers, weapons, webs, and pits), provided these elements are all confined to a 20-foot Cube. The effort takes 10 minutes (regardless of the number of elements you create), during which time you must remain in the Cube, and requires Concentration. If your Concentration is broken or you leave the Cube before the work is done, all the painted elements vanish, and the pot of pigment is wasted.

When the work is done, all the painted objects and terrain features become real. Thus, painting a door on a wall creates an actual door, which can be opened to whatever is beyond. Painting a pit creates a real pit, the entire depth of which must lie within the 20-foot Cube.

No object created by a pot of pigment can have a value greater than 25 GP, and the total value of all objects created by a pot of pigment can't exceed 500 GP. If you paint objects of greater value (such as a large pile of gold), they look authentic, but close inspection reveals they're made from paste, cookies, or some other worthless material.

If you paint a form of energy such as fire or lightning, the energy dissipates as soon as you complete the painting, doing no harm.

#### Medallion of Thoughts

_Wondrous Item, Uncommon (Requires Attunement)_

The medallion has 5 charges. While wearing it, you can expend 1 charge to cast _Detect Thoughts_ (save DC 13) from it. The medallion regains 1d4 expended charges daily at dawn.

#### Mirror of Life Trapping

_Wondrous Item, Very Rare_

When this 4-foot-tall, 2-foot-wide mirror is viewed indirectly, its surface shows faint images of creatures. The mirror weighs 50 pounds, and it has AC 11, HP 10, Immunity to Poison and Psychic damage, and Vulnerability to Bludgeoning damage. It shatters and is destroyed when reduced to 0 Hit Points.

If the mirror is hanging on a vertical surface and you are within 5 feet of it, you can take a Magic action and use a command word to activate it. It remains activated until you take a Magic action and repeat the command word to deactivate it.

Any creature other than you that sees its reflection in the activated mirror while within 30 feet of the mirror must succeed on a DC 15 Charisma saving throw or be trapped, along with anything it is wearing or carrying, in one of the mirror's twelve extradimensional cells. A creature that knows the mirror's nature makes the save with Advantage, and Constructs succeed on the save automatically.

An extradimensional cell is an infinite expanse filled with thick fog that reduces visibility to 10 feet. Creatures trapped in the mirror's cells don't age, and they don't need to eat, drink, or sleep. A creature trapped within a cell can escape using magic that permits planar travel. Otherwise, the creature is confined to the cell until freed.

If the mirror traps a creature but its twelve extradimensional cells are already occupied, the mirror frees one trapped creature at random to accommodate the new prisoner. A freed creature appears in an unoccupied space within sight of the mirror but facing away from it. If the mirror is shattered, all creatures it contains are freed and appear in unoccupied spaces near it.

While within 5 feet of the mirror, you can take a Magic action to name one creature trapped in it or call out a particular cell by number. The creature named or contained in the named cell appears as an image on the mirror's surface. You and the creature can then communicate.

In a similar way, you can take a Magic action and use a second command word to free one creature trapped in the mirror. The freed creature appears, along with its possessions, in the unoccupied space nearest to the mirror and facing away from it.

Placing the mirror inside an extradimensional space created by a _Bag of Holding_, _Portable Hole_, or similar item instantly destroys both items and opens a gate to the Astral Plane. The gate originates where the one item was placed inside the other. Any creature within 10 feet of the gate and not behind Total Cover is sucked through it to a random location on the Astral Plane. The gate then closes. The gate is one-way only and can't be reopened.

#### Mithral Armor

_Armor (Any Medium or Heavy, Except Hide Armor), Uncommon_

Mithral is a light, flexible metal. Armor made of this substance can be worn under normal clothes. If the armor normally imposes Disadvantage on Dexterity (Stealth) checks or has a Strength requirement, the mithral version of the armor doesn't.

#### Mysterious Deck

_Wondrous Item, Legendary_

Usually found in a box or pouch, this deck contains a number of cards made of ivory or vellum. Most (75 percent) of these decks have thirteen cards, but some have twenty-two. Use the appropriate column of the Mysterious Deck table when randomly determining cards drawn from the deck.

Before you draw a card, you must declare how many cards you intend to draw and then draw them randomly. Any cards drawn in excess of this number have no effect. Otherwise, as soon as you draw a card from the deck, its magic takes effect. You must draw each card no more than 1 hour after the previous draw. If you fail to draw the chosen number, the remaining number of cards fly from the deck on their own and take effect all at once.

Once a card is drawn, it disappears. Unless the card is the Fool or Jester, the card reappears in the deck, making it possible to draw the same card twice. (Once the Fool or Jester has left the deck, reroll on the table if that card comes up again.)

**Mysterious Deck**

<table>
  <thead>
    <tr>
      <th>1d100 (13-Card Deck)</th>
      <th>1d100 (22-Card Deck)</th>
      <th>Card</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>—</td>
      <td>01–05</td>
      <td>Balance</td>
    </tr>
    <tr>
      <td>—</td>
      <td>06–10</td>
      <td>Comet</td>
    </tr>
    <tr>
      <td>—</td>
      <td>11–14</td>
      <td>Donjon</td>
    </tr>
    <tr>
      <td>01–08</td>
      <td>15–18</td>
      <td>Euryale</td>
    </tr>
    <tr>
      <td>—</td>
      <td>19–23</td>
      <td>Fates</td>
    </tr>
    <tr>
      <td>09–16</td>
      <td>24–27</td>
      <td>Flames</td>
    </tr>
    <tr>
      <td>—</td>
      <td>28–31</td>
      <td>Fool</td>
    </tr>
    <tr>
      <td>—</td>
      <td>32–36</td>
      <td>Gem</td>
    </tr>
    <tr>
      <td>17–24</td>
      <td>37–41</td>
      <td>Jester</td>
    </tr>
    <tr>
      <td>25–32</td>
      <td>42–46</td>
      <td>Key</td>
    </tr>
    <tr>
      <td>33–40</td>
      <td>47–51</td>
      <td>Knight</td>
    </tr>
    <tr>
      <td>41–48</td>
      <td>52–56</td>
      <td>Moon</td>
    </tr>
    <tr>
      <td>—</td>
      <td>57–60</td>
      <td>Puzzle</td>
    </tr>
    <tr>
      <td>49–56</td>
      <td>61–64</td>
      <td>Rogue</td>
    </tr>
    <tr>
      <td>57–64</td>
      <td>65–68</td>
      <td>Ruin</td>
    </tr>
    <tr>
      <td>—</td>
      <td>69–73</td>
      <td>Sage</td>
    </tr>
  </tbody>
</table>

<table>
  <thead>
    <tr>
      <th>1d100 (13-Card Deck)</th>
      <th>1d100 (22-Card Deck)</th>
      <th>Card</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>65–72</td>
      <td>74–77</td>
      <td>Skull</td>
    </tr>
    <tr>
      <td>73–80</td>
      <td>78–82</td>
      <td>Star</td>
    </tr>
    <tr>
      <td>81–88</td>
      <td>83–87</td>
      <td>Sun</td>
    </tr>
    <tr>
      <td>—</td>
      <td>88–91</td>
      <td>Talons</td>
    </tr>
    <tr>
      <td>89–96</td>
      <td>92–96</td>
      <td>Throne</td>
    </tr>
    <tr>
      <td>97–00</td>
      <td>97–00</td>
      <td>Void</td>
    </tr>
  </tbody>
</table>

Each card's effect is described below.

_Balance._ You can increase one of your ability scores by 2, to a maximum of 22, provided you also decrease another one of your ability scores by 2. You can't decrease an ability that has a score of 5 or lower. Alternatively, you can choose not to adjust your ability scores, in which case this card has no effect.

_Comet._ The next time you enter combat against one or more Hostile creatures, you can select one of them as your foe when you roll Initiative. If you reduce your foe to 0 Hit Points during that combat, you have Advantage on Death Saving Throws for 1 year. If someone else reduces your chosen foe to 0 Hit Points or you don't choose a foe, this card has no effect.

_Donjon._ You disappear and become entombed in a state of suspended animation in an extradimensional sphere. Everything you're wearing and carrying disappears with you except for Artifacts, which stay behind in the space you occupied when you disappeared. You remain imprisoned until you are found and removed from the sphere. You can't be located by any Divination magic, but a _Wish_ spell can reveal the location of your prison. You draw no more cards.

_Euryale._ The card's medusa-like visage curses you. You take a −2 penalty to saving throws while cursed in this way. Only a god or the magic of the Fates card can end this curse.

_Fates._ Reality's fabric unravels and spins anew, allowing you to avoid or erase one event as if it never happened. You can use the card's magic as soon as you draw the card or at any other time before you die.

_Flames._ A powerful devil becomes your enemy. The devil seeks your ruin and torments you, savoring your suffering before attempting to slay you. This enmity lasts until either you or the devil dies.

_Fool._ You have Disadvantage on D20 Tests for the next 72 hours. Draw another card; this draw doesn't count as one of your declared draws.

_Gem._ Twenty-five pieces of jewelry worth 2,000 GP each or fifty gems worth 1,000 GP each appear at your feet.

_Jester._ You have Advantage on D20 Tests for the next 72 hours, or you can draw two additional cards beyond your declared draws.

_Key._ A Rare or rarer magic weapon with which you are proficient appears on your person. The GM chooses the weapon.

_Knight._ You gain the service of a **Knight**, who magically appears in an unoccupied space you choose within 30 feet of yourself. The knight has the same alignment as you and serves you loyally until death, believing the two of you have been drawn together by fate. Work with your GM to create a name and backstory for this NPC. The GM can use a different stat block to represent the knight, as desired.

_Moon._ You gain the ability to cast _Wish_ 1d3 times.

_Puzzle._ Permanently reduce your Intelligence or Wisdom by 1d4 + 1 (to a minimum score of 1). You can draw one additional card beyond your declared draws.

_Rogue._ An NPC of the GM's choice becomes Hostile toward you. You don't know the identity of this NPC until they or someone else reveals it. Nothing less than a _Wish_ spell or divine intervention can end the NPC's hostility toward you.

_Ruin._ All forms of wealth that you carry or own, other than magic items, are lost to you. Portable property vanishes. Businesses, buildings, and land you own are lost in a way that alters reality the least. Any documentation that proves you should own something lost to this card also disappears.

_Sage._ At any time you choose within one year of drawing this card, you can ask a question in meditation and mentally receive a truthful answer to that question.

_Skull._ An **Avatar of Death** (see the accompanying stat block) appears in an unoccupied space as close to you as possible. The avatar targets only you with its attacks, appearing as a ghostly skeleton clad in a tattered black robe and carrying a spectral scythe. The avatar disappears when it drops to 0 Hit Points or you die. If an ally of yours deals damage to the avatar, that ally summons another **Avatar of Death**. The new avatar appears in an unoccupied space as close to that ally as possible and targets only that ally with its attacks. You and your allies can each summon only one avatar as a consequence of this draw. A creature slain by an avatar can't be restored to life.

_Star._ Increase one of your ability scores by 2, to a maximum of 24.

_Sun._ A magic item (chosen by the GM) appears on your person. In addition, you gain 10 Temporary Hit Points daily at dawn until you die.

_Talons._ Every magic item you wear or carry disintegrates. Artifacts in your possession vanish instead.

_Throne._ You gain proficiency and Expertise in your choice of History, Insight, Intimidation, or Persuasion. In addition, you gain rightful ownership of a small keep somewhere in the world. However, the keep is currently home to one or more monsters, which must be cleared out before you can claim the keep as yours.

_Void._ Your soul is drawn from your body and contained in an object in a place of the GM's choice. One or more powerful beings guard the place. While your soul is trapped in this way, your body is inert, ceases aging, and requires no food, air, or water. A _Wish_ spell can't return your soul to your body, but the spell reveals the location of the object that holds your soul. You draw no more cards.

#### Avatar of Death

_Medium Undead, Neutral Evil_

**AC** 20 **Initiative** +3 (13) <br>
**HP** Half the HP maximum of its summoner <br>
**Speed** 60 ft., Fly 60 ft. (hover) <br>

<table>
  <thead>
    <tr>
      <th></th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><strong>STR</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
      <td><strong>DEX</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
      <td><strong>CON</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
    </tr>
    <tr>
      <td><strong>INT</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
      <td><strong>WIS</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
      <td><strong>CHA</strong></td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
    </tr>
  </tbody>
</table>

**Immunities** Necrotic, Poison; Charmed, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned, Unconscious<br>
**Senses** Truesight 60 ft., Passive Perception 13<br>
**Languages** All languages known to its summoner<br>
**CR** None (XP 0; PB equals its summoner's)

### Traits

<hr>

**_Incorporeal Movement._** The avatar can move through other creatures and objects as if they were Difficult Terrain. It takes 5 (1d10) Force damage if it ends its turn inside an object.

### Actions

<hr>

**_Multiattack._** The avatar makes a number of Reaping Scythe attacks equal to half the summoner's Proficiency Bonus (rounded up).

**_Reaping Scythe._** _Melee Attack Roll:_ Automatic hit, reach 5 ft. _Hit:_ 7 (1d8 + 3) Slashing damage plus 4 (1d8) Necrotic damage.

#### Necklace of Adaptation

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this necklace, you can breathe normally in any environment, and you have Advantage on saving throws made to avoid or end the Poisoned condition.

#### Necklace of Fireballs

_Wondrous Item, Rare_

This necklace has 1d6 + 3 beads hanging from it. You can take a Magic action to detach a bead and throw it up to 60 feet away. When it reaches the end of its trajectory, the bead detonates as a level 3 _Fireball_ (save DC 15).

You can hurl multiple beads, or even the whole necklace, at one time. When you do so, increase the damage of the _Fireball_ by 1d6 for each bead after the first (maximum 12d6).

#### Necklace of Prayer Beads

_Wondrous Item, Rare (Requires Attunement by a Cleric, Druid, or Paladin)_

This necklace has 1d4 + 2 magic beads made from aquamarine, black pearl, or topaz. It also has many nonmagical beads made from stones such as amber, bloodstone, citrine, coral, jade, pearl, or quartz. If a magic bead is removed from the necklace, that bead loses its magic.

Six types of magic beads exist. The GM decides the type of each bead on the necklace or determines it randomly by rolling on the table below. A necklace can have more than one bead of the same type. To use one, you must be wearing the necklace. Each bead contains a spell that you can cast from it as a Bonus Action (using your spell save DC if a save is necessary). Once a magic bead's spell is cast, that bead can't be used again until the next dawn.

<table>
  <thead>
    <tr>
      <th>1d20</th>
      <th>Bead</th>
      <th>Spell</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1–6</td>
      <td>Bead of Blessing</td>
      <td>Bless</td>
    </tr>
    <tr>
      <td>7–12</td>
      <td>Bead of Curing</td>
      <td>Cure Wounds (level 2 version)</td>
    </tr>
    <tr>
      <td>13–16</td>
      <td>Bead of Favor</td>
      <td>Greater Restoration</td>
    </tr>
    <tr>
      <td>17–18</td>
      <td>Bead of Smiting</td>
      <td>Shining Smite</td>
    </tr>
    <tr>
      <td>19</td>
      <td>Bead of Summons</td>
      <td>Guardian of Faith</td>
    </tr>
    <tr>
      <td>20</td>
      <td>Bead of Wind Walking</td>
      <td>Wind Walk</td>
    </tr>
  </tbody>
</table>

#### Nine Lives Stealer

_Weapon (Any Simple or Martial), Very Rare (Requires Attunement)_

You gain a +2 bonus to attack rolls and damage rolls made with this magic weapon.

**_Life Stealing._** The weapon has 1d8 + 1 charges. When you attack a creature that has fewer than 100 Hit Points with this weapon and roll a 20 on the d20 for the attack roll, the creature must succeed on a DC 15 Constitution saving throw or be slain instantly as the sword tears its life force from its body. Constructs and Undead succeed on the save automatically. The weapon loses 1 charge if the creature is slain. When the weapon has no charges remaining, it loses this property.

#### Oathbow

_Weapon (Longbow or Shortbow), Very Rare (Requires Attunement)_

When you nock an arrow on this bow, it whispers in Elvish, "Swift defeat to my enemies." When you use this weapon to make a ranged attack, you can utter or sign the following command words: "Swift death to you who have wronged me." The target of your attack becomes your sworn enemy until it dies or until dawn 7 days later. You can have only one such sworn enemy at a time. When your sworn enemy dies, you can choose a new one after the next dawn.

When you make a ranged attack roll with this weapon against your sworn enemy, you have Advantage on the roll. In addition, your target gains no benefit from Half Cover or Three-Quarters Cover, and you suffer no Disadvantage due to long range. If the attack hits, your sworn enemy takes an extra 3d6 Piercing damage.

While your sworn enemy lives, you have Disadvantage on attack rolls with all other weapons.

#### Oil of Etherealness

_Potion, Rare_

One vial of this oil can cover one Medium or smaller creature, along with the equipment it's wearing and carrying (one additional vial is required for each size category above Medium). Applying the oil takes 10 minutes. The affected creature then gains the effect of the _Etherealness_ spell for 1 hour.

Beads of this cloudy, gray oil form on the outside of its container and quickly evaporate.

#### Oil of Sharpness

_Potion, Very Rare_

One vial of this oil can coat one Melee weapon or twenty pieces of ammunition, but only ammunition and Melee weapons that are nonmagical and deal Slashing or Piercing damage are affected. Applying the oil takes 1 minute, after which the oil magically seeps into whatever it coats, turning the coated weapon into a _+3 Weapon_ or the coated ammunition into _+3 Ammunition_.

This clear, gelatinous oil sparkles with tiny, ultrathin silver shards.

#### Oil of Slipperiness

_Potion, Uncommon_

One vial of this oil can cover one Medium or smaller creature, along with the equipment it's wearing and carrying (one additional vial is required for each size category above Medium). Applying the oil takes 10 minutes. The affected creature then gains the effect of the _Freedom of Movement_ spell for 8 hours.

Alternatively, the oil can be poured on the ground as a Magic action, where it covers a 10-foot square, duplicating the effect of the _Grease_ spell in that area for 8 hours.

This sticky, black unguent is thick and heavy, but it flows quickly when poured.

#### Pearl of Power

_Wondrous Item, Uncommon (Requires Attunement by a Spellcaster)_

While this pearl is on your person, you can take a Magic action to regain one expended spell slot of level 3 or lower. Once you use the pearl, it can't be used again until the next dawn.

#### Periapt of Health

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this pendant, you can take a Magic action to regain 2d4 + 2 Hit Points. Once used, this property can't be used again until the next dawn.

In addition, you have Advantage on saving throws to avoid or end the Poisoned condition while you wear this pendant.

#### Periapt of Proof against Poison

_Wondrous Item, Rare (Requires Attunement)_

This delicate silver chain has a brilliant-cut black gem pendant. While you wear it, you have Immunity to the Poisoned condition and Poison damage.

#### Periapt of Wound Closure

_Wondrous Item, Uncommon (Requires Attunement)_

While wearing this pendant, you gain the following benefits.

**_Life Preservation._** Whenever you make a Death Saving Throw, you can change a roll of 9 or lower to a 10, turning a failed save into a successful one.

**_Natural Healing Boost._** Whenever you roll a Hit Point Die to regain Hit Points, double the number of Hit Points it restores.

#### Philter of Love

_Potion, Uncommon_

The next time you see a creature within 10 minutes after drinking this philter, you are charmed by that creature and have the Charmed condition for 1 hour.

This rose-hued, effervescent liquid contains one easy-to-miss bubble shaped like a heart.

#### Pipes of Haunting

_Wondrous Item, Uncommon_

These pipes have 3 charges and regain 1d3 expended charges daily at dawn. You can take a Magic action to play them and expend 1 charge to create an eerie, spellbinding tune. Each creature of your choice within 30 feet of you must succeed on a DC 15 Wisdom saving throw or have the Frightened condition for 1 minute. A creature that fails the save repeats it at the end of each of its turns, ending the effect on itself on a success. A creature that succeeds on its save is immune to the effect of these pipes for 24 hours.

#### Pipes of the Sewers

_Wondrous Item, Uncommon (Requires Attunement)_

While these pipes are on your person, ordinary rats and giant rats are Indifferent toward you and won't attack you unless you threaten or harm them.

The pipes have 3 charges and regain 1d3 expended charges daily at dawn. If you play the pipes as a Magic action, you can take a Bonus Action to expend 1 to 3 charges, calling forth one Swarm of Rats with each expended charge if enough rats are within half a mile of you to be called in this fashion (as determined by the GM). If there aren't enough rats to form a swarm, the charge is wasted. Called swarms move toward the music by the shortest available route but aren't under your control otherwise.

Whenever a Swarm of Rats that isn't under another creature's control comes within 30 feet of you while you are playing the pipes, the swarm makes a DC 15 Wisdom saving throw. On a successful save, the swarm behaves as it normally would and can't be swayed by the pipes' music for the next 24 hours. On a failed save, the swarm is swayed by the pipes' music and becomes Friendly to you and your allies for as long as you continue to play the pipes each round as a Magic action. A Friendly swarm obeys your commands. If you issue no commands to a Friendly swarm, it defends itself but otherwise takes no actions. If a Friendly swarm starts its turn more than 30 feet away from you, your control over that swarm ends, and the swarm behaves as it normally would and can't be swayed by the pipes' music for the next 24 hours.

#### Plate Armor of Etherealness

_Armor (Half Plate Armor or Plate Armor), Legendary (Requires Attunement)_

While you're wearing this armor, you can take a Magic action and use a command word to gain the effect of the _Etherealness_ spell. The spell ends immediately if you remove the armor or take a Magic action to repeat the command word. This property of the armor can't be used again until the next dawn.

#### Portable Hole

_Wondrous Item, Rare_

This fine black cloth, soft as silk, is folded up to the dimensions of a handkerchief. It unfolds into a circular sheet 6 feet in diameter.

You can take a Magic action to unfold a _Portable Hole_ and place it on or against a solid surface, whereupon the _Portable Hole_ creates an
extradimensional hole 10 feet deep. The cylindrical space within the hole exists on a different plane of existence, so it can't be used to create open passages. Any creature inside an open _Portable Hole_ can exit the hole by climbing out of it.

You can take a Magic action to close a _Portable Hole_ by taking hold of the edges of the cloth and folding it up. Folding the cloth closes the hole, and any creatures or objects within remain in the extradimensional space. No matter what's in it, the hole weighs next to nothing.

If the hole is folded up, a creature within the hole's extradimensional space can take an action to make a DC 10 Strength (Athletics) check. On a successful check, the creature forces its way out and appears within 5 feet of the _Portable Hole_. A closed _Portable Hole_ holds enough air for 1 hour of breathing, divided by the number of breathing creatures inside.

Placing a _Portable Hole_ inside an extradimensional space created by a _Bag of Holding_, _Handy Haversack_, or similar item instantly destroys both items and opens a gate to the Astral Plane. The gate originates where the one item was placed inside the other. Any creature within 10 feet of the gate and not behind Total Cover is sucked through it and deposited in a random location on the Astral Plane. The gate then closes. The gate is one-way only and can't be reopened.

#### Potion of Animal Friendship

_Potion, Uncommon_

When you drink this potion, you can cast the level 3 version of the _Animal Friendship_ spell (save DC 13).

Agitating this potion's muddy liquid brings little bits into view: a fish scale, a hummingbird feather, a cat claw, or a squirrel hair.

#### Potion of Clairvoyance

_Potion, Rare_

When you drink this potion, you gain the effect of the _Clairvoyance_ spell (no Concentration required).

An eyeball bobs in this potion's yellowish liquid but vanishes when the potion is opened.

#### Potion of Climbing

_Potion, Common_

When you drink this potion, you gain a Climb Speed equal to your Speed for 1 hour. During this time, you have Advantage on Strength (Athletics) checks to climb.

This potion is separated into brown, silver, and gray layers resembling bands of stone. Shaking the bottle fails to mix the colors.

#### Potion of Diminution

_Potion, Rare_

When you drink this potion, you gain the "reduce" effect of the _Enlarge/Reduce_ spell for 1d4 hours (no Concentration required).

The red in the potion's liquid continuously contracts to a tiny bead and then expands to color the clear liquid around it. Shaking the bottle fails to interrupt this process.

#### Potion of Flying

_Potion, Very Rare_

When you drink this potion, you gain a Fly Speed equal to your Speed for 1 hour and can hover. If you're in the air when the potion wears off, you fall unless you have some other means of staying aloft.

This potion's clear liquid floats at the top of its container and has cloudy white impurities drifting in it.

#### Potion of Gaseous Form

_Potion, Rare_

When you drink this potion, you gain the effect of the _Gaseous Form_ spell for 1 hour (no Concentration required) or until you end the effect as a Bonus Action.

This potion's container seems to hold fog that moves and pours like water.

#### Potion of Giant Strength

_Potion, Rarity Varies_

When you drink this potion, your Strength score changes for 1 hour. The type of giant determines the score (see the table below). The potion has no effect on you if your Strength is equal to or greater than that score.

This potion's transparent liquid has floating in it a sliver of light resembling a giant's fingernail.

<table>
  <thead>
    <tr>
      <th>Potion</th>
      <th>Str.</th>
      <th>Rarity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Potion of Giant Strength (hill)</td>
      <td>21</td>
      <td>Uncommon</td>
    </tr>
    <tr>
      <td>Potion of Giant Strength (frost or stone)</td>
      <td>23</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>Potion of Giant Strength (fire)</td>
      <td>25</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>Potion of Giant Strength (cloud)</td>
      <td>27</td>
      <td>Very Rare</td>
    </tr>
    <tr>
      <td>Potion of Giant Strength (storm)</td>
      <td>29</td>
      <td>Legendary</td>
    </tr>
  </tbody>
</table>

#### Potion of Growth

_Potion, Uncommon_

When you drink this potion, you gain the "enlarge" effect of the _Enlarge/Reduce_ spell for 10 minutes (no Concentration required).

The red in the potion's liquid continuously expands from a tiny bead to color the clear liquid around it and then contracts. Shaking the bottle fails to interrupt this process.

#### Potions of Healing

_Potion, Rarity Varies_

You regain Hit Points when you drink this potion. The number of Hit Points depends on the potion's rarity, as shown in the table below.

Whatever its potency, the potion's red liquid glimmers when agitated.

<table>
  <thead>
    <tr>
      <th>Potion</th>
      <th>HP Regained</th>
      <th>Rarity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Potion of Healing</td>
      <td>2d4 + 2</td>
      <td>Common</td>
    </tr>
    <tr>
      <td>Potion of Healing (greater)</td>
      <td>4d4 + 4</td>
      <td>Uncommon</td>
    </tr>
    <tr>
      <td>Potion of Healing (superior)</td>
      <td>8d4 + 8</td>
      <td>Rare</td>
    </tr>
    <tr>
      <td>Potion of Healing (supreme)</td>
      <td>10d4 + 20</td>
      <td>Very Rare</td>
    </tr>
  </tbody>
</table>

#### Potion of Heroism

_Potion, Rare_

When you drink this potion, you gain 10 Temporary Hit Points that last for 1 hour. For the same duration, you are under the effect of the _Bless_ spell (no Concentration required).

This potion's blue liquid bubbles and steams as if boiling.

#### Potion of Invisibility

_Potion, Rare_

This potion's container looks empty but feels as though it holds liquid. When you drink the potion, you have the Invisible condition for 1 hour. The effect ends early if you make an attack roll, deal damage, or cast a spell.

#### Potion of Invulnerability

_Potion, Rare_

For 1 minute after you drink this potion, you have Resistance to all damage.

This potion's syrupy liquid looks like liquefied iron.

#### Potion of Longevity

_Potion, Very Rare_

When you drink this potion, your physical age is reduced by 1d6 + 6 years, to a minimum of 13 years. Each time you subsequently drink a _Potion of Longevity_, there is 10 percent cumulative chance that you instead age by 1d6 + 6 years.

Suspended in this amber liquid is a tiny heart that, against all reason, is still beating. These ingredients vanish when the potion is opened.

#### Potion of Mind Reading

_Potion, Rare_

When you drink this potion, you gain the effect of the _Detect Thoughts_ spell (save DC 13) for 10 minutes (no Concentration required).

This potion's dense, purple liquid has an ovoid cloud of pink floating in it.

#### Potion of Poison

_Potion, Uncommon_

This concoction looks, smells, and tastes like a _Potion of Healing_ or another beneficial potion. However, it is actually poison masked by illusion magic. _Identify_ reveals its true nature.

If you drink this potion, you take 4d6 Poison damage and must succeed on a DC 13 Constitution saving throw or have the Poisoned condition for 1 hour.

#### Potion of Resistance

_Potion, Uncommon_

When you drink this potion, you have Resistance to one type of damage for 1 hour. The GM chooses the type or determines it randomly by rolling on the following table.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Damage Type</th>
      <th>1d10</th>
      <th>Damage Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Acid</td>
      <td>6</td>
      <td>Necrotic</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Cold</td>
      <td>7</td>
      <td>Poison</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Fire</td>
      <td>8</td>
      <td>Psychic</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Force</td>
      <td>9</td>
      <td>Radiant</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Lightning</td>
      <td>10</td>
      <td>Thunder</td>
    </tr>
  </tbody>
</table>

#### Potion of Speed

_Potion, Very Rare_

When you drink this potion, you gain the effect of the _Haste_ spell for 1 minute (no Concentration required) without suffering the wave of lethargy that typically occurs when the effect ends.

This potion's yellow fluid is streaked with black and swirls on its own.

#### Potion of Vitality

_Potion, Very Rare_

When you drink this potion, it removes any Exhaustion levels you have and ends the Poisoned condition on you. For the next 24 hours, you regain the maximum number of Hit Points for any Hit Point Die you spend.

This potion's crimson liquid regularly pulses with dull light, calling to mind a heartbeat.

#### Potion of Water Breathing

_Potion, Uncommon_

You can breathe underwater for 24 hours after drinking this potion.
This potion's cloudy green fluid smells of the sea and has a jellyfish-like bubble floating in it.

#### Quarterstaff of the Acrobat

_Weapon (Quarterstaff), Very Rare (Requires Attunement)_

You have a +2 bonus to attack rolls and damage rolls made with this magic weapon.

While holding this weapon, you can cause it to emit green Dim Light out to 10 feet, either as a Bonus Action or after you roll Initiative, or you can extinguish the light as a Bonus Action.

While holding this weapon, you can take a Bonus Action to alter its form, turning it into a 6-inch rod (for ease of storage) or a 10-foot pole, or reverting it a Quarterstaff; the weapon will elongate only as far as the surrounding space allows.

In certain forms, the weapon has the following additional properties.

_Acrobatic Assist (Quarterstaff and 10-Foot Pole Forms Only)._ While holding this weapon, you have Advantage on Dexterity (Acrobatics) checks.

_Attack Deflection (Quarterstaff Form Only)._ When you are hit by an attack while holding the weapon, you can take a Reaction to twirl the weapon around you, gaining a +5 bonus to your Armor Class against the triggering attack, potentially causing the attack to miss you. You can't use this property again until you finish a Short or Long Rest.

_Ranged Weapon (Quarterstaff Form Only)._ This weapon has the Thrown property with a normal range of 30 feet and a long range of 120 feet. Immediately after you make a ranged attack with the weapon, it flies back to your hand.

#### Ring of Animal Influence

_Ring, Rare_

This ring has 3 charges, and it regains 1d3 expended charges daily at dawn. While wearing the ring, you can expend 1 charge to cast one of the following spells (save DC 13) from it:

- _Animal Friendship_
- _Fear_ (affects Beasts only)
- _Speak with Animals_

#### Ring of Djinni Summoning

_Ring, Legendary (Requires Attunement)_

While wearing this ring, you can take a Magic action to summon a particular **Djinni** from the Elemental Plane of Air. The djinni appears in an unoccupied space you choose within 120 feet of yourself. It remains as long as you maintain Concentration, to a maximum of 1 hour, or until it drops to 0 Hit Points.

While summoned, the djinni is Friendly to you and your allies, and it obeys your commands. If you fail to command it, the djinni defends itself against attackers but takes no other actions.

After the djinni departs, it can't be summoned again for 24 hours, and the ring becomes nonmagical if the djinni dies.

_Rings of Djinni Summoning_ are often created by the djinn they summon and given to mortals as gifts of friendship or tokens of esteem.

#### Ring of Elemental Command

_Ring, Legendary (Requires Attunement)_

Each _Ring of Elemental Command_ is linked to one of the four Elemental Planes. The GM chooses or randomly determines the linked plane. For example, a _Ring of Elemental Command_ (air) is linked to the Elemental Plane of Air.

Every _Ring of Elemental Command_ has the following two properties:

**Elemental Bane.** While wearing the ring, you have Advantage on attack rolls against Elementals and they have Disadvantage on attack rolls against you.

**Elemental Compulsion.** While wearing the ring, you can take a Magic action to try to compel an Elemental you see within 60 feet of yourself. The Elemental makes a DC 18 Wisdom saving throw. On a failed save, the Elemental has the Charmed condition until the start your next turn, and you determine what it does with its move and action on its next turn.

_Elemental Focus._ While wearing the ring, you benefit from additional properties corresponding to the ring's linked Elemental Plane:

**Air.** You know Auran, you have Resistance to Lightning damage, and you have a Fly Speed equal to your Speed and can hover.

**Earth.** You know Terran, and you have Resistance to Acid damage. Terrain composed of rubble, rocks, or dirt isn't Difficult Terrain for you. In addition, you can move through solid earth or rock as if those areas were Difficult Terrain without disturbing the matter through which you pass. If you end your turn in solid earth or rock, you are shunted out to the nearest unoccupied space you last occupied.

**Fire.** You know Ignan, and you have Immunity to Fire damage.

**Water.** You know Aquan, you gain a Swim Speed of 60 feet, and you can breathe underwater.

_Spellcasting._ The ring has 5 charges and regains 1d4 + 1 expended charges daily at dawn. While wearing the ring, you can cast a spell from it. Choose the spell from the list of available spells based on the Elemental Plane the ring is linked to, as shown in the following table. The table indicates how many charges you must expend to cast the spell, which has a save DC of 18.

<table>
  <thead>
    <tr>
      <th>Plane</th>
      <th>Spells (Charges)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Air</td>
      <td>*Chain Lightning* (3 charges), *Feather Fall* (0 charges), *Gust of Wind* (2 charges), *Wind Wall* (1 charge)</td>
    </tr>
    <tr>
      <td>Earth</td>
      <td>*Earthquake* (5 charges), *Stone Shape* (2 charges), *Stoneskin* (3 charges), *Wall of Stone* (3 charges)</td>
    </tr>
    <tr>
      <td>Fire</td>
      <td>*Burning Hands* (1 charge), *Fireball* (2 charges), *Fire Storm* (4 charges), *Wall of Fire* (3 charges)</td>
    </tr>
    <tr>
      <td>Water</td>
      <td>*Create or Destroy Water* (1 charge), *Ice Storm* (2 charges), *Tsunami* (5 charges), *Wall of Ice* (3 charges), *Water Walk* (2 charges)</td>
    </tr>
  </tbody>
</table>

#### Ring of Evasion

_Ring, Rare (Requires Attunement)_

This ring has 3 charges, and it regains 1d3 expended charges daily at dawn. When you fail a Dexterity saving throw while wearing the ring, you can take a Reaction to expend 1 charge to succeed on that save instead.

#### Ring of Feather Falling

_Ring, Rare (Requires Attunement)_

When you fall while wearing this ring, you descend 60 feet per round and take no damage from falling.

#### Ring of Free Action

_Ring, Rare (Requires Attunement)_

While you wear this ring, Difficult Terrain doesn't cost you extra movement. In addition, magic can neither reduce any of your Speeds nor cause you to have the Paralyzed or Restrained condition.

#### Ring of Invisibility

_Ring, Legendary (Requires Attunement)_

While wearing this ring, you can take a Magic action to give yourself the Invisible condition. You remain Invisible until the ring is removed or until you take a Bonus Action to become visible again.

#### Ring of Jumping

_Ring, Uncommon (Requires Attunement)_

While wearing this ring, you can cast _Jump_ from it, but can target only yourself when you do so.

#### Ring of Mind Shielding

_Ring, Uncommon (Requires Attunement)_

While wearing this ring, you are immune to magic that allows other creatures to read your thoughts, determine whether you are lying, know your alignment, or know your creature type. Creatures can telepathically communicate with you only if you allow it.

You can take a Magic action to cause the ring to become imperceptible until you take another Magic action to make it perceptible, until you remove the ring, or until you die.

If you die while wearing the ring, your soul enters it, unless it already houses a soul. You can remain in the ring or depart for the afterlife. As long as your soul is in the ring, you can telepathically communicate with any creature wearing it. A wearer can't prevent this telepathic communication.

#### Ring of Protection

_Ring, Rare (Requires Attunement)_

You gain a +1 bonus to Armor Class and saving throws while wearing this ring.

#### Ring of Regeneration

_Ring, Very Rare (Requires Attunement)_

While wearing this ring, you regain 1d6 Hit Points every 10 minutes if you have at least 1 Hit Point. If you lose a body part, the ring causes the missing part to regrow and return to full functionality after 1d6 + 1 days if you have at least 1 Hit Point the whole time.

#### Ring of Resistance

_Ring, Rare_

You have Resistance to one damage type while wearing this ring. The gemstone in the ring indicates the type, which the GM chooses or determines randomly by rolling on the following table.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Damage Type</th>
      <th>Gemstone</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Acid</td>
      <td>Pearl</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Cold</td>
      <td>Tourmaline</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Fire</td>
      <td>Garnet</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Force</td>
      <td>Sapphire</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Lightning</td>
      <td>Citrine</td>
    </tr>
    <tr>
      <td>6</td>
      <td>Necrotic</td>
      <td>Jet</td>
    </tr>
    <tr>
      <td>7</td>
      <td>Poison</td>
      <td>Amethyst</td>
    </tr>
    <tr>
      <td>8</td>
      <td>Psychic</td>
      <td>Jade</td>
    </tr>
    <tr>
      <td>9</td>
      <td>Radiant</td>
      <td>Topaz</td>
    </tr>
    <tr>
      <td>10</td>
      <td>Thunder</td>
      <td>Spinel</td>
    </tr>
  </tbody>
</table>

#### Ring of Shooting Stars

_Ring, Very Rare (Requires Attunement)_

You can cast _Dancing Lights_ or _Light_ from the ring.

The ring has 6 charges and regains 1d6 expended charges daily at dawn. You can expend its charges to use the properties below.

**_Faerie Fire._** You can expend 1 charge to cast _Faerie Fire_ from the ring.

**_Lightning Spheres._** You can expend 2 charges as a Magic action to create up to four 3-foot-diameter spheres of lightning. Each sphere appears in an unoccupied space you can see within 120 feet of yourself. The spheres last as long as you maintain Concentration, up to 1 minute. Each sphere sheds Dim Light in a 30-foot radius.

As a Bonus Action, you can move each sphere up to 30 feet, but no farther than 120 feet away from yourself. The first time the sphere comes within 5 feet of a creature other than you that isn't behind Total Cover, the sphere discharges lightning at that creature and disappears. That creature makes a DC 15 Dexterity saving throw. On a failed save, the creature takes Lightning damage based on the number of spheres you created, as shown in the following table. On a successful save, the creature takes half as much damage.

<table>
  <thead>
    <tr>
      <th>Number of Spheres</th>
      <th>Lightning Damage</th>
      <th>Number of Spheres</th>
      <th>Lightning Damage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>4d12</td>
      <td>3</td>
      <td>2d6</td>
    </tr>
    <tr>
      <td>2</td>
      <td>5d4</td>
      <td>4</td>
      <td>2d4</td>
    </tr>
  </tbody>
</table>

_Shooting Stars._ You can expend 1 to 3 charges as a Magic action. For every charge you expend, you launch a glowing mote of light from the ring at a point you can see within 60 feet of yourself. Each creature in a 15-foot Cube originating from that point is showered in sparks and makes a DC 15 Dexterity saving throw, taking 5d4 Radiant damage on a failed save or half as much damage on a successful one.

#### Ring of Spell Storing

_Ring, Rare (Requires Attunement)_

This ring stores spells cast into it, holding them until the attuned wearer uses them. The ring can store up to 5 levels worth of spells at a time. When found, it contains 1d6 − 1 levels of stored spells chosen by the GM.

Any creature can cast a spell of level 1 through 5 into the ring by touching the ring as the spell is cast. The spell has no effect other than to be stored in the ring. If the ring can't hold the spell, the spell is expended without effect. The level of the slot used to cast the spell determines how much space it uses.

While wearing this ring, you can cast any spell stored in it. The spell uses the slot level, spell save DC, spell attack bonus, and spellcasting ability of the original caster but is otherwise treated as if you cast the spell. The spell cast from the ring is no longer stored in it, freeing up space.

#### Ring of Spell Turning

_Ring, Legendary (Requires Attunement)_

While wearing this ring, you have Advantage on saving throws against spells. If you succeed on the save for a spell of level 7 or lower, the spell has no effect on you. If that spell targeted only you and didn't create an area of effect, you can take a Reaction to deflect the spell back at the spell's caster; the caster must make a saving throw against the spell using their own spell save DC.

#### Ring of Swimming

_Ring, Uncommon_

You have a Swim Speed of 40 feet while wearing this ring.

#### Ring of Telekinesis

_Ring, Very Rare (Requires Attunement)_

While wearing this ring, you can cast _Telekinesis_ from it.

#### Ring of the Ram

_Ring, Rare (Requires Attunement)_

This ring has 3 charges and regains 1d3 expended charges daily at dawn. While wearing the ring, you can take a Magic action to expend 1 to 3 charges to make a ranged spell attack against one creature you can see within 60 feet of yourself. The ring produces a spectral ram's head and makes its attack roll with a +7 bonus. On a hit, for each charge you spend, the target takes 2d10 Force damage and is pushed 5 feet away from you.

Alternatively, you can expend 1 to 3 of the ring's charges as a Magic action to try to break a nonmagical object you can see within 60 feet of yourself that isn't being worn or carried. The ring makes a Strength check with a +5 bonus for each charge you spend.

#### Ring of Three Wishes

_Ring, Legendary_

While wearing this ring, you can expend 1 of its 3 charges to cast _Wish_ from it. The ring becomes nonmagical when you use the last charge.

#### Ring of Warmth

_Ring, Uncommon (Requires Attunement)_

If you take Cold damage while wearing this ring, the ring reduces the damage you take by 2d8.

In addition, while wearing this ring, you and everything you wear and carry are unharmed by temperatures of 0 degrees Fahrenheit or lower.

#### Ring of Water Walking

_Ring, Uncommon_

While wearing this ring, you cast _Water Walk_ from it, targeting only yourself.

#### Ring of X-ray Vision

_Ring, Rare (Requires Attunement)_

While wearing this ring, you can take a Magic action to gain X-ray vision with a range of 30 feet for 1 minute. To you, solid objects within that radius appear transparent and don't prevent light from passing through them. The vision can penetrate 1 foot of stone, 1 inch of common metal, or up to 3 feet of wood or dirt. Thicker substances or a thin sheet of lead block the vision.

Whenever you use the ring again before taking a Long Rest, you must succeed on a DC 15 Constitution saving throw or gain 1 Exhaustion level.

#### Robe of Eyes

_Wondrous Item, Rare (Requires Attunement)_

This robe is adorned with eyelike patterns. While you wear the robe, you gain the following benefits:

**All-Around Vision.** The robe gives you Advantage on Wisdom (Perception) checks that rely on sight.

**Special Senses.** You have Darkvision and Truesight, both with a range of 120 feet.

_Drawbacks._ A _Light_ spell cast on the robe or a _Daylight_ spell cast within 5 feet of the robe gives you the Blinded condition for 1 minute. At the end of each of your turns, you make a Constitution saving throw (DC 11 for _Light_ or DC 15 for _Daylight_), ending the condition on yourself on a success.

#### Robe of Scintillating Colors

_Wondrous Item, Very Rare (Requires Attunement)_

This robe has 3 charges, and it regains 1d3 expended charges daily at dawn. While you wear it, you can take a Magic action and expend 1 charge to cause the garment to display a shifting pattern of dazzling hues until the end of your next turn. During this time, the robe sheds Bright Light in a 30-foot radius and Dim Light for an additional 30 feet, and creatures that can see you have Disadvantage on attack rolls against you. Any creature in the Bright Light that can see you when the robe's power is activated must succeed on a DC 15 Wisdom saving throw or have the Stunned condition until the effect ends.

#### Robe of Stars

_Wondrous Item, Very Rare (Requires Attunement)_

This black or dark-blue robe is embroidered with small white or silver stars. You gain a +1 bonus to saving throws while you wear it.

Six stars, located on the robe's upper-front portion, are particularly large. While wearing this robe, you can take a Magic action to remove one of the stars and expend it to cast the level 5 version of _Magic Missile_. Daily at dusk, 1d6 removed stars reappear on the robe.

While you wear the robe, you can take a Magic action to enter the Astral Plane along with everything you are wearing and carrying. You remain there until you take a Magic action to return to the plane you were on. You reappear in the last space you occupied or, if that space is occupied, the nearest unoccupied space.

#### Robe of the Archmagi

_Wondrous Item, Legendary (Requires Attunement by a Sorcerer, Warlock, or Wizard)_

This elegant garment is made from exquisite cloth and adorned with runes.

You gain these benefits while wearing the robe.

_Armor._ If you aren't wearing armor, your base Armor Class is 15 plus your Dexterity modifier.

_Magic Resistance._ You have Advantage on saving throws against spells and other magical effects.

_War Mage._ Your spell save DC and spell attack bonus each increase by 2.

#### Robe of Useful Items

_Wondrous Item, Uncommon_

This robe has cloth patches of various shapes and colors covering it. While wearing the robe, you can take a Magic action to detach one of the patches, causing it to become the object or creature it represents. Once the last patch is removed, the robe becomes an ordinary garment.

The robe has two of each of the following patches:

- Bullseye Lantern (filled and lit)
- Dagger
- Mirror
- Pole
- Rope (coiled)
- Sack

In addition, the robe has 4d4 other patches. The GM chooses the patches or determines them randomly by rolling on the following table.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Patch</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–08</td>
      <td>Bag of 100 GP</td>
    </tr>
    <tr>
      <td>09–15</td>
      <td>Silver coffer (1 foot long, 6 inches wide and deep) worth 500 GP</td>
    </tr>
    <tr>
      <td>16–22</td>
      <td>Iron door (up to 10 feet wide and 10 feet high, barred on one side of your choice), which you can place in an opening you can reach; it conforms to fit the opening, attaching and hinging itself</td>
    </tr>
    <tr>
      <td>23–30</td>
      <td>10 gems worth 100 GP each</td>
    </tr>
    <tr>
      <td>31–44</td>
      <td>Wooden ladder (24 feet long)</td>
    </tr>
    <tr>
      <td>45–51</td>
      <td>Riding Horse with a Riding Saddle</td>
    </tr>
    <tr>
      <td>52–59</td>
      <td>Open pit (a 10-foot Cube), which you can place on the ground within 10 feet of yourself</td>
    </tr>
    <tr>
      <td>60–68</td>
      <td>4 Potions of Healing</td>
    </tr>
    <tr>
      <td>69–75</td>
      <td>Rowboat (12 feet long)</td>
    </tr>
    <tr>
      <td>76–83</td>
      <td>Spell Scroll containing one spell of level 1, 2, or 3 (your choice)</td>
    </tr>
    <tr>
      <td>84–90</td>
      <td>2 Mastiffs</td>
    </tr>
    <tr>
      <td>91–96</td>
      <td>Window (2 feet by 4 feet, up to 2 feet deep), which you can place on a vertical surface you can reach</td>
    </tr>
    <tr>
      <td>97–00</td>
      <td>Portable Ram</td>
    </tr>
  </tbody>
</table>

#### Rod of Absorption

_Rod, Very Rare (Requires Attunement)_

While holding this rod, you can take a Reaction to absorb a spell that is targeting only you and doesn't create an area of effect. The absorbed spell's effect is canceled, and the spell's energy—not the spell itself—is stored in the rod. The energy has the same level as the spell when it was cast. A canceled spell dissipates with no effect, and any resources used to cast it are wasted. The rod can absorb and store up to 50 levels of energy over the course of its existence. Once the rod absorbs 50 levels of energy, it can't absorb more. If you are targeted by a spell that the rod can't store, the rod has no effect on that spell.

When you become attuned to the rod, you know how many levels of energy the rod has absorbed over the course of its existence and how many levels of spell energy it currently has stored.

If you are a spellcaster holding the rod, you can convert energy stored in it into spell slots to cast spells you have prepared or know. You can create spell slots only of a level equal to or lower than your own spell slots, up to a maximum of level 5. You use the stored levels in place of your slots but otherwise cast the spell as normal. For example, you can use 3 levels stored in the rod as a level 3 spell slot.

A newly found rod typically has 1d10 levels of spell energy stored in it. A rod that can no longer absorb spell energy and has no energy remaining becomes nonmagical.

#### Rod of Alertness

_Rod, Very Rare (Requires Attunement)_

This rod has the following properties.

_Alertness._ While holding the rod, you have Advantage on Wisdom (Perception) checks and on Initiative rolls.

_Spells._ While holding the rod, you can cast the following spells from it:

- _Detect Evil and Good_
- _Detect Magic_
- _Detect Poison and Disease_
- _See Invisibility_

_Protective Aura._ As a Magic action, you can plant the haft end of the rod in the ground, whereupon the rod's head sheds Bright Light in a 60-foot radius and Dim Light for an additional 60 feet. While in that Bright Light, you and your allies gain a +1 bonus to Armor Class and saving throws and can sense the location of any Invisible creature that is also in the Bright Light.

The rod's head stops glowing and the effect ends after 10 minutes or when a creature takes a Magic action to pull the rod from the ground. Once used, this property can't be used again until the next dawn.

#### Rod of Lordly Might

_Rod, Legendary (Requires Attunement)_

This rod has a flanged head, and it functions as a magic Mace that grants a +3 bonus to attack rolls and damage rolls made with it. The rod has properties associated with six different buttons that are set in a row along the haft. It has three other properties as well, detailed below.

_Buttons._ You can press one of the following buttons as a Bonus Action; a button's effect lasts until you push a different button or until you push the same button again, which causes the rod to revert to its normal form:

**Button 1.** A fiery blade sprouts from the end opposite the rod's flanged head. The flames shed Bright Light in a 40-foot radius and Dim Light for an additional 40 feet, and the blade functions as a magic Longsword or Shortsword (your choice) that deals an extra 2d6 Fire damage on a hit.

**Button 2.** The rod's flanged head folds down and two crescent-shaped blades spring out, transforming the rod into a magic Battleaxe that grants a +3 bonus to attack rolls and damage rolls made with it.

**Button 3.** The rod's flanged head folds down, a spear point springs from the rod's tip, and the rod's handle lengthens into a 6-foot haft, transforming the rod into a magic Spear that grants a +3 bonus to attack rolls and damage rolls made with it.

**Button 4.** The rod transforms into a climbing pole up to 50 feet long (you specify the length), though the rod's buttons remain within your reach. In surfaces as hard as granite, a spike at the bottom and three hooks at the top anchor the pole. Horizontal bars 3 inches long fold out from the sides, 1 foot apart, forming a ladder. The pole can bear up to 4,000 pounds. More weight or lack of solid anchoring causes the rod to revert to its normal form.

**Button 5.** The rod transforms into a handheld battering ram and grants its user a +10 bonus to Strength (Athletics) checks made to break through doors, barricades, and other barriers.

**Button 6.** The rod assumes or remains in its normal form and indicates magnetic north. (Nothing happens if this function of the rod is used in a location that has no magnetic north.) The rod also gives you knowledge of your approximate depth beneath the ground or your height above it.

_Drain Life._ When you hit a creature with a melee attack using the rod, you can force the target to make a DC 17 Constitution saving throw. On a failed save, the target takes an extra 4d6 Necrotic damage, and you regain a number of Hit Points equal to half that Necrotic damage. Once used, this property can't be used again until the next dawn.

_Paralyze._ When you hit a creature with a melee attack using the rod, you can force the target to make a DC 17 Constitution saving throw. On a failed save, the target has the Paralyzed condition for 1 minute. The target repeats the save at the end of each of its turns, ending the effect on a success. Once used, this property can't be used again until the next dawn.

_Terrify._ While holding the rod, you can take a Magic action to force each creature you can see within 30 feet of yourself to make a DC 17 Wisdom saving throw. On a failed save, a target has the Frightened condition for 1 minute. A Frightened target repeats the save at the end of each of its turns, ending the effect on itself on a success. Once used, this property can't be used again until the next dawn.

#### Rod of Resurrection

_Rod, Legendary (Requires Attunement)_

The rod has 5 charges. While you hold it, you can cast one of the following spells from it: _Heal_ (expends 1 charge) or _Resurrection_ (expends 5 charges).

The rod regains 1 expended charge daily at dawn. If you expend the last charge, roll 1d20. On a 1, the rod disappears in a harmless burst of radiance.

#### Rod of Rulership

_Rod, Rare (Requires Attunement)_

You can take a Magic action to present the rod and command obedience from each creature of your choice that you can see within 120 feet of yourself. Each target must succeed on a DC 15 Wisdom saving throw or have the Charmed condition for 8 hours. While Charmed in this way, the creature regards you as its trusted leader. If harmed by you or your allies or commanded to do something contrary to its nature, a target ceases to be Charmed in this way. Once used, this property can't be used again until the next dawn.

#### Rod of Security

_Rod, Very Rare_

While holding this rod, you can take a Magic action to activate it. The rod then instantly transports you and up to 199 other willing creatures you can see to a demiplane. You choose the form the demiplane takes. It could be a tranquil garden, a cheery tavern, an immense palace, a tropical island, a fantastic carnival, or whatever else you can imagine. Regardless of its nature, the demiplane contains enough water and food to sustain its visitors, and the demiplane's environment can't harm its occupants. Everything else that can be interacted with there can exist only there. For example, a flower picked from a garden there disappears if it is taken outside the demiplane.

For each hour spent in the demiplane, a visitor regains Hit Points as if it had spent 1 Hit Point Die. Also, creatures don't age while there, although time passes normally. Visitors can remain there for up to 200 days divided by the number of creatures present (round down).

When the time runs out or you take a Magic action to end the effect, all visitors reappear in the location they occupied when you activated the rod or an unoccupied space nearest that location. Once used, this property can't be used again until 10 days have passed.

#### Rope of Climbing

_Wondrous Item, Uncommon_

This 60-foot length of rope can hold up to 3,000 pounds. While holding one end of the rope, you can take a Magic action to command the other end of the rope to animate and move toward a destination you choose, up to the rope's length away from you. That end moves 10 feet on your turn when you first command it and 10 feet at the start of each of your subsequent turns until reaching its destination or until you tell it to stop. You can also tell the rope to fasten itself securely to an object or to unfasten itself, to knot or unknot itself, or to coil itself for carrying.

If you tell the rope to knot, large knots appear at 1-foot intervals along the rope. While knotted, the rope shortens to a 50-foot length and grants Advantage on ability checks made to climb using the rope.

The rope has AC 20, HP 20, and Immunity to Poison and Psychic damage. It regains 1 Hit Point every 5 minutes as long as it has at least 1 Hit Point. If the rope drops to 0 Hit Points, it is destroyed.

#### Rope of Entanglement

_Wondrous Item, Rare_

This rope is 30 feet long. While holding one end of the rope, you can take a Magic action to command the other end to dart forward and entangle one creature you can see within 20 feet of yourself. The target must succeed on a DC 15 Dexterity saving throw or have the Restrained condition. You can release the target by letting go of your end of the rope (causing the rope to coil up in the target's space) or by using a Bonus Action to repeat the command (causing the rope to coil up in your hand).

A target Restrained by the rope can take an action to make its choice of a DC 15 Strength (Athletics) or Dexterity (Acrobatics) check. On a successful check, the target is no longer Restrained by the rope. If you're still holding onto the rope when a target escapes from it, you can take a Reaction to command the rope to coil up in your hand; otherwise, the rope coils up in the target's space.

The rope has AC 20, HP 20, and Immunity to Poison and Psychic damage. It regains 1 Hit Point every 5 minutes as long as it has at least 1 Hit Point. If the rope drops to 0 Hit Points, it is destroyed.

#### Scarab of Protection

_Wondrous Item, Legendary (Requires Attunement)_

This beetle-shaped medallion provides three benefits while it is on your person.

_Defense._ You gain a +1 bonus to Armor Class.

_Preservation._ The scarab has 12 charges. If you fail a saving throw against a Necromancy spell or a harmful effect originating from an Undead, you can take a Reaction to expend 1 charge and turn the failed save into a successful one. The scarab crumbles into powder and is destroyed when its last charge is expended.

_Spell Resistance._ You have Advantage on saving throws against spells.

#### Scimitar of Speed

_Weapon (Scimitar), Very Rare (Requires Attunement)_

You gain a +2 bonus to attack rolls and damage rolls made with this magic weapon. In addition, you can make one attack with it as a Bonus Action on each of your turns.

#### Sending Stones

_Wondrous Item, Uncommon_

_Sending Stones_ come in pairs, with each stone carved to match the other so the pairing is easily recognized. While you touch one stone, you can cast _Sending_ from it. The target is the bearer of the other stone. If no creature bears the other stone, you know that fact as soon as you use the stone, and you don't cast the spell.

Once _Sending_ is cast using either stone, the stones can't be used again until the next dawn. If one of the stones in a pair is destroyed, the other one becomes nonmagical.

#### Sentinel Shield

_Armor (Shield), Uncommon_

While holding this Shield, you have Advantage on Initiative rolls and Wisdom (Perception) checks. The Shield is emblazoned with a symbol of an eye.

#### Shield, +1, +2, or +3

_Armor (Shield), Uncommon (+1), Rare (+2), or Very Rare (+3)_

While holding this Shield, you have a bonus to Armor Class determined by the Shield's rarity, in addition to the Shield's normal bonus to AC.

#### Shield of Missile Attraction

_Armor (Shield), Rare (Requires Attunement)_

While holding this Shield, you have Resistance to damage from attacks made with Ranged weapons.

_Curse._ This Shield is cursed. Attuning to it curses you until you are targeted by a _Remove Curse_ spell or similar magic. Removing the Shield fails to end the curse on you. Whenever an attack with a Ranged weapon targets a creature within 10 feet of you, the curse causes you to become the target instead.

#### Shield of the Cavalier

_Armor (Shield), Very Rare (Requires Attunement)_

While holding this Shield, you have a +2 bonus to Armor Class. This bonus is in addition to the Shield's normal bonus to AC.

The Shield has the following additional properties that you can use while holding it.

_Forceful Bash._ When you take the Attack action, you can make one of the attack rolls using the Shield against a target within 5 feet of yourself. Apply your Proficiency Bonus and Strength modifier to the attack roll. On a hit, the Shield deals Force damage to the target equal to 2d6 + 2 plus your Strength modifier, and if the target is a creature, you can push it up to 10 feet directly away from yourself. If the creature is your size or smaller, you can also knock it down, giving it the Prone condition.

_Protective Field._ As a Reaction, when you or an ally you can see within 5 feet of you is targeted by an attack or makes a saving throw against an area of effect, you can use the Shield to create an immobile 5-foot Emanation originating from you. When the Emanation appears, any creatures or objects not fully contained within it are pushed into the nearest unoccupied spaces outside it. The attack or area of effect that triggered the Reaction has no effect on creatures and objects inside the Emanation, which lasts as long as you maintain Concentration, up to 1 minute. Nothing can pass into or out of the Emanation. A creature or object inside the Emanation can't be damaged by attacks or effects originating from outside, nor can a creature inside the Emanation damage anything outside it. Once this property is used, it can't be used again until the next dawn.

#### Slippers of Spider Climbing

_Wondrous Item, Uncommon (Requires Attunement)_

While you wear these light shoes, you can move up, down, and across vertical surfaces and along ceilings, while leaving your hands free. You have a Climb Speed equal to your Speed. However, the slippers don't allow you to move this way on a slippery surface, such as one covered by ice or oil.

#### Sovereign Glue

_Wondrous Item, Legendary_

This viscous, milky-white substance can form a permanent adhesive bond between any two objects. It must be stored in a jar or flask that has been coated inside with _Oil of Slipperiness_. When found, a container contains 1d6 + 1 ounces.

One ounce of the glue can cover a 1-foot square surface. Applying an ounce of _Sovereign Glue_ takes a Utilize action, and the applied glue takes 1 minute to set. Once it has done so, the bond it creates can be broken only by the application of _Universal Solvent_ or _Oil of Etherealness_, or with a _Wish_ spell.

#### Spellguard Shield

_Armor (Shield), Very Rare (Requires Attunement)_

While holding this Shield, you have Advantage on saving throws against spells and other magical effects, and spell attack rolls have Disadvantage against you.

#### Spell Scroll

_Scroll, Rarity Varies_

A _Spell Scroll_ bears the words of a single spell, written in a mystical cipher. If the spell is on your spell list, you can read the scroll and cast its spell without Material components. Otherwise, the scroll is unintelligible. Casting the spell by reading the scroll requires the spell's normal casting time. Once the spell is cast, the scroll crumbles to dust. If the casting is interrupted, the scroll isn't lost.

If the spell is on your spell list but of a higher level than you can normally cast, you make an ability check using your spellcasting ability to determine whether you cast the spell. The DC equals 10 plus the spell's level. On a failed check, the spell disappears from the scroll with no other effect.

The level of the spell on the scroll determines the spell's saving throw DC and attack bonus, as well as the scroll's rarity, as shown in the following table.

<table>
  <thead>
    <tr>
      <th>Spell Level</th>
      <th>Rarity</th>
      <th>Save DC</th>
      <th>Attack Bonus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Cantrip</td>
      <td>Common</td>
      <td>13</td>
      <td>+5</td>
    </tr>
    <tr>
      <td>1</td>
      <td>Common</td>
      <td>13</td>
      <td>+5</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Uncommon</td>
      <td>13</td>
      <td>+5</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Uncommon</td>
      <td>15</td>
      <td>+7</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Rare</td>
      <td>15</td>
      <td>+7</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Rare</td>
      <td>17</td>
      <td>+9</td>
    </tr>
    <tr>
      <td>6</td>
      <td>Very Rare</td>
      <td>17</td>
      <td>+9</td>
    </tr>
    <tr>
      <td>7</td>
      <td>Very Rare</td>
      <td>18</td>
      <td>+10</td>
    </tr>
    <tr>
      <td>8</td>
      <td>Very Rare</td>
      <td>18</td>
      <td>+10</td>
    </tr>
    <tr>
      <td>9</td>
      <td>Legendary</td>
      <td>19</td>
      <td>+11</td>
    </tr>
  </tbody>
</table>

_Copying a Scroll into a Spellbook._ A Wizard spell on a _Spell Scroll_ can be copied into a spellbook. When a spell is copied in this way, the copier must succeed on an Intelligence (Arcana) check with a DC equal to 10 plus the spell's level. On a successful check, the spell is copied. Whether the check succeeds or fails, the _Spell Scroll_ is destroyed.

#### Sphere of Annihilation

_Wondrous Item, Legendary_

This 2-foot-diameter black sphere is a hole in the multiverse, hovering in space and stabilized by a magical field surrounding it.

The sphere obliterates all matter it passes through and all matter that passes through it. Artifacts are the exception. Unless an Artifact is susceptible to damage from a _Sphere of Annihilation_, it passes through the sphere unscathed. Anything else that touches the sphere but isn't wholly engulfed and obliterated by it takes 8d10 Force damage.

_Controlling the Sphere._ A _Sphere of Annihilation_ is stationary until someone takes control of it. If you are within 60 feet of a sphere, you can take a Magic action to make a DC 25 Intelligence (Arcana) check. On a successful check, you control the sphere until the start of your next turn, and if it was under another creature's control, that creature loses control of the sphere. On a failed check, the sphere moves 10 feet toward you in a straight line.

While in control of the sphere, you can take a Bonus Action to cause it to move in one direction of your choice, up to a number of feet equal to 5 times your Intelligence modifier (minimum 5 feet). Any creature whose space the sphere enters must succeed on a DC 19 Dexterity saving throw or be touched by it, taking 8d10 Force damage. A creature reduced to 0 Hit Points by this damage is obliterated, leaving its possessions behind but no other physical remains.

_Sphere Interactions._ If the sphere comes into contact with a planar portal (such as that created by the _Gate_ spell) or an extradimensional space (such as that within a _Portable Hole_), the GM determines randomly what happens using the following table.

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–50</td>
      <td>The sphere is destroyed.</td>
    </tr>
    <tr>
      <td>51–85</td>
      <td>The sphere moves through the portal or into the extradimensional space.</td>
    </tr>
    <tr>
      <td>86–00</td>
      <td>A spatial rift sends the sphere and each creature and object within 180 feet of the sphere to a random plane of existence.</td>
    </tr>
  </tbody>
</table>

#### Staff of Charming

_Staff, Rare (Requires Attunement by a Bard, Cleric, Druid, Sorcerer, Warlock, or Wizard)_

This staff has 10 charges. While holding the staff, you can use any of its properties:

**Cast Spell.** You can expend 1 of the staff's charges to cast _Charm Person_, _Command_, or _Comprehend Languages_ from it using your spell save DC.

**Reflect Enchantment.** If you succeed on a saving throw against an Enchantment spell that targets only you, you can take a Reaction to expend 1 charge from the staff and turn the spell back on its caster as if you had cast the spell.

**Resist Enchantment.** If you fail a saving throw against an Enchantment spell that targets only you, you can turn your failed save into a successful one. You can't use this property of the staff again until the next dawn.

_Regaining Charges._ The staff regains 1d8 + 2 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff crumbles to dust and is destroyed.

#### Staff of Fire

_Staff, Very Rare (Requires Attunement by a Druid, Sorcerer, Warlock, or Wizard)_

You have Resistance to Fire damage while you hold this staff.

_Spells._ The staff has 10 charges. While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Burning Hands*</td>
      <td>1</td>
      <td>*Wall of Fire*</td>
      <td>4</td>
    </tr>
    <tr>
      <td>*Fireball*</td>
      <td>3</td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff crumbles into cinders and is destroyed.

#### Staff of Frost

_Staff, Very Rare (Requires Attunement by a Druid, Sorcerer, Warlock, or Wizard)_

You have Resistance to Cold damage while you hold this staff.

_Spells._ The staff has 10 charges. While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Cone of Cold*</td>
      <td>5</td>
      <td>*Ice Storm*</td>
      <td>4</td>
    </tr>
    <tr>
      <td>*Fog Cloud*</td>
      <td>1</td>
      <td>*Wall of Ice*</td>
      <td>4</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff turns to water and is destroyed.

#### Staff of Healing

_Staff, Rare (Requires Attunement by a Bard, Cleric, or Druid)_

This staff has 10 charges. While holding the staff, you can cast one of the spells on the following table from it, using your spellcasting ability modifier. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Cure Wounds*</td>
      <td>1 charge per spell level (maximum 4 for a level 4 spell)</td>
    </tr>
    <tr>
      <td>*Lesser Restoration*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Mass Cure Wounds*</td>
      <td>5</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff vanishes in a flash of light, lost forever.

#### Staff of Power

_Staff, Very Rare (Requires Attunement by a Sorcerer, Warlock, or Wizard)_

This staff has 20 charges and can be wielded as a magic Quarterstaff that grants a +2 bonus to attack rolls and damage rolls made with it. While holding it, you gain a +2 bonus to Armor Class, saving throws, and spell attack rolls.

_Spells._ While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Cone of Cold*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Fireball* (level 5 version)</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Globe of Invulnerability*</td>
      <td>6</td>
    </tr>
    <tr>
      <td>*Hold Monster*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Levitate*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Lightning Bolt* (level 5 version)</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Magic Missile*</td>
      <td>1</td>
    </tr>
    <tr>
      <td>*Ray of Enfeeblement*</td>
      <td>1</td>
    </tr>
    <tr>
      <td>*Wall of Force*</td>
      <td>5</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 2d8 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff retains its +2 bonus to attack rolls and damage rolls but loses all other properties. On a 20, the staff regains 1d8 + 2 charges.

_Retributive Strike._ You can take a Magic action to break the staff over your knee or against a solid surface. The staff is destroyed and releases its magic in an explosion that fills a 30-foot Emanation originating from itself. You have a 50 percent chance to instantly travel to a random plane of existence, avoiding the explosion. If you fail to avoid the effect, you take Force damage equal to 16 times the number of charges in the staff. Each other creature in the area makes a DC 17 Dexterity saving throw. On a failed save, a creature takes Force damage equal to 4 times the number of charges in the staff. On a successful save, a creature takes half as much damage.

#### Staff of Striking

_Staff, Very Rare (Requires Attunement)_

This staff can be wielded as a magic Quarterstaff that grants a +3 bonus to attack rolls and damage rolls made with it.

The staff has 10 charges. When you hit with a melee attack using it, you can expend up to 3 charges. For each charge you expend, the target takes an extra 1d6 Force damage.

_Regaining Charges._ The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff becomes a nonmagical Quarterstaff.

#### Staff of Swarming Insects

_Staff, Rare (Requires Attunement by a Bard, Cleric, Druid, Sorcerer, Warlock, or Wizard)_

This staff has 10 charges.

_Insect Cloud._ While holding the staff, you can take a Magic action and expend 1 charge to cause a swarm of harmless flying insects to fill a 30-foot Emanation originating from you. The insects remain for 10 minutes, making the area Heavily Obscured for creatures other than you. A strong wind (like that created by _Gust of Wind_) disperses the swarm and ends the effect.

_Spells._ While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC and spell attack modifier. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Giant Insect*</td>
      <td>4</td>
    </tr>
    <tr>
      <td>*Insect Plague*</td>
      <td>5</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, a swarm of insects consumes and destroys the staff, then disperses.

#### Staff of the Magi

_Staff, Legendary (Requires Attunement by a Sorcerer, Warlock, or Wizard)_

This staff has 50 charges and can be wielded as a magic Quarterstaff that grants a +2 bonus to attack rolls and damage rolls made with it. While you hold it, you gain a +2 bonus to spell attack rolls.

_Spell Absorption._ While holding the staff, you have Advantage on saving throws against spells. In addition, you can take a Reaction when another creature casts a spell that targets only you. If you do, the staff absorbs the magic of the spell, canceling its effect and gaining a number of charges equal to the absorbed spell's level. However, if doing so brings the staff's total number of charges above 50, the staff explodes as if you activated its Retributive Strike (see below).

_Spells._ While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Arcane Lock*</td>
      <td>0</td>
    </tr>
    <tr>
      <td>*Conjure Elemental*</td>
      <td>7</td>
    </tr>
    <tr>
      <td>*Detect Magic*</td>
      <td>0</td>
    </tr>
    <tr>
      <td>*Dispel Magic*</td>
      <td>3</td>
    </tr>
    <tr>
      <td>*Enlarge/Reduce*</td>
      <td>0</td>
    </tr>
    <tr>
      <td>*Fireball* (level 7 version)</td>
      <td>7</td>
    </tr>
    <tr>
      <td>*Flaming Sphere*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Ice Storm*</td>
      <td>4</td>
    </tr>
    <tr>
      <td>*Invisibility*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Knock*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Light*</td>
      <td>0</td>
    </tr>
    <tr>
      <td>*Lightning Bolt* (level 7 version)</td>
      <td>7</td>
    </tr>
    <tr>
      <td>*Passwall*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Plane Shift*</td>
      <td>7</td>
    </tr>
    <tr>
      <td>*Protection from Evil and Good*</td>
      <td>0</td>
    </tr>
    <tr>
      <td>*Telekinesis*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Wall of Fire*</td>
      <td>4</td>
    </tr>
    <tr>
      <td>*Web*</td>
      <td>2</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The staff regains 4d6 + 2 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 20, the staff regains 1d12 + 1 charges.

_Retributive Strike._ You can take a Magic action to break the staff over your knee or against a solid surface. The staff is destroyed and releases its magic in an explosion that fills a 30-foot Emanation originating from itself. You have a 50 percent chance to instantly travel to a random plane of existence, avoiding the explosion. If you fail to avoid the effect, you take Force damage equal to 16 times the number of charges in the staff. Each other creature in the area makes a DC 17 Dexterity saving throw. On a failed save, a creature takes Force damage equal to 6 times the number of charges in the staff. On a successful save, a creature takes half as much damage.

#### Staff of the Python

_Staff, Uncommon (Requires Attunement)_

As a Magic action, you can throw this staff so that it lands in an unoccupied space within 10 feet of you, causing the staff to become a **Giant Constrictor Snake** in that space. The snake is under your control and shares your Initiative count, taking its turn immediately after yours.

On your turn, you can mentally command the snake (no action required) if it is within 60 feet of you and you don't have the Incapacitated condition. You decide what action the snake takes and where it moves during its turn, or you can issue it a general command, such as to attack your enemies or guard a location. Absent commands from you, the snake defends itself.

As a Bonus Action, you can command the snake to revert to staff form in its current space, and you can't use the staff's property again for 1 hour. If the snake is reduced to 0 Hit Points, it dies and reverts to its staff form; the staff then shatters and is destroyed. If the snake reverts to staff form before losing all its Hit Points, it regains all of them.

#### Staff of the Woodlands

_Staff, Rare (Requires Attunement by a Druid)_

This staff has 6 charges and can be wielded as a magic Quarterstaff that grants a +2 bonus to attack rolls and damage rolls made with it. While holding it, you have a +2 bonus to spell attack rolls.

_Spells._ While holding the staff, you can cast one of the spells on the following table from it, using your spell save DC. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Animal Friendship*</td>
      <td>1</td>
    </tr>
    <tr>
      <td>*Awaken*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Barkskin*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Locate Animals or Plants*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Pass without Trace*</td>
      <td>2</td>
    </tr>
    <tr>
      <td>*Speak with Animals*</td>
      <td>1</td>
    </tr>
    <tr>
      <td>*Speak with Plants*</td>
      <td>3</td>
    </tr>
    <tr>
      <td>*Wall of Thorns*</td>
      <td>6</td>
    </tr>
  </tbody>
</table>

_Tree Form._ You can take a Magic action to plant one end of the staff in earth in an unoccupied space and expend 1 charge to transform the staff into a healthy tree. The tree is 60 feet tall and has a 5-foot-diameter trunk, and its branches at the top spread out in a 20-foot radius. The tree appears ordinary but radiates a faint aura of Transmutation magic that can be discerned with the _Detect Magic_ spell. While touching the tree and using a Magic action, you return the staff to its normal form. Any creature in the tree falls when the tree reverts to a staff.

_Regaining Charges._ The staff regains 1d6 expended charges daily at dawn. If you expend the last charge, roll 1d20. On a 1, the staff loses its properties and becomes a nonmagical Quarterstaff.

#### Staff of Thunder and Lightning

_Staff, Very Rare (Requires Attunement)_

This staff can be wielded as a magic Quarterstaff that grants a +2 bonus to attack rolls and damage rolls made with it. It also has the following additional properties. Once one of these properties is used, it can't be used again until the next dawn.

_Lightning._ When you hit with a melee attack using the staff, you can cause the target to take an extra 2d6 Lightning damage (no action required).

_Thunder._ When you hit with a melee attack using the staff, you can cause the staff to emit a crack of thunder audible out to 300 feet (no action required). The target you hit must succeed on a DC 17 Constitution saving throw or have the Stunned condition until the end of your next turn.

**_Thunder and Lightning._** Immediately after you hit with a melee attack using the staff, you can take a Bonus Action to use the Lightning and Thunder properties (see above) at the same time. Doing so doesn't expend the daily use of those properties, only the use of this one.

_Lightning Strike._ You can take a Magic action to cause a bolt of lightning to leap from the staff's tip in a Line that is 5 feet wide and 120 feet long. Each creature in that Line makes a DC 17 Dexterity saving throw, taking 9d6 Lightning damage on a failed save or half as much damage on a successful one.

_Thunderclap._ You can take a Magic action to cause the staff to produce a thunderclap audible out to 600 feet. Every creature within a 60-foot Emanation originating from you makes a DC 17 Constitution saving throw. On a failed save, a creature takes 2d6 Thunder damage and has the Deafened condition for 1 minute. On a successful save, a creature takes half as much damage only.

#### Staff of Withering

_Staff, Rare (Requires Attunement)_

This staff has 3 charges and regains 1d3 expended charges daily at dawn.

The staff can be wielded as a magic Quarterstaff. On a hit, it deals damage as a normal Quarterstaff, and you can expend 1 charge to deal an extra 2d10 Necrotic damage to the target and force it to make a DC 15 Constitution saving throw. On a failed save, the target has Disadvantage for 1 hour on any ability check or saving throw that uses Strength or Constitution.

#### Stone of Controlling Earth Elementals

_Wondrous Item, Rare_

While touching this 5-pound stone to the ground, you can take a Magic action to summon an **Earth Elemental**. The elemental appears in an unoccupied space you choose within 30 feet of yourself, obeys your commands, and takes its turn immediately after you on your Initiative count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The stone can't be used this way again until the next dawn.

#### Stone of Good Luck (Luckstone)

_Wondrous Item, Uncommon (Requires Attunement)_

While this polished agate is on your person, you gain a +1 bonus to ability checks and saving throws.

#### Sun Blade

_Weapon (Longsword), Rare (Requires Attunement)_

This item appears to be a sword hilt.

_Blade of Radiance._ While grasping the hilt, you can take a Bonus Action to cause a blade of pure radiance to spring into existence or make the blade disappear. While the blade exists, this magic weapon functions as a Longsword with the Finesse property. If you are proficient with Longswords or Shortswords, you are proficient with the _Sun Blade_.

You gain a +2 bonus to attack rolls and damage rolls made with this weapon, which deals Radiant damage instead of Slashing damage. When you hit an Undead with it, that target takes an extra 1d8 Radiant damage.

_Sunlight._ The sword's luminous blade emits Bright Light in a 15-foot radius and Dim Light for an additional 15 feet. The light is sunlight. While the blade persists, you can take a Magic action to expand or reduce its radius of Bright Light and Dim Light by 5 feet each, to a maximum of 30 feet each or a minimum of 10 feet each.

#### Sword of Life Stealing

_Weapon (Glaive, Greatsword, Longsword, Rapier, Scimitar, or Shortsword), Rare (Requires Attunement)_

When you attack a creature with this magic weapon and roll a 20 on the d20 for the attack roll, that target takes an extra 15 Necrotic damage if it isn't a Construct or an Undead, and you gain Temporary Hit Points equal to the amount of Necrotic damage taken.

#### Sword of Sharpness

_Weapon (Glaive, Greatsword, Longsword, or Scimitar), Very Rare (Requires Attunement)_

When you attack an object with this magic weapon and hit, maximize your weapon damage dice against the target.

When you attack a creature with this weapon and roll a 20 on the d20 for the attack roll, that target takes an extra 14 Slashing damage and gains 1 Exhaustion level.

#### Sword of Wounding

_Weapon (Glaive, Greatsword, Longsword, Rapier, Scimitar, or Shortsword), Rare (Requires Attunement)_

When you hit a creature with an attack using this magic weapon, the target takes an extra 2d6 Necrotic damage and must succeed on a DC 15 Constitution saving throw or be unable to regain Hit Points for 1 hour. The target repeats the save at the end of each of its turns, ending the effect on itself on a success.

#### Talisman of Pure Good

_Wondrous Item, Legendary (Requires Attunement by a Cleric or Paladin)_

This talisman is a mighty symbol of goodness. A Fiend or an Undead that touches the talisman takes 8d6 Radiant damage and takes the damage again each time it ends its turn holding or carrying the talisman.

_Holy Symbol._ You can use the talisman as a Holy Symbol. You gain a +2 bonus to spell attack rolls while you wear or hold it.

_Pure Rebuke._ The talisman has 7 charges. While wearing or holding the talisman, you can take a Magic action to expend 1 charge and target one creature you can see on the ground within 120 feet of yourself. A flaming fissure opens under the target, and the target makes a DC 20 Dexterity saving throw. If the target is a Fiend or an Undead, it has Disadvantage on the save. On a failed save, the target falls into the fissure and is destroyed, leaving no remains. On a successful save, the target isn't cast into the fissure but takes 4d6 Psychic damage from the ordeal. In either case, the fissure then closes, leaving no trace of its existence. When you expend the last charge, the talisman disperses into motes of golden light and is destroyed.

#### Talisman of the Sphere

_Wondrous Item, Legendary (Requires Attunement)_

While holding or wearing this talisman, you have Advantage on any Intelligence (Arcana) check you make to control a _Sphere of Annihilation_. In addition, when you start your turn in control of a _Sphere of Annihilation_, you can take a Magic action to move it 10 feet plus a number of additional feet equal to 10 times your Intelligence modifier. This movement doesn't have to be in a straight line.

#### Talisman of Ultimate Evil

_Wondrous Item, Legendary (Requires Attunement)_

This item symbolizes unrepentant evil. A creature that isn't a Fiend or an Undead that touches the talisman takes 8d6 Necrotic damage and takes the damage again each time it ends its turn holding or carrying the talisman.

_Holy Symbol._ You can use the talisman as a Holy Symbol. You gain a +2 bonus to spell attack rolls while you wear or hold it.

_Ultimate End._ The talisman has 6 charges. While wearing or holding the talisman, you can take a Magic action to expend 1 charge and target one creature you can see on the ground within 120 feet of yourself. A flaming fissure opens under the target, and the target makes a DC 20 Dexterity saving throw. If the target is a Celestial, it has Disadvantage on the save. On a failed save, the target falls into the fissure and is destroyed, leaving no remains. On a successful save, the target isn't cast into the fissure but takes 4d6 Psychic damage from the ordeal. In either case, the fissure then closes, leaving no trace of its existence. When you expend the last charge, the talisman dissolves into foul-smelling slime and is destroyed.

#### Thunderous Greatclub

_Weapon (Greatclub), Very Rare (Requires Attunement)_

While you are attuned to this magic weapon, your Strength is 20 unless your Strength is already equal to or greater than that score. The weapon deals an extra 1d8 Thunder damage to any creature it hits and an extra 3d8 Thunder damage to objects it hits that aren't being worn or carried.

The weapon has the following additional properties.

_Clap of Thunder._ As a Magic action, you can strike the weapon against a hard surface to create a loud clap of thunder audible out to 300 feet. You also create a 30-foot Cone of thunderous energy. Each creature in the Cone must succeed on a DC 15 Strength saving throw or have the Prone condition. Nonmagical objects in the Cone that aren't being worn or carried take 3d8 Thunder damage.

_Earthquake._ As a Magic action, you can strike the weapon against the ground to create an intense seismic disturbance in a 50-foot-radius circle centered on the point of impact. Structures in contact with the ground in that area take 50 Bludgeoning damage, and each creature on the ground in that area must succeed on a DC 20 Dexterity saving throw or have the Prone condition. If that creature is also concentrating, it must succeed on a DC 20 Constitution saving throw, or its Concentration is broken. In addition, you can cause a 30-foot-deep, 10-foot-wide fissure to open up on the ground anywhere in the area. Any creature on a spot where the fissure opens must make a DC 20 Dexterity saving throw, falling into the fissure on a failed save or moving with the fissure's edge on a successful one. Any structure on a spot where the fissure opens collapses into the fissure. Once you use this property, it can't be used again until the next dawn.

#### Tome of Clear Thought

_Wondrous Item, Very Rare_

This book contains memory and logic exercises, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Intelligence increases by 2, to a maximum of 30. The manual then loses its magic but regains it in a century.

#### Tome of Leadership and Influence

_Wondrous Item, Very Rare_

This book contains guidelines for influencing and charming others, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Charisma increases by 2, to a maximum of 30. The manual then loses its magic but regains it in a century.

#### Tome of Understanding

_Wondrous Item, Very Rare_

This book contains intuition and insight exercises, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Wisdom increases by 2, to a maximum of 30. The manual then loses its magic, but regains it in a century.

#### Trident of Fish Command

_Weapon (Trident), Uncommon (Requires Attunement)_

This magic weapon has 3 charges, and it regains 1d3 expended charges daily at dawn. While you carry it, you can expend 1 charge to cast _Dominate Beast_ (save DC 15) from it on a Beast that has a Swim Speed.

#### Universal Solvent

_Wondrous Item, Legendary_

This tube holds milky liquid with a strong alcohol smell. When found, a tube contains 1d6 + 1 ounces.

You can take a Utilize action to pour 1 or more ounces of solvent from the tube onto a surface within reach. Each ounce instantly dissolves up to 1 square foot of adhesive it touches, including _Sovereign Glue_.

#### Vicious Weapon

_Weapon (Any Simple or Martial), Rare_

This magic weapon deals an extra 2d6 damage to any creature it hits. This extra damage is of the same type as the weapon's normal damage.

#### Vorpal Sword

_Weapon (Glaive, Greatsword, Longsword, or Scimitar), Legendary (Requires Attunement)_

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon. In addition, the weapon ignores Resistance to Slashing damage.

When you use this weapon to attack a creature that has at least one head and roll a 20 on the d20 for the attack roll, you cut off one of the creature's heads. The creature dies if it can't survive without the lost head. A creature is immune to this effect if it has Immunity to Slashing damage, if it doesn't have or need a head, or if the GM decides that the creature is too big for its head to be cut off with this weapon. Such a creature instead takes an extra 30 Slashing damage from the hit. If the creature has Legendary Resistance, it can expend one daily use of that trait to avoid losing its head, taking the extra damage instead.

#### Wand of Binding

_Wand, Rare (Requires Attunement)_

This wand has 7 charges.

_Spells._ While holding the wand, you can cast one of the spells (save DC 17) on the following table from it. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Hold Monster*</td>
      <td>5</td>
    </tr>
    <tr>
      <td>*Hold Person*</td>
      <td>2</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Enemy Detection

_Wand, Rare (Requires Attunement)_

This wand has 7 charges. While holding it, you can take a Magic action to expend 1 charge. For 1 minute, you know the direction of the nearest creature Hostile to you within 60 feet, but not its distance from you. The wand can sense the presence of Hostile creatures that are Invisible, ethereal, disguised, or hidden, as well as those in plain sight. The effect ends if you stop holding the wand.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Fear

_Wand, Rare (Requires Attunement)_

This wand has 7 charges.

_Spells._ While holding the wand, you can cast one of the spells (save DC 15) on the following table from it. The table indicates how many charges you must expend to cast the spell.

<table>
  <thead>
    <tr>
      <th>Spell</th>
      <th>Charge Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>*Command* (flee or grovel only)</td>
      <td>1</td>
    </tr>
    <tr>
      <td>*Fear* (60-foot Cone)</td>
      <td>3</td>
    </tr>
  </tbody>
</table>

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Fireballs

_Wand, Rare (Requires Attunement by a Spellcaster)_

This wand has 7 charges. While holding it, you can expend no more than 3 charges to cast _Fireball_ (save DC 15) from it. For 1 charge, you cast the level 3 version of the spell. You can increase the spell's level by 1 for each additional charge you expend.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Lightning Bolts

_Wand, Rare (Requires Attunement by a Spellcaster)_

This wand has 7 charges. While holding it, you can expend no more than 3 charges to cast _Lightning Bolt_ (save DC 15) from it. For 1 charge, you cast the level 3 version of the spell. You can increase the spell's level by 1 for each additional charge you expend.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Magic Detection

_Wand, Uncommon_

This wand has 3 charges. While holding it, you can expend 1 charge to cast _Detect Magic_ from it. The wand regains 1d3 expended charges daily at dawn.

#### Wand of Magic Missiles

_Wand, Uncommon_

This wand has 7 charges. While holding it, you can expend no more than 3 charges to cast _Magic Missile_ from it. For 1 charge, you cast the level 1 version of the spell. You can increase the spell's level by 1 for each additional charge you expend.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Paralysis

_Wand, Rare (Requires Attunement by a Spellcaster)_

This wand has 7 charges. While holding it, you can take a Magic action to expend 1 charge to cause a thin blue ray to streak from the tip toward a creature you can see within 60 feet of yourself. The target must succeed on a DC 15 Constitution saving throw or have the Paralyzed condition for 1 minute. At the end of each of the target's turns, it repeats the save, ending the effect on itself on a success.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Polymorph

_Wand, Very Rare (Requires Attunement by a Spellcaster)_

This wand has 7 charges. While holding it, you can expend 1 charge to cast _Polymorph_ (save DC 15) from it.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Secrets

_Wand, Uncommon_

This wand has 3 charges and regains 1d3 expended charges daily at dawn. While holding it, you can take a Magic action to expend 1 charge, and if a secret door or trap is within 60 feet of you, the wand pulses and points at the one nearest to you.

#### Wand of the War Mage, +1, +2, or +3

_Wand, Uncommon (+1), Rare (+2), or Very Rare (+3) (Requires Attunement by a Spellcaster)_

While holding this wand, you gain a bonus to spell attack rolls determined by the wand's rarity. In addition, you ignore Half Cover when making a spell attack roll.

#### Wand of Web

_Wand, Uncommon (Requires Attunement by a Spellcaster)_

This wand has 7 charges. While holding it, you can expend 1 charge to cast _Web_ (save DC 13) from it.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.

#### Wand of Wonder

_Wand, Rare (Requires Attunement)_

This wand has 7 charges. While holding it, you can take a Magic action to expend 1 charge while choosing a point within 120 feet of yourself. That location becomes the point of origin of a spell or other magical effect determined by rolling on the Wand of Wonder Effects table. Spells cast from the wand have a save DC of 15. If a spell's maximum range is normally less than 120 feet, it becomes 120 feet when cast from the wand. If an effect has multiple possible subjects, the GM determines randomly which among them are affected.

_Regaining Charges._ The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand's last charge, roll 1d20. On a 1, the wand crumbles into dust and is destroyed.

**Wand of Wonder Effects**

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>01–20</td>
      <td>You cast a spell originating from the chosen point. Roll 1d10 to determine the spell: on a 1–2, Darkness; on a 3–4, Faerie Fire; on a 5–6, Fireball; on a 7–8, Slow; on a 9–10, Stinking Cloud.</td>
    </tr>
    <tr>
      <td>21–25</td>
      <td>Nothing happens at the chosen point of origin. Instead, you have the Stunned condition until the start of your next turn, believing something awesome just happened.</td>
    </tr>
    <tr>
      <td>26–30</td>
      <td>You cast Gust of Wind. The Line created by the spell extends from you to the chosen point of origin.</td>
    </tr>
    <tr>
      <td>31–35</td>
      <td>Nothing happens at the chosen point of origin. Instead, you take 1d6 Psychic damage.</td>
    </tr>
    <tr>
      <td>36–40</td>
      <td>Heavy rain falls for 1 minute in a 120-foot-high, 60-foot-radius Cylinder centered on the chosen point of origin. During that time, the area of effect is Lightly Obscured.</td>
    </tr>
    <tr>
      <td>41–45</td>
      <td>A cloud of 600 oversized butterflies fills a 60-foot-high, 30-foot-radius Cylinder centered on the chosen point of origin. The butterflies remain for 10 minutes, during which time the area of effect is Heavily Obscured.</td>
    </tr>
    <tr>
      <td>46–50</td>
      <td>You cast Lightning Bolt. The Line created by the spell extends from you to the chosen point of origin.</td>
    </tr>
    <tr>
      <td>51–55</td>
      <td>The creature closest to the chosen point of origin is enlarged as if you had cast Enlarge/ Reduce on it. If the target isn't you and can't be affected by that spell, you become the target instead.</td>
    </tr>
    <tr>
      <td>56–60</td>
      <td>A magically formed creature appears in an unoccupied space as close to the chosen point of origin as possible. The creature isn't under your control, acts as it normally would, and disappears after 1 hour or when it drops to 0 Hit Points. Roll 1d4 to determine which creature appears. On a 1, a Rhinoceros appears; on a 2, an Elephant appears; and on a 3–4, a Rat appears.</td>
    </tr>
    <tr>
      <td>61–64</td>
      <td>Grass covers a 60-foot-radius circle of ground, with the center of that circle as close to the chosen point of origin as possible. Grass that's already there grows to ten times its normal size and remains overgrown for 1 minute.</td>
    </tr>
  </tbody>
</table>

<table>
  <thead>
    <tr>
      <th>1d100</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>65–68</td>
      <td>An object of the GM's choice disappears into the Ethereal Plane. The object must be neither worn nor carried, within 120 feet of the chosen point of origin, and no larger than 10 feet in any dimension. If there are no such objects in range, nothing happens.</td>
    </tr>
    <tr>
      <td>69–72</td>
      <td>Nothing happens at the chosen point of origin. Instead, you shrink as if you had cast Enlarge/ Reduce on yourself and remain in that state for 1 minute.</td>
    </tr>
    <tr>
      <td>73–77</td>
      <td>Leaves grow from the creature nearest to the chosen point of origin. Unless they are picked off, the leaves turn brown and fall off after 24 hours.</td>
    </tr>
    <tr>
      <td>78–82</td>
      <td>Nothing happens at the chosen point of origin. Instead, a burst of colorful, shimmering light extends from you in a 30-foot Emanation. Each creature in the area must succeed on a DC 15 Constitution saving throw or have the Blinded condition for 1 minute. A creature repeats the save at the end of each of its turns, ending the effect on itself on a success.</td>
    </tr>
    <tr>
      <td>83–87</td>
      <td>Nothing happens at the chosen point of origin. Instead, you cast Invisibility on yourself.</td>
    </tr>
    <tr>
      <td>88–92</td>
      <td>Nothing happens at the chosen point of origin. Instead, a stream of 1d4 × 10 gems, each worth 1 GP, shoots from the wand's tip in a Line 30 feet long and 5 feet wide toward the chosen point of origin. Each gem deals 1 Bludgeoning damage, and the total damage of the gems is divided equally among all creatures in the Line.</td>
    </tr>
    <tr>
      <td>93–97</td>
      <td>You cast Polymorph, targeting the creature closest to the chosen point of origin. Roll 1d4 to determine the target's new form. On a 1, the new form is a Black Bear; on a 2, the new form is a Giant Wasp; on a 3–4, the new form is a Frog.</td>
    </tr>
    <tr>
      <td>98–00</td>
      <td>The creature closest to the chosen point of origin makes a DC 15 Constitution saving throw. On a failed save, the creature has the Restrained condition and begins to turn to stone. While Restrained in this way, the creature repeats the save at the end of its next turn. On a successful save, the effect ends. On a failed save, the creature has the Petrified condition instead of the Restrained condition. The petrification lasts until the creature is freed by the Greater Restoration spell or similar magic.</td>
    </tr>
  </tbody>
</table>

#### Weapon, +1, +2, or +3

_Weapon (Any Simple or Martial), Uncommon (+1), Rare (+2), or Very Rare (+3)_

You have a bonus to attack rolls and damage rolls made with this magic weapon. The bonus is determined by the weapon's rarity.

#### Weapon of Warning

_Weapon (Any Simple or Martial), Uncommon (Requires Attunement)_

As long as this weapon is within your reach and you are attuned to it, you and allies within 30 feet of you gain the following benefits.

_Alarm._ The weapon magically awakens each subject who is sleeping naturally when combat begins. This benefit doesn't wake a subject from magically induced sleep.

_Supernatural Readiness._ Each subject has Advantage on its Initiative rolls.

#### Well of Many Worlds

_Wondrous Item, Legendary_

This fine black cloth, soft as silk, is folded up to the dimensions of a handkerchief. It unfolds into a circular sheet 6 feet in diameter.

You can take a Magic action to unfold the _Well of Many Worlds_ and place it on a solid surface, whereupon it forms a two-way, 6-foot-diameter, circular portal to another world or plane of existence. Each time the item opens a portal, the GM decides where it leads. The portal remains open until a creature within 5 feet of it takes a Magic action to close it by taking hold of the edges of the cloth and folding it up.

Once the _Well of Many Worlds_ has opened a portal, it can't do so again for 1d8 hours.

#### Wind Fan

_Wondrous Item, Uncommon_

While holding this fan, you can cast _Gust of Wind_ (save DC 13) from it. Each subsequent time the fan is used before the next dawn, it has a cumulative 20 percent chance of not working; if the fan fails to work, it tears into useless, nonmagical tatters.

#### Winged Boots

_Wondrous Item, Uncommon (Requires Attunement)_

These boots have 4 charges and regain 1d4 expended charges daily at dawn. While wearing the boots, you can take a Magic action to expend 1 charge, gaining a Fly Speed of 30 feet for 1 hour. If you are flying when the duration expires, you descend at a rate of 30 feet per round until you land.

#### Wings of Flying

_Wondrous Item, Rare (Requires Attunement)_

While wearing this cloak, you can take a Magic action to turn the cloak into a pair of wings on your back. The wings lasts for 1 hour or until you end the effect early as a Magic action. The wings give you a Fly Speed of 60 feet. If you are aloft when the wings disappear, you fall. When the wings disappear, you can't use them again for 1d12 hours.
