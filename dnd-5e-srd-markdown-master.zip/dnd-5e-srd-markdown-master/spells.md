﻿# Spells

## Gaining Spells

Before you can cast a spell, you must have the spell prepared in your mind or have access to the spell from a magic item, such as a _Spell Scroll_. Your features specify which spells you have access to, if any; whether you always have certain spells prepared; and whether you can change the list of spells you have prepared.

### Preparing Spells

If you have a list of level 1+ spells you prepare, your spellcasting feature specifies when you can change the list and the number of spells you can change, as summarized in the Spell Preparation by Class table.

**Spell Preparation by Class**

<table>
  <thead>
    <tr>
      <th>Class</th>
      <th>Change When You…</th>
      <th>Number of Spells</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Bard</td>
      <td>Gain a level</td>
      <td>One</td>
    </tr>
    <tr>
      <td>Cleric</td>
      <td>Finish a Long Rest</td>
      <td>Any</td>
    </tr>
    <tr>
      <td>Druid</td>
      <td>Finish a Long Rest</td>
      <td>Any</td>
    </tr>
    <tr>
      <td>Paladin</td>
      <td>Finish a Long Rest</td>
      <td>One</td>
    </tr>
    <tr>
      <td>Ranger</td>
      <td>Finish a Long Rest</td>
      <td>One</td>
    </tr>
    <tr>
      <td>Sorcerer</td>
      <td>Gain a level</td>
      <td>One</td>
    </tr>
    <tr>
      <td>Warlock</td>
      <td>Gain a level</td>
      <td>One</td>
    </tr>
    <tr>
      <td>Wizard</td>
      <td>Finish a Long Rest</td>
      <td>Any</td>
    </tr>
  </tbody>
</table>

Most spellcasting monsters don't change their lists of prepared spells, but the GM is free to alter them.

### Always-Prepared Spells

Certain features might give you a spell that you always have prepared. If you also have a list of prepared spells that you can change, a spell that you always have prepared doesn't count against the number of spells on that list.

## Casting Spells

Each spell description has a series of entries that provide the details needed to cast the spell. The following sections explain each of those entries, which follow a spell's name.

> **Casting in Armor**
>
> You must have training with any armor you are wearing to cast spells while wearing it. You are otherwise too hampered by the armor for spellcasting.

### Spell Level

Every spell has a level from 0 to 9, which is indicated in a spell's description. A spell's level is an indicator of how powerful it is. Cantrips—simple spells that can be cast almost by rote—are level 0. The rules for each spellcasting class say when its members gain access to spells of certain levels.

#### Spell Slots

Spellcasting is taxing, so a spellcaster can cast only a limited number of level 1+ spells before resting. Spell slots are the main way a spellcaster's magical potential is represented. Each spellcasting class gives its members a limited number of spell slots of certain spell levels. For example, a level 3 Wizard has four level 1 spell slots and two level 2 slots.

When you cast a spell, you expend a slot of that spell's level or higher, effectively "filling" a slot with the spell. Imagine a spell slot is a groove of a certain size—small for a level 1 slot and larger for a higher-level spell. A level 1 spell fits into a slot of any size, but a level 2 spell fits only into a slot that's at least level 2. So when a level 3 Wizard casts _Magic Missile_, a level 1 spell, that Wizard spends one of four level 1 slots and has three remaining.

Finishing a Long Rest restores any expended spell slots.

#### Casting without Slots

There are several ways to cast a spell without expending a spell slot:

**Cantrips.** A cantrip is cast without a spell slot.

**Rituals.** Certain spells have the Ritual tag in the Casting Time entry. Such a spell can be cast following the normal rules for spellcasting, or it can be cast as a Ritual. The Ritual version of a spell takes 10 minutes longer to cast than normal, but it doesn't expend a spell slot. To cast a spell as a Ritual, a spellcaster must have it prepared.

**Special Abilities.** Some characters and monsters have special abilities that allow them to cast specific spells without a spell slot. This casting is usually limited in another way, such as being able to cast the spell a limited number of times per day.

**Magic Items.** _Spell Scrolls_ and some other magic items contain spells that can be cast without a spell slot. The description of such an item specifies how many times a spell can be cast from it.

#### Using a Higher-Level Spell Slot

When a spellcaster casts a spell using a slot that is of a higher level than the spell, the spell takes on the higher level for that casting. For instance, if a Wizard casts _Magic Missile_ using a level 2 slot, that _Magic Missile_ is level 2. Effectively, the spell expands to fill the slot it is put into.
Some spells, such as _Magic Missile_ and _Cure Wounds_, have more powerful effects when cast at a higher level, as detailed in a spell's description.

### School of Magic

Each spell belongs to a school of magic. The schools are listed in the Schools of Magic table. These categories help describe spells but have no rules of their own, although some other rules refer to them.

**Schools of Magic**

<table>
  <thead>
    <tr>
      <th>School</th>
      <th>Typical Effects</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Abjuration</td>
      <td>Prevents or reverses harmful effects</td>
    </tr>
    <tr>
      <td>Conjuration</td>
      <td>Transports creatures or objects</td>
    </tr>
    <tr>
      <td>Divination</td>
      <td>Reveals information</td>
    </tr>
    <tr>
      <td>Enchantment</td>
      <td>Influences minds</td>
    </tr>
    <tr>
      <td>Evocation</td>
      <td>Channels energy to create effects that are often destructive</td>
    </tr>
    <tr>
      <td>Illusion</td>
      <td>Deceives the mind or senses</td>
    </tr>
    <tr>
      <td>Necromancy</td>
      <td>Manipulates life and death</td>
    </tr>
    <tr>
      <td>Transmutation</td>
      <td>Transforms creatures or objects</td>
    </tr>
  </tbody>
</table>

### Class Spell Lists

If a spell is on a class's spell list, the class's name appears in parentheses after the spell's school of magic. Some features add a spell to a character's spell list even if the character isn't a member of a class in the parentheses.

## Casting Time

Most spells require the Magic action to cast, but some spells require a Bonus Action, a Reaction, or 1 minute or more. A spell's Casting Time entry specifies which of those is required.

### One Spell with a Spell Slot per Turn

On a turn, you can expend only one spell slot to cast a spell. This rule means you can't, for example, cast a spell with a spell slot using the Magic action and another one using a Bonus Action on the same turn.

### Reaction and Bonus Action Triggers

A spell that has a casting time of a Reaction is cast in response to a trigger that is defined in the spell's Casting Time entry. Some spells that have a casting time of a Bonus Action are also cast in response to a trigger defined in the spell.

### Longer Casting Times

Certain spells—including a spell cast as a Ritual—require more time to cast: minutes or even hours. While you cast a spell with a casting time of 1 minute or more, you must take the Magic action on each of your turns, and you must maintain Concentration (see "Rules Glossary") while you do so. If your Concentration is broken, the spell fails, but you don't expend a spell slot. To cast the spell again, you must start over.

## Range

A spell's range indicates how far from the spellcaster the spell's effect can originate, and the spell's description specifies which part of the effect is limited by the range.

A range usually takes one of the following forms:

**Distance**. The range is expressed in feet.

**Touch**. The spell's effect originates on something, as defined by the spell, that the spellcaster must touch within their reach.

**Self**. The spell is cast on the spellcaster or emanates from them, as specified in the spell.

If a spell has movable effects, they aren't restricted by its range unless the spell's description says otherwise.

## Components

A spell's components are physical requirements the spellcaster must meet to cast the spell. Each spell's description indicates whether it requires Verbal (V), Somatic (S), or Material (M) components. If the spellcaster can't provide one or more of a spell's components, the spellcaster can't cast the spell.

### Verbal (V)

A Verbal component is the chanting of esoteric words that sound like nonsense to the uninitiated. The words must be uttered in a normal speaking voice. The words themselves aren't the source of the spell's power; rather, the particular combination of sounds, with specific pitch and resonance, sets the threads of magic in motion. Thus, a creature who is gagged or in an area of magical silence can't cast a spell with a Verbal component.

### Somatic (S)

A Somatic component is a forceful gesticulation or an intricate set of gestures. A spellcaster must use at least one of their hands to perform these movements.

### Material (M)

A Material component is a particular material used in a spell's casting, as specified in parentheses in the Components entry. These materials aren't consumed by the spell unless the spell's description states otherwise. The spellcaster must have a hand free to access them, but it can be the same hand used to perform Somatic components, if any.

If a spell doesn't consume its materials and doesn't specify a cost for them, a spellcaster can use a Component Pouch (see "Equipment") instead of providing the materials specified in the spell, or the
spellcaster can substitute a Spellcasting Focus if the caster has a feature that allows that substitution. To use a Component Pouch, you must have a hand free to reach into it, and to use a Spellcasting Focus, you must hold it unless its description says otherwise (see "Equipment" for descriptions).

## Duration

A spell's duration is the length of time the spell persists after it is cast. A duration typically takes one of the following forms:

**Concentration.** A duration that requires Concentration follows the Concentration rules (see "Rules Glossary").

**Instantaneous.** An instantaneous duration means the spell's magic appears only for a moment and then disappears.

**Time Span.** A duration that provides a time span specifies how long the spell lasts in rounds, minutes, hours, or the like. For example, a Duration entry might say "1 minute," meaning the spell ends after 1 minute has passed. While a time-span spell that you cast is ongoing, you can dismiss it (no action required) if you don't have the Incapacitated condition.

## Effects

The effects of a spell are detailed after its duration entry. Those details present exactly what the spell does, which ignores mundane physical laws; any outcomes beyond those effects are under the GM's purview. Whatever the effects, they typically deal with targets, saving throws, attack rolls, or all three, each of which is detailed below.

## Targets

A typical spell requires the caster to pick one or more targets to be affected by the spell's magic. A spell's description says whether the spell targets creatures, objects, or something else.

_A Clear Path to the Target._ To target something with a spell, a caster must have a clear path to it, so it can't be behind Total Cover.

_Targeting Yourself._ If a spell targets a creature of your choice, you can choose yourself unless the creature must be Hostile or specifically a creature other than you.

_Areas of Effect._ Some spells, such as _Thunderwave_, cover an area called an area of effect, which is defined in "Rules Glossary." The area determines what the spell targets. The description of a spell specifies whether it has an area of effect, which is typically one of these shapes: Cone, Cube, Cylinder, Emanation, Line, or Sphere.

_Awareness of Being Targeted._ Unless a spell has a perceptible effect, a creature doesn't know it was targeted by the spell. An effect like lightning is obvious, but a more subtle effect, such as an attempt to read thoughts, goes unnoticed unless a spell's description says otherwise.

_Invalid Targets._ If you cast a spell on someone or something that can't be affected by it, nothing happens to that target, but if you used a spell slot to cast the spell, the slot is still expended.

If the spell normally has no effect on a target that succeeds on a saving throw, the invalid target appears to have succeeded on its saving throw, even though it didn't attempt one (giving no hint that the creature is an invalid target). Otherwise, you perceive that the spell did nothing to the target.

## Saving Throws

Many spells specify that a target makes a saving throw to avoid some or all of a spell's effects. The spell specifies the ability that the target uses for the save and what happens on a success or failure. Here's how to calculate the DC for your spells:

**Spell save DC** = 8 + your spellcasting ability modifier + your Proficiency Bonus

## Attack Rolls

Some spells require the caster to make an attack roll to determine whether the spell hits a target. Here's how to calculate the attack modifier for your spells:

**Spell attack modifier** = your spellcasting ability modifier + your Proficiency Bonus

## Combining Spell Effects

The effects of different spells add together while their durations overlap. In contrast, the effects of the same spell cast multiple times don't combine. Instead, the most potent effect—such as the highest bonus—from those castings applies while their durations overlap. The most recent effect applies if the castings are equally potent and their durations overlap. For example, if two Clerics cast _Bless_ on the same target, that target gains the spell's benefit only once; the target doesn't receive two bonus dice. But if the durations of the spells overlap, the effect continues until the duration of the second _Bless_ ends.

> **IDENTIFYING AN ONGOING SPELL**
>
> You can try to identify a non-instantaneous spell by its observable effects if its duration is ongoing. To identify it, you must take the Study action and succeed on a DC 15 Intelligence (Arcana) check.

## Spell Descriptions

#### Acid Arrow

_Level 2 Evocation (Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (powdered rhubarb leaf)
**Duration:** Instantaneous

A shimmering green arrow streaks toward a target within range and bursts in a spray of acid. Make a ranged spell attack against the target. On a hit, the target takes 4d4 Acid damage and 2d4 Acid damage at the end of its next turn. On a miss, the arrow splashes the target with acid for half as much of the initial damage only.

_Using a Higher-Level Spell Slot._ The damage (both initial and later) increases by 1d4 for each spell slot level above 2.

#### Acid Splash

_Evocation Cantrip (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You create an acidic bubble at a point within range, where it explodes in a 5-foot-radius Sphere. Each creature in that Sphere must succeed on a Dexterity saving throw or take 1d6 Acid damage.

_Cantrip Upgrade._ The damage increases by 1d6 when you reach levels 5 (2d6), 11 (3d6), and 17 (4d6).

#### Aid

_Level 2 Abjuration (Bard, Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a strip of white cloth)
**Duration:** 8 hours

Choose up to three creatures within range. Each target's Hit Point maximum and current Hit Points increase by 5 for the duration.

_Using a Higher-Level Spell Slot._ Each target's Hit Points increase by 5 for each spell slot level above 2.

#### Alarm

_Level 1 Abjuration (Ranger, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** 30 feet
**Components:** V, S, M (a bell and silver wire)
**Duration:** 8 hours

You set an alarm against intrusion. Choose a door, a window, or an area within range that is no larger than a 20-foot Cube. Until the spell ends, an alarm alerts you whenever a creature touches or enters the warded area. When you cast the spell, you can designate creatures that won't set off the alarm. You also choose whether the alarm is audible or mental:

**Audible Alarm.** The alarm produces the sound of a handbell for 10 seconds within 60 feet of the warded area.

**Mental Alarm.** You are alerted by a mental ping if you are within 1 mile of the warded area. This ping awakens you if you're asleep.

#### Alter Self

_Level 2 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 1 hour

You alter your physical form. Choose one of the following options. Its effects last for the duration, during which you can take a Magic action to replace the option you chose with a different one.

_Aquatic Adaptation._ You sprout gills and grow webs between your fingers. You can breathe underwater and gain a Swim Speed equal to your Speed.

_Change Appearance._ You alter your appearance. You decide what you look like, including your height, weight, facial features, sound of your voice, hair length, coloration, and other distinguishing characteristics. You can make yourself appear as a member of another species, though none of your statistics change. You can't appear as a creature of a different size, and your basic shape stays the same; if you're bipedal, you can't use this spell to become quadrupedal, for instance. For the duration, you can take a Magic action to change your appearance in this way again.

_Natural Weapons._ You grow claws (Slashing), fangs (Piercing), horns (Piercing), or hooves (Bludgeoning). When you use your Unarmed Strike to deal damage with that new growth, it deals 1d6 damage of the type in parentheses instead of dealing the normal damage for your Unarmed Strike, and you use your spellcasting ability modifier for the attack and damage rolls rather than using Strength.

#### Animal Friendship

_Level 1 Enchantment (Bard, Druid, Ranger)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a morsel of food)
**Duration:** 24 hours

Target a Beast that you can see within range. The target must succeed on a Wisdom saving throw or have the Charmed condition for the duration. If you
or one of your allies deals damage to the target, the spells ends.

_Using a Higher-Level Spell Slot._ You can target one additional Beast for each spell slot level above 1.

#### Animal Messenger

_Level 2 Enchantment (Bard, Druid, Ranger)_

**Casting Time:** Action or Ritual
**Range:** 30 feet
**Components:** V, S, M (a morsel of food)
**Duration:** 24 hours

A Tiny Beast of your choice that you can see within range must succeed on a Charisma saving throw, or it attempts to deliver a message for you (if the target's Challenge Rating isn't 0, it automatically succeeds). You specify a location you have visited and a recipient who matches a general description, such as "a person dressed in the uniform of the town guard" or "a red-haired dwarf wearing a pointed hat." You also communicate a message of up to twenty-five words. The Beast travels for the duration toward the specified location, covering about 25 miles per 24 hours or 50 miles if the Beast can fly.

When the Beast arrives, it delivers your message to the creature that you described, mimicking your communication. If the Beast doesn't reach its destination before the spell ends, the message is lost, and the Beast returns to where you cast the spell.

_Using a Higher-Level Spell Slot._ The spell's duration increases by 48 hours for each spell slot level above 2.

#### Animal Shapes

_Level 8 Transmutation (Druid)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** 24 hours

Choose any number of willing creatures that you can see within range. Each target shape-shifts into a Large or smaller Beast of your choice that has a Challenge Rating of 4 or lower. You can choose a different form for each target. On later turns, you can take a Magic action to transform the targets again.

A target's game statistics are replaced by the chosen Beast's statistics, but the target retains its creature type; Hit Points; Hit Point Dice; alignment; ability to communicate; and Intelligence, Wisdom, and Charisma scores. The target's actions are limited by the Beast form's anatomy, and it can't cast spells. The target's equipment melds into the new form, and the target can't use any of that equipment while in that form.

The target gains a number of Temporary Hit Points equal to the Hit Points of the first form into which it shape-shifts. These Temporary Hit Points vanish if any remain when the spell ends. The transformation lasts for the duration or until the target ends it as a Bonus Action.

#### Animate Dead

_Level 3 Necromancy (Cleric, Wizard)_

**Casting Time:** 1 minute
**Range:** 10 feet
**Components:** V, S, M (a drop of blood, a piece of flesh, and a pinch of bone dust)
**Duration:** Instantaneous

Choose a pile of bones or a corpse of a Medium or Small Humanoid within range. The target becomes an Undead creature: a **Skeleton** if you chose bones or a **Zombie** if you chose a corpse (see "Monsters" for the stat blocks).

On each of your turns, you can take a Bonus Action to mentally command any creature you made with this spell if the creature is within 60 feet of you (if you control multiple creatures, you can command any of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move on its next turn, or you can issue a general command, such as to guard a chamber or corridor. If you issue no commands, the creature takes the Dodge action and moves only to avoid harm. Once given an order, the creature continues to follow it until its task is complete.

The creature is under your control for 24 hours, after which it stops obeying any command you've given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature again before the current 24-hour period ends. This use of the spell reasserts your control over up to four creatures you have animated with this spell rather than animating a new creature.

_Using a Higher-Level Spell Slot._ You animate or reassert control over two additional Undead creatures for each spell slot level above 3. Each of the creatures must come from a different corpse or pile of bones.

#### Animate Objects

_Level 5 Transmutation (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

Objects animate at your command. Choose a number of nonmagical objects within range that aren't being worn or carried, aren't fixed to a surface, and aren't Gargantuan. The maximum number of objects is equal to your spellcasting ability modifier; for this number, a Medium or smaller target counts as
one object, a Large target counts as two, and a Huge target counts as three.

Each target animates, sprouts legs, and becomes a Construct that uses the **Animated Object** stat block; this creature is under your control until the spell ends or until it is reduced to 0 Hit Points. Each creature you make with this spell is an ally to you and your allies. In combat, it shares your Initiative count and takes its turn immediately after yours.

Until the spell ends, you can take a Bonus Action to mentally command any creature you made with this spell if the creature is within 500 feet of you (if you control multiple creatures, you can command any of them at the same time, issuing the same command to each one). If you issue no commands, the creature takes the Dodge action and moves only to avoid harm. When the creature drops to 0 Hit Points, it reverts to its object form, and any remaining damage carries over to that form.

_Using a Higher-Level Spell Slot._ The creature's Slam damage increases by 1d4 (Medium or smaller), 1d6 (Large), or 1d12 (Huge) for each spell slot level above 5.

#### Animated Object

_Huge or Smaller Construct, Unaligned_

**AC** 15
**HP** 10 (Medium or smaller), 20 (Large), 40 (Huge)
**Speed** 30 ft.

<table>
  <tbody>
    <tr>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td colspan="4"></td>
    </tr>
    <tr>
      <td>STR</td>
      <td>16</td>
      <td>+3</td>
      <td>+3</td>
      <td>DEX</td>
      <td>10</td>
      <td>+0</td>
      <td>+0</td>
      <td>CON</td>
      <td>10</td>
      <td>+0</td>
      <td>+0</td>
    </tr>
    <tr>
      <td>INT</td>
      <td>3</td>
      <td>−4</td>
      <td>−4</td>
      <td>WIS</td>
      <td>3</td>
      <td>−4</td>
      <td>−4</td>
      <td>CHA</td>
      <td>1</td>
      <td>−5</td>
      <td>−5</td>
    </tr>
  </tbody>
</table>

**Immunities** Poison, Psychic; Charmed, Exhaustion, Frightened, Paralyzed, Poisoned
**Senses** Blindsight 30 ft.; Passive Perception 6
**Languages** Understands the languages you know
**CR** None (XP 0; PB equals your Proficiency Bonus)

#### Actions

_Slam._ _Melee Attack Roll:_ Bonus equals your spell attack modifier, reach 5 ft. _Hit:_ Force damage equal to 1d4 + 3 (Medium or smaller), 2d6 + 3 + your spellcasting ability modifier (Large), or 2d12 + 3 + your spellcasting ability modifier (Huge).

#### Antilife Shell

_Level 5 Abjuration (Druid)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 1 hour

An aura extends from you in a 10-foot Emanation for the duration. The aura prevents creatures other than Constructs and Undead from passing or reaching through it. An affected creature can cast spells or make attacks with Ranged or Reach weapons through the barrier.

If you move so that an affected creature is forced to pass through the barrier, the spell ends.

#### Antimagic Field

_Level 8 Abjuration (Cleric, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (iron filings)
**Duration:** Concentration, up to 1 hour

An aura of antimagic surrounds you in 10-foot Emanation. No one can cast spells, take Magic actions, or create other magical effects inside the aura, and those things can't target or otherwise affect anything inside it. Magical properties of magic items don't work inside the aura or on anything inside it.

Areas of effect created by spells or other magic can't extend into the aura, and no one can teleport into or out of it or use planar travel there. Portals close temporarily while in the aura.

Ongoing spells, except those cast by an Artifact or a deity, are suppressed in the area. While an effect is suppressed, it doesn't function, but the time it spends suppressed counts against its duration.

_Dispel Magic_ has no effect on the aura, and the auras created by different _Antimagic Field_ spells don't nullify each other.

#### Antipathy/Sympathy

_Level 8 Enchantment (Bard, Druid, Wizard)_

**Casting Time:** 1 hour
**Range:** 60 feet
**Components:** V, S, M (a mix of vinegar and honey)
**Duration:** 10 days

As you cast the spell, choose whether it creates antipathy or sympathy, and target one creature or object that is Huge or smaller. Then specify a kind of creature, such as red dragons, goblins, or vampires. A creature of the chosen kind makes a Wisdom saving throw when it comes within 120 feet of the target. Your choice of antipathy or sympathy determines what happens to a creature when it fails that save:

**Antipathy.** The creature has the Frightened condition. The Frightened creature must use its movement on its turns to get as far away as possible from the target, moving by the safest route.

**Sympathy.** The creature has the Charmed condition. The Charmed creature must use its movement on its turns to get as close as possible to the target, moving by the safest route. If the creature is within 5 feet of the target, the creature can't willingly move away. If the target damages the Charmed creature, that creature can make a
Wisdom saving throw to end the effect, as described below.

_Ending the Effect._ If the Frightened or Charmed creature ends its turn more than 120 feet away from the target, the creature makes a Wisdom saving throw. On a successful save, the creature is no longer affected by the target. A creature that successfully saves against this effect is immune to it for 1 minute, after which it can be affected again.

#### Arcane Eye

_Level 4 Divination (Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a bit of bat fur)
**Duration:** Concentration, up to 1 hour

You create an Invisible, invulnerable eye within range that hovers for the duration. You mentally receive visual information from the eye, which can see in every direction. It also has Darkvision with a range of 30 feet.

As a Bonus Action, you can move the eye up to 30 feet in any direction. A solid barrier blocks the eye's movement, but the eye can pass through an opening as small as 1 inch in diameter.

#### Arcane Hand

_Level 5 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (an eggshell and a glove)
**Duration:** Concentration, up to 1 minute

You create a Large hand of shimmering magical energy in an unoccupied space that you can see within range. The hand lasts for the duration, and it moves at your command, mimicking the movements of your own hand.

The hand is an object that has AC 20 and Hit Points equal to your Hit Point maximum. If it drops to 0 Hit Points, the spell ends. The hand doesn't occupy its space.

When you cast the spell and as a Bonus Action on your later turns, you can move the hand up to 60 feet and then cause one of the following effects:

**Clenched Fist.** The hand strikes a target within 5 feet of it. Make a melee spell attack. On a hit, the target takes 5d8 Force damage.

**Forceful Hand.** The hand attempts to push a Huge or smaller creature within 5 feet of it. The target must succeed on a Strength saving throw, or the hand pushes the target up to 5 feet plus a number of feet equal to five times your spellcasting ability modifier. The hand moves with the target, remaining within 5 feet of it.

**Grasping Hand.** The hand attempts to grapple a Huge or smaller creature within 5 feet of it. The target must succeed on a Dexterity saving throw, or the target has the Grappled condition, with an escape DC equal to your spell save DC. While the hand grapples the target, you can take a Bonus Action to cause the hand to crush it, dealing Bludgeoning damage to the target equal to 4d6 plus your spellcasting ability modifier.

**Interposing Hand.** The hand grants you Half Cover against attacks and other effects that originate from its space or that pass through it. In addition, its space counts as Difficult Terrain for your enemies.

_Using a Higher-Level Spell Slot._ The damage of the Clenched Fist increases by 2d8 and the damage of the Grasping Hand increases by 2d6 for each spell slot level above 5.

#### Arcane Lock

_Level 2 Abjuration (Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (gold dust worth 25+ GP, which the spell consumes)
**Duration:** Until dispelled

You touch a closed door, window, gate, container, or hatch and magically lock it for the duration. This lock can't be unlocked by any nonmagical means. You and any creatures you designate when you cast the spell can open and close the object despite the lock. You can also set a password that, when spoken within 5 feet of the object, unlocks it for 1 minute.

#### Arcane Sword

_Level 7 Evocation (Bard, Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (a miniature sword worth 250+ GP)
**Duration:** Concentration, up to 1 minute

You create a spectral sword that hovers within range. It lasts for the duration.

When the sword appears, you make a melee spell attack against a target within 5 feet of the sword. On a hit, the target takes Force damage equal to 4d12 plus your spellcasting ability modifier.

On your later turns, you can take a Bonus Action to move the sword up to 30 feet to a spot you can see and repeat the attack against the same target or a different one.

#### Arcanist's Magic Aura

_Level 2 Illusion (Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a small square of silk)
**Duration:** 24 hours

With a touch, you place an illusion on a willing creature or an object that isn't being worn or carried. A creature gains the Mask effect below, and an object gains the False Aura effect below. The effect lasts for the duration. If you cast the spell on the same target every day for 30 days, the illusion lasts until dispelled.

_Mask (Creature)._ Choose a creature type other than the target's actual type. Spells and other magical effects treat the target as if it were a creature of the chosen type.

_False Aura (Object)._ You change the way the target appears to spells and magical effects that detect magical auras, such as _Detect Magic_. You can make a nonmagical object appear magical, make a magic item appear nonmagical, or change the object's aura so that it appears to belong to a school of magic you choose.

#### Astral Projection

_Level 9 Necromancy (Cleric, Warlock, Wizard)_

**Casting Time:** 1 hour
**Range:** 10 feet
**Components:** V, S, M (for each of the spell's targets, one jacinth worth 1,000+ GP and one silver bar worth 100+ GP, all of which the spell consumes)
**Duration:** Until dispelled

You and up to eight willing creatures within range project your astral bodies into the Astral Plane (the spell ends instantly if you are already on that plane). Each target's body is left behind in a state of suspended animation; it has the Unconscious condition, doesn't need food or air, and doesn't age.

A target's astral form resembles its body in almost every way, replicating its game statistics and possessions. The principal difference is the addition of a silvery cord that trails from between the shoulder blades of the astral form. The cord fades from view after 1 foot. If the cord is cut—which happens only when an effect states that it does so—the target's body and astral form both die.

A target's astral form can travel through the Astral Plane. The moment an astral form leaves that plane, the target's body and possessions travel along the silver cord, causing the target to re-enter its body on the new plane.

Any damage or other effects that apply to an astral form have no effect on the target's body and vice versa. If a target's body or astral form drops to 0 Hit Points, the spell ends for that target. The spell ends for all the targets if you take a Magic action to dismiss it.

When the spell ends for a target who isn't dead, the target reappears in its body and exits the state of suspended animation.

#### Augury

_Level 2 Divination (Cleric, Druid, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Self
**Components:** V, S, M (specially marked sticks, bones, cards, or other divinatory tokens worth 25+ GP)
**Duration:** Instantaneous

You receive an omen from an otherworldly entity about the results of a course of action that you plan to take within the next 30 minutes. The GM chooses the omen from the Omens table.

**Omens**

<table>
  <thead>
    <tr>
      <th>Omen</th>
      <th>For Results That Will Be …</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Weal</td>
      <td>Good</td>
    </tr>
    <tr>
      <td>Woe</td>
      <td>Bad</td>
    </tr>
    <tr>
      <td>Weal and woe</td>
      <td>Good and bad</td>
    </tr>
    <tr>
      <td>Indifference</td>
      <td>Neither good nor bad</td>
    </tr>
  </tbody>
</table>

The spell doesn't account for circumstances, such as other spells, that might change the results.

If you cast the spell more than once before finishing a Long Rest, there is a cumulative 25 percent chance for each casting after the first that you get no answer.

#### Aura of Life

_Level 4 Abjuration (Cleric, Paladin)_

**Casting Time:** Action
**Range:** Self
**Components:** V
**Duration:** Concentration, up to 10 minutes

An aura radiates from you in a 30-foot Emanation for the duration. While in the aura, you and your allies have Resistance to Necrotic damage, and your Hit Point maximums can't be reduced. If an ally with 0 Hit Points starts its turn in the aura, that ally regains 1 Hit Point.

#### Awaken

_Level 5 Transmutation (Bard, Druid)_

**Casting Time:** 8 hours
**Range:** Touch
**Components:** V, S, M (an agate worth 1,000+ GP, which the spell consumes)
**Duration:** Instantaneous

You spend the casting time tracing magical pathways within a precious gemstone, and then touch the target. The target must be either a Beast or Plant creature with an Intelligence of 3 or less or a natural plant that isn't a creature. The target gains
an Intelligence of 10 and the ability to speak one language you know. If the target is a natural plant, it becomes a Plant creature and gains the ability to move its limbs, roots, vines, creepers, and so forth, and it gains senses similar to a human's. The GM chooses statistics appropriate for the awakened Plant, such as the statistics for the **Awakened Shrub** or **Awakened Tree** in "Monsters."

The awakened target has the Charmed condition for 30 days or until you or your allies deal damage to it. When that condition ends, the awakened creature chooses its attitude toward you.

#### Bane

_Level 1 Enchantment (Bard, Cleric, Warlock)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a drop of blood)
**Duration:** Concentration, up to 1 minute

Up to three creatures of your choice that you can see within range must each make a Charisma saving throw. Whenever a target that fails this save makes an attack roll or a saving throw before the spell ends, the target must subtract 1d4 from the attack roll or save.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Banishment

_Level 4 Abjuration (Cleric, Paladin, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a pentacle)
**Duration:** Concentration, up to 1 minute

One creature that you can see within range must succeed on a Charisma saving throw or be transported to a harmless demiplane for the duration. While there, the target has the Incapacitated condition. When the spell ends, the target reappears in the space it left or in the nearest unoccupied space if that space is occupied.

If the target is an Aberration, a Celestial, an Elemental, a Fey, or a Fiend, the target doesn't return if the spell lasts for 1 minute. The target is instead transported to a random location on a plane (GM's choice) associated with its creature type.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 4.

#### Barkskin

_Level 2 Transmutation (Druid, Ranger)_

**Casting Time:** Bonus Action
**Range:** Touch

**Component:** V, S, M (a handful of bark)
**Duration:** 1 hour

You touch a willing creature. Until the spell ends, the target's skin assumes a bark-like appearance, and the target has an Armor Class of 17 if its AC is lower than that.

#### Beacon of Hope

_Level 3 Abjuration (Cleric)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

Choose any number of creatures within range. For the duration, each target has Advantage on Wisdom saving throws and Death Saving Throws and regains the maximum number of Hit Points possible from any healing.

#### Befuddlement

_Level 8 Enchantment (Bard, Druid, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a key ring with no keys)
**Duration:** Instantaneous

You blast the mind of a creature that you can see within range. The target makes an Intelligence saving throw.

On a failed save, the target takes 10d12 Psychic damage and can't cast spells or take the Magic action. At the end of every 30 days, the target repeats the save, ending the effect on a success. The effect can also be ended by the _Greater Restoration_, _Heal_, or _Wish_ spell.

On a successful save, the target takes half as much damage only.

#### Bestow Curse

_Level 3 Necromancy (Bard, Cleric, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You touch a creature, which must succeed on a Wisdom saving throw or become cursed for the duration. Until the curse ends, the target suffers one of the following effects of your choice:

- Choose one ability. The target has Disadvantage on ability checks and saving throws made with that ability.
- The target has Disadvantage on attack rolls against you.
- In combat, the target must succeed on a Wisdom saving throw at the start of each of its turns or be forced to take the Dodge action on that turn.
  • If you deal damage to the target with an attack roll or a spell, the target takes an extra 1d8 Necrotic damage.

_Using a Higher-Level Spell Slot._ If you cast this spell using a level 4 spell slot, you can maintain Concentration on it for up to 10 minutes. If you use a level 5+ spell slot, the spell doesn't require Concentration, and the duration becomes 8 hours (level 5–6 slot) or 24 hours (level 7–8 slot). If you use a level 9 spell slot, the spell lasts until dispelled.

#### Black Tentacles

_Level 4 Conjuration (Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (a tentacle)
**Duration:** Concentration, up to 1 minute

Squirming, ebony tentacles fill a 20-foot square on ground that you can see within range. For the duration, these tentacles turn the ground in that area into Difficult Terrain.

Each creature in that area makes a Strength saving throw. On a failed save, it takes 3d6 Bludgeoning damage, and it has the Restrained condition until the spell ends. A creature also makes that save if it enters the area or ends it turn there. A creature makes that save only once per turn.

A Restrained creature can take an action to make a Strength (Athletics) check against your spell save DC, ending the condition on itself on a success.

#### Blade Barrier

_Level 6 Evocation (Cleric)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You create a wall of whirling blades made of magical energy. The wall appears within range and lasts for the duration. You make a straight wall up to 100 feet long, 20 feet high, and 5 feet thick, or a ringed wall up to 60 feet in diameter, 20 feet high, and 5 feet thick. The wall provides Three-Quarters Cover, and its space is Difficult Terrain.

Any creature in the wall's space makes a Dexterity saving throw, taking 6d10 Force damage on a failed save or half as much damage on a successful one. A creature also makes that save if it enters the wall's space or ends it turn there. A creature makes that save only once per turn.

#### Bless

_Level 1 Enchantment (Cleric, Paladin)_

**Casting Time:** Action
**Range:** 30 feet

**Components:** V, S, M (a Holy Symbol worth 5+ GP)
**Duration:** Concentration, up to 1 minute

You bless up to three creatures within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target adds 1d4 to the attack roll or save.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Blight

_Level 4 Necromancy (Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Instantaneous

A creature that you can see within range makes a Constitution saving throw, taking 8d8 Necrotic damage on a failed save or half as much damage on a successful one. A Plant creature automatically fails the save.

Alternatively, target a nonmagical plant that isn't a creature, such as a tree or shrub. It doesn't make a save; it simply withers and dies.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 4.

#### Blindness/Deafness

_Level 2 Transmutation (Bard, Cleric, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V
**Duration:** 1 minute

One creature that you can see within range must succeed on a Constitution saving throw, or it has the Blinded or Deafened condition (your choice) for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 2.

#### Blink

_Level 3 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** 1 minute

Roll 1d6 at the end of each of your turns for the duration. On a roll of 4–6, you vanish from your current plane of existence and appear in the Ethereal Plane (the spell ends instantly if you are already on that plane). While on the Ethereal Plane, you can
perceive the plane you left, which is cast in shades of gray, but you can't see anything there more than 60 feet away. You can affect and be affected only by other creatures on the Ethereal Plane, and creatures on the other plane can't perceive you unless they have a special ability that lets them perceive things on the Ethereal Plane.

You return to the other plane at the start of your next turn and when the spell ends if you are on the Ethereal Plane. You return to an unoccupied space of your choice that you can see within 10 feet of the space you left. If no unoccupied space is available within that range, you appear in the nearest unoccupied space.

#### Blur

_Level 2 Illusion (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V
**Duration:** Concentration, up to 1 minute

Your body becomes blurred. For the duration, any creature has Disadvantage on attack rolls against you. An attacker is immune to this effect if it perceives you with Blindsight or Truesight.

#### Burning Hands

_Level 1 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Instantaneous

A thin sheet of flames shoots forth from you. Each creature in a 15-foot Cone makes a Dexterity saving throw, taking 3d6 Fire damage on a failed save or half as much damage on a successful one.

Flammable objects in the Cone that aren't being worn or carried start burning.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 1.

#### Call Lightning

_Level 3 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

A storm cloud appears at a point within range that you can see above yourself. It takes the shape of a Cylinder that is 10 feet tall with a 60-foot radius.

When you cast the spell, choose a point you can see under the cloud. A lightning bolt shoots from the cloud to that point. Each creature within 5 feet of that point makes a Dexterity saving throw, taking 3d10 Lightning damage on a failed save or half as much damage on a successful one.

Until the spell ends, you can take a Magic action to call down lightning in that way again, targeting the same point or a different one.

If you're outdoors in a storm when you cast this spell, the spell gives you control over that storm instead of creating a new one. Under such conditions, the spell's damage increases by 1d10.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 3.

#### Calm Emotions

_Level 2 Enchantment (Bard, Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

Each Humanoid in a 20-foot-radius Sphere centered on a point you choose within range must succeed on a Charisma saving throw or be affected by one of the following effects (choose for each creature):

- The creature has Immunity to the Charmed and Frightened conditions until the spell ends. If the creature was already Charmed or Frightened, those conditions are suppressed for the duration.
- The creature becomes Indifferent about creatures of your choice that it's Hostile toward. This indifference ends if the target takes damage or witnesses its allies taking damage. When the spell ends, the creature's attitude returns to normal.

#### Chain Lightning

_Level 6 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (three silver pins)
**Duration:** Instantaneous

You launch a lightning bolt toward a target you can see within range. Three bolts then leap from that target to as many as three other targets of your choice, each of which must be within 30 feet of the first target. A target can be a creature or an object and can be targeted by only one of the bolts.

Each target makes a Dexterity saving throw, taking 10d8 Lightning damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ One additional bolt leaps from the first target to another target for each spell slot level above 6.

#### Charm Monster

_Level 4 Enchantment (Bard, Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** 1 hour
One creature you can see within range makes a Wisdom saving throw. It does so with Advantage if you or your allies are fighting it. On a failed save, the target has the Charmed condition until the spell ends or until you or your allies damage it. The Charmed creature is Friendly to you. When the spell ends, the target knows it was Charmed by you.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 4.

#### Charm Person

_Level 1 Enchantment (Bard, Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** 1 hour

One Humanoid you can see within range makes a Wisdom saving throw. It does so with Advantage if you or your allies are fighting it. On a failed save, the target has the Charmed condition until the spell ends or until you or your allies damage it. The Charmed creature is Friendly to you. When the spell ends, the target knows it was Charmed by you.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Chill Touch

_Necromancy Cantrip (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

Channeling the chill of the grave, make a melee spell attack against a target within reach. On a hit, the target takes 1d10 Necrotic damage, and it can't regain Hit Points until the end of your next turn.

_Cantrip Upgrade._ The damage increases by 1d10 when you reach levels 5 (2d10), 11 (3d10), and 17 (4d10).

#### Chromatic Orb

_Level 1 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (a diamond worth 50+ GP)
**Duration:** Instantaneous

You hurl an orb of energy at a target within range. Choose Acid, Cold, Fire, Lightning, Poison, or Thunder for the type of orb you create, and then make a ranged spell attack against the target. On a hit, the target takes 3d8 damage of the chosen type.

If you roll the same number on two or more of the d8s, the orb leaps to a different target of your choice within 30 feet of the target. Make an attack roll against the new target, and make a new damage roll. The orb can't leap again unless you cast the spell with a level 2+ spell slot.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 1. The orb can leap a maximum number of times equal to the level of the slot expended, and a creature can be targeted only once by each casting of this spell.

#### Circle of Death

_Level 6 Necromancy (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (the powder of a crushed black pearl worth 500+ GP)
**Duration:** Instantaneous

Negative energy ripples out in a 60-foot-radius Sphere from a point you choose within range. Each creature in that area makes a Constitution saving throw, taking 8d8 Necrotic damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The damage increases by 2d8 for each spell slot level above 6.

#### Clairvoyance

_Level 3 Divination (Bard, Cleric, Sorcerer, Wizard)_

**Casting Time:** 10 minutes
**Range:** 1 mile
**Components:** V, S, M (a focus worth 100+ GP, either a jeweled horn for hearing or a glass eye for seeing)
**Duration:** Concentration, up to 10 minutes

You create an Invisible sensor within range in a location familiar to you (a place you have visited or seen before) or in an obvious location that is unfamiliar to you (such as behind a door, around a corner, or in a grove of trees). The intangible, invulnerable sensor remains in place for the duration.

When you cast the spell, choose seeing or hearing. You can use the chosen sense through the sensor as if you were in its space. As a Bonus Action, you can switch between seeing and hearing.

A creature that sees the sensor (such as a creature benefiting from _See Invisibility_ or Truesight) sees a luminous orb about the size of your fist.

#### Clone

_Level 8 Necromancy (Wizard)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (a diamond worth 1,000+ GP, which the spell consumes, and a sealable vessel worth 2,000+ GP that is large enough to hold the creature being cloned)
**Duration:** Instantaneous
You touch a creature or at least 1 cubic inch of its flesh. An inert duplicate of that creature forms inside the vessel used in the spell's casting and finishes growing after 120 days; you choose whether the finished clone is the same age as the creature or younger. The clone remains inert and endures indefinitely while its vessel remains undisturbed.

If the original creature dies after the clone finishes forming, the creature's soul transfers to the clone if the soul is free and willing to return. The clone is physically identical to the original and has the same personality, memories, and abilities, but none of the original's equipment. The creature's original remains, if any, become inert and can't be revived, since the creature's soul is elsewhere.

#### Cloudkill

_Level 5 Conjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You create a 20-foot-radius Sphere of yellow-green fog centered on a point within range. The fog lasts for the duration or until strong wind (such as the one created by _Gust of Wind_) disperses it, ending the spell. Its area is Heavily Obscured.

Each creature in the Sphere makes a Constitution saving throw, taking 5d8 Poison damage on a failed save or half as much damage on a successful one. A creature must also make this save when the Sphere moves into its space and when it enters the Sphere or ends its turn there. A creature makes this save only once per turn.

The Sphere moves 10 feet away from you at the start of each of your turns.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 5.

#### Color Spray

_Level 1 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a pinch of colorful sand)
**Duration:** Instantaneous

You launch a dazzling array of flashing, colorful light. Each creature in a 15-foot Cone originating from you must succeed on a Constitution saving throw or have the Blinded condition until the end of your next turn.

#### Command

_Level 1 Enchantment (Bard, Cleric, Paladin)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

You speak a one-word command to a creature you can see within range. The target must succeed on a Wisdom saving throw or follow the command on its next turn. Choose the command from these options:

**Approach.** The target moves toward you by the shortest and most direct route, ending its turn if it moves within 5 feet of you.

**Drop.** The target drops whatever it is holding and then ends its turn.

**Flee.** The target spends its turn moving away from you by the fastest available means.

**Grovel.** The target has the Prone condition and then ends its turn.

**Halt.** On its turn, the target doesn't move and takes no action or Bonus Action.

_Using a Higher-Level Spell Slot._ You can affect one additional creature for each spell slot level above 1.

#### Commune

_Level 5 Divination (Cleric)_

**Casting Time:** 1 minute or Ritual
**Range:** Self
**Components:** V, S, M (incense)
**Duration:** 1 minute

You contact a deity or a divine proxy and ask up to three questions that can be answered with yes or no. You must ask your questions before the spell ends. You receive a correct answer for each question.

Divine beings aren't necessarily omniscient, so you might receive "unclear" as an answer if a question pertains to information that lies beyond the deity's knowledge. In a case where a one-word answer could be misleading or contrary to the deity's interests, the GM might offer a short phrase as an answer instead.

If you cast the spell more than once before finishing a Long Rest, there is a cumulative 25 percent chance for each casting after the first that you get no answer.

#### Commune with Nature

_Level 5 Divination (Druid, Ranger)_

**Casting Time:** 1 minute or Ritual
**Range:** Self
**Components:** V, S
**Duration:** Instantaneous

You commune with nature spirits and gain knowledge of the surrounding area. In the outdoors, the spell gives you knowledge of the area within 3 miles of you. In caves and other natural underground settings, the radius is limited to 300 feet. The spell
doesn't function where nature has been replaced by construction, such as in castles and settlements.

Choose three of the following facts; you learn those facts as they pertain to the spell's area:

• Locations of settlements
• Locations of portals to other planes of existence
• Location of one Challenge Rating 10+ creature (GM's choice) that is a Celestial, an Elemental, a Fey, a Fiend, or an Undead
• The most prevalent kind of plant, mineral, or Beast (you choose which to learn)
• Locations of bodies of water

For example, you could determine the location of a powerful monster in the area, the locations of bodies of water, and the locations of any towns.

#### Comprehend Languages

_Level 1 Divination (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S, M (a pinch of soot and salt)
**Duration:** 1 hour

For the duration, you understand the literal meaning of any language that you hear or see signed. You also understand any written language that you see, but you must be touching the surface on which the words are written. It takes about 1 minute to read one page of text. This spell doesn't decode symbols or secret messages.

#### Compulsion

_Level 4 Enchantment (Bard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

Each creature of your choice that you can see within range must succeed on a Wisdom saving throw or have the Charmed condition until the spell ends.

For the duration, you can take a Bonus Action to designate a direction that is horizontal to you. Each Charmed target must use as much of its movement as possible to move in that direction on its next turn, taking the safest route. After moving in this way, a target repeats the save, ending the spell on itself on a success.

#### Cone of Cold

_Level 5 Evocation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a small crystal or glass cone)
**Duration:** Instantaneous

You unleash a blast of cold air. Each creature in a 60-foot Cone originating from you makes a Constitution saving throw, taking 8d8 Cold damage on a failed save or half as much damage on a successful one. A creature killed by this spell becomes a frozen statue until it thaws.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 5.

#### Confusion

_Level 4 Enchantment (Bard, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (three nut shells)
**Duration:** Concentration, up to 1 minute

Each creature in a 10-foot-radius Sphere centered on a point you choose within range must succeed on a Wisdom saving throw, or that target can't take Bonus Actions or Reactions and must roll 1d10 at the start of each of its turns to determine its behavior for that turn, consulting the table below.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Behavior for the Turn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>The target doesn't take an action, and it uses all its movement to move. Roll 1d4 for the direction: 1, north; 2, east; 3, south; or 4, west.</td>
    </tr>
    <tr>
      <td>2–6</td>
      <td>The target doesn't move or take actions.</td>
    </tr>
    <tr>
      <td>7–8</td>
      <td>The target doesn't move, and it takes the Attack action to make one melee attack against a random creature within reach. If none are within reach, the target takes no action.</td>
    </tr>
    <tr>
      <td>9–10</td>
      <td>The target chooses its behavior.</td>
    </tr>
  </tbody>
</table>

At the end of each of its turns, an affected target repeats the save, ending the spell on itself on a success.

_Using a Higher-Level Spell Slot._ The Sphere's radius increases by 5 feet for each spell slot level above 4.

#### Conjure Animals

_Level 3 Conjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure nature spirits that appear as a Large pack of spectral, intangible animals in an unoccupied space you can see within range. The pack lasts for the duration, and you choose the spirits' animal form, such as wolves, serpents, or birds.

You have Advantage on Strength saving throws while you're within 5 feet of the pack, and when you move on your turn, you can also move the pack up to 30 feet to an unoccupied space you can see.

Whenever the pack moves within 10 feet of a creature you can see and whenever a creature you can see enters a space within 10 feet of the pack or ends
its turn there, you can force that creature to make a Dexterity saving throw. On a failed save, the creature takes 3d10 Slashing damage. A creature makes this save only once per turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 3.

#### Conjure Celestial

_Level 7 Conjuration (Cleric)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure a spirit from the Upper Planes, which manifests as a pillar of light in a 10-foot-radius, 40-foot-high Cylinder centered on a point within range. For each creature you can see in the Cylinder, choose which of these lights shines on it:

**Healing Light.** The target regains Hit Points equal to 4d12 plus your spellcasting ability modifier.

**Searing Light.** The target makes a Dexterity saving throw, taking 6d12 Radiant damage on a failed save or half as much damage on a successful one.

Until the spell ends, Bright Light fills the Cylinder, and when you move on your turn, you can also move the Cylinder up to 30 feet.

Whenever the Cylinder moves into the space of a creature you can see and whenever a creature you can see enters the Cylinder or ends its turn there, you can bathe it in one of the lights. A creature can be affected by this spell only once per turn.

_Using a Higher-Level Spell Slot._ The healing and damage increase by 1d12 for each spell slot level above 7.

#### Conjure Elemental

_Level 5 Conjuration (Druid, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure a Large, intangible spirit from the Elemental Planes that appears in an unoccupied space within range. Choose the spirit's element, which determines its damage type: air (Lightning), earth (Thunder), fire (Fire), or water (Cold). The spirit lasts for the duration.

Whenever a creature you can see enters the spirit's space or starts its turn within 5 feet of the spirit, you can force that creature to make a Dexterity saving throw if the spirit has no creature Restrained. On failed save, the target takes 8d8 damage of the spirit's type, and the target has the Restrained condition until the spell ends. At the start of each of its turns, the Restrained target repeats the save.

On a failed save, the target takes 4d8 damage of the spirit's type. On a successful save, the target isn't Restrained by the spirit.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 5.

#### Conjure Fey

_Level 6 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure a Medium spirit from the Feywild in an unoccupied space you can see within range. The spirit lasts for the duration, and it looks like a Fey creature of your choice. When the spirit appears, you can make one melee spell attack against a creature within 5 feet of it. On a hit, the target takes Psychic damage equal to 3d12 plus your spellcasting ability modifier, and the target has the Frightened condition until the start of your next turn, with both you and the spirit as the source of the fear.

As a Bonus Action on your later turns, you can teleport the spirit to an unoccupied space you can see within 30 feet of the space it left and make the attack against a creature within 5 feet of it.

_Using a Higher-Level Spell Slot._ The damage increases by 1d12 for each spell slot level above 6.

#### Conjure Minor Elementals

_Level 4 Conjuration (Druid, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure spirits from the Elemental Planes that flit around you in a 15-foot Emanation for the duration. Until the spell ends, any attack you make deals an extra 2d8 damage when you hit a creature in the Emanation. This damage is Acid, Cold, Fire, or Lightning (your choice when you make the attack).

In addition, the ground in the Emanation is Difficult Terrain for your enemies.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 4.

#### Conjure Woodland Beings

_Level 4 Conjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You conjure nature spirits that flit around you in a 10-foot Emanation for the duration. Whenever the Emanation enters the space of a creature you can
see and whenever a creature you can see enters the Emanation or ends its turn there, you can force that creature to make a Wisdom saving throw. The creature takes 5d8 Force damage on a failed save or half as much damage on a successful one. A creature makes this save only once per turn.

In addition, you can take the Disengage action as a Bonus Action for the spell's duration.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 4.

#### Contact Other Plane

_Level 5 Divination (Warlock, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Self
**Components:** V
**Duration:** 1 minute

You mentally contact a demigod, the spirit of a long-dead sage, or some other knowledgeable entity from another plane. Contacting this otherworldly intelligence can break your mind. When you cast this spell, make a DC 15 Intelligence saving throw. On a successful save, you can ask the entity up to five questions. You must ask your questions before the spell ends. The GM answers each question with one word, such as "yes," "no," "maybe," "never," "irrelevant," or "unclear" (if the entity doesn't know the answer to the question). If a one-word answer would be misleading, the GM might instead offer a short phrase as an answer.

On a failed save, you take 6d6 Psychic damage and have the Incapacitated condition until you finish a Long Rest. A _Greater Restoration_ spell cast on you ends this effect.

#### Contagion

_Level 5 Necromancy (Cleric, Druid)_

**Casting Time:** Action
**Range:** Touch
**Component:** V, S
**Duration:** 7 days

Your touch inflicts a magical contagion. The target must succeed on a Constitution saving throw or take 11d8 Necrotic damage and have the Poisoned condition. Also, choose one ability when you cast the spell. While Poisoned, the target has Disadvantage on saving throws made with the chosen ability.

The target must repeat the saving throw at the end of each of its turns until it gets three successes or failures. If the target succeeds on three of these saves, the spell ends on the target. If the target fails three of the saves, the spell lasts for 7 days on it.

Whenever the Poisoned target receives an effect that would end the Poisoned condition, the target must succeed on a Constitution saving throw, or the Poisoned condition doesn't end on it.

#### Contingency

_Level 6 Abjuration (Wizard)_

**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (a gem-encrusted statuette of yourself worth 1,500+ GP)
**Duration:** 10 days

Choose a spell of level 5 or lower that you can cast, that has a casting time of an action, and that can target you. You cast that spell—called the contingent spell—as part of casting _Contingency_, expending spell slots for both, but the contingent spell doesn't come into effect. Instead, it takes effect when a certain trigger occurs. You describe that trigger when you cast the two spells. For example, a _Contingency_ cast with _Water Breathing_ might stipulate that _Water Breathing_ comes into effect when you are engulfed in water or a similar liquid.

The contingent spell takes effect immediately after the trigger occurs for the first time, whether or not you want it to, and then _Contingency_ ends.

The contingent spell takes effect only on you, even if it can normally target others. You can use only one _Contingency_ spell at a time. If you cast this spell again, the effect of another _Contingency_ spell on you ends. Also, _Contingency_ ends on you if its material component is ever not on your person.

#### Continual Flame

_Level 2 Evocation (Cleric, Druid, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (ruby dust worth 50+ GP, which the spell consumes)
**Duration:** Until dispelled

A flame springs from an object that you touch. The effect casts Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. It looks like a regular flame, but it creates no heat and consumes no fuel. The flame can be covered or hidden but not smothered or quenched.

#### Control Water

_Level 4 Transmutation (Cleric, Druid, Wizard)_

**Casting Time:** Action
**Range:** 300 feet
**Components:** V, S, M (a mixture of water and dust)
**Duration:** Concentration, up to 10 minutes

Until the spell ends, you control any water inside an area you choose that is a Cube up to 100 feet on a side, using one of the following effects. As a Magic action on your later turns, you can repeat the same effect or choose a different one.

_Flood._ You cause the water level of all standing water in the area to rise by as much as 20 feet. If you
choose an area in a large body of water, you instead create a 20-foot tall wave that travels from one side of the area to the other and then crashes. Any Huge or smaller vehicles in the wave's path are carried with it to the other side. Any Huge or smaller vehicles struck by the wave have a 25 percent chance of capsizing.

The water level remains elevated until the spell ends or you choose a different effect. If this effect produced a wave, the wave repeats on the start of your next turn while the flood effect lasts.

_Part Water._ You part water in the area and create a trench. The trench extends across the spell's area, and the separated water forms a wall to either side. The trench remains until the spell ends or you choose a different effect. The water then slowly fills in the trench over the course of the next round until the normal water level is restored.

_Redirect Flow._ You cause flowing water in the area to move in a direction you choose, even if the water has to flow over obstacles, up walls, or in other unlikely directions. The water in the area moves as you direct it, but once it moves beyond the spell's area, it resumes its flow based on the terrain. The water continues to move in the direction you chose until the spell ends or you choose a different effect.

_Whirlpool._ You cause a whirlpool to form in the center of the area, which must be at least 50 feet square and 25 feet deep. The whirlpool lasts until you choose a different effect or the spell ends. The whirlpool is 5 feet wide at the base, up to 50 feet wide at the top, and 25 feet tall. Any creature in the water and within 25 feet of the whirlpool is pulled 10 feet toward it. When a creature enters the whirlpool for the first time on a turn or ends its turn there, it makes a Strength saving throw. On a failed save, the creature takes 2d8 Bludgeoning damage. On a successful save, the creature takes half as much damage. A creature can swim away from the whirlpool only if it first takes an action to pull away and succeeds on a Strength (Athletics) check against your spell save DC.

#### Control Weather

_Level 8 Transmutation (Cleric, Druid, Wizard)_

**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (burning incense)
**Duration:** Concentration, up to 8 hours

You take control of the weather within 5 miles of you for the duration. You must be outdoors to cast this spell, and it ends early if you go indoors.

When you cast the spell, you change the current weather conditions, which are determined by the GM. You can change precipitation, temperature, and wind. It takes 1d4 × 10 minutes for the new

conditions to take effect. Once they do so, you can change the conditions again. When the spell ends, the weather gradually returns to normal.

When you change the weather conditions, find a current condition on the following tables and change its stage by one, up or down. When changing the wind, you can change its direction.

**Precipitation**

<table>
  <thead>
    <tr>
      <th>Stage</th>
      <th>Condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Clear</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Light clouds</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Overcast or ground fog</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Rain, hail, or snow</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Torrential rain, driving hail, or blizzard</td>
    </tr>
  </tbody>
</table>

**Temperature**

<table>
  <thead>
    <tr>
      <th>Stage</th>
      <th>Condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Heat wave</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Hot</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Warm</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Cool</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Cold</td>
    </tr>
    <tr>
      <td>6</td>
      <td>Freezing</td>
    </tr>
  </tbody>
</table>

**Wind**

<table>
  <thead>
    <tr>
      <th>Stage</th>
      <th>Condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Calm</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Moderate wind</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Strong wind</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Gale</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Storm</td>
    </tr>
  </tbody>
</table>

#### Counterspell

_Level 3 Abjuration (Sorcerer, Warlock, Wizard)_

**Casting Time:** Reaction, which you take when you see a creature within 60 feet of yourself casting a spell with Verbal, Somatic, or Material components
**Range:** 60 feet
**Components:** S
**Duration:** Instantaneous

You attempt to interrupt a creature in the process of casting a spell. The creature makes a Constitution saving throw. On a failed save, the spell dissipates with no effect, and the action, Bonus Action, or Reaction used to cast it is wasted. If that spell was cast with a spell slot, the slot isn't expended.

#### Create Food and Water

_Level 3 Conjuration (Cleric, Paladin)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Instantaneous

You create 45 pounds of food and 30 gallons of fresh water on the ground or in containers within range—both useful in fending off the hazards of malnutrition and dehydration. The food is bland but nourishing and looks like a food of your choice, and the water is clean. The food spoils after 24 hours if uneaten.

#### Create or Destroy Water

_Level 1 Transmutation (Cleric, Druid)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a mix of water and sand)
**Duration:** Instantaneous

You do one of the following:

**Create Water.** You create up to 10 gallons of clean water within range in an open container. Alternatively, the water falls as rain in a 30-foot Cube within range, extinguishing exposed flames there.

**Destroy Water.** You destroy up to 10 gallons of water in an open container within range. Alternatively, you destroy fog in a 30-foot Cube within range.

_Using a Higher-Level Spell Slot._ You create or destroy 10 additional gallons of water, or the size of the Cube increases by 5 feet, for each spell slot level above 1.

#### Create Undead

_Level 6 Necromancy (Cleric, Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** 10 feet
**Components:** V, S, M (one 150+ GP black onyx stone for each corpse)
**Duration:** Instantaneous

You can cast this spell only at night. Choose up to three corpses of Medium or Small Humanoids within range. Each one becomes a **Ghoul** under your control (see "Monsters" for its stat block).

As a Bonus Action on each of your turns, you can mentally command any creature you animated with this spell if the creature is within 120 feet of you (if you control multiple creatures, you can command any of them at the same time, issuing the same command to them). You decide what action the creature will take and where it will move on its next turn, or you can issue a general command, such as to guard a particular place. If you issue no commands, the creature takes the Dodge action and moves only to avoid harm. Once given an order, the creature continues to follow the order until its task is complete.

The creature is under your control for 24 hours, after which it stops obeying any command you've given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature before the current 24-hour period ends. This use of the spell reasserts your control over up to three creatures you have animated with this spell rather than animating new ones.

_Using a Higher-Level Spell Slot._ If you use a level 7 spell slot, you can animate or reassert control over four **Ghouls**. If you use a level 8 spell slot, you can animate or reassert control over five **Ghouls** or two **Ghasts** or **Wights**. If you use a level 9 spell slot, you can animate or reassert control over six **Ghouls**, three **Ghasts** or **Wights**, or two **Mummies**. See "Monsters" for these stat blocks.

#### Creation

_Level 5 Illusion (Sorcerer, Wizard)_

**Casting Time:** 1 minute
**Range:** 30 feet
**Components:** V, S, M (a paintbrush)
**Duration:** Special

You pull wisps of shadow material from the Shadowfell to create an object within range. It is either an object of vegetable matter (soft goods, rope, wood, and the like) or mineral matter (stone, crystal, metal, and the like). The object must be no larger than a 5-foot Cube, and the object must be of a form and material that you have seen.

The spell's duration depends on the object's material, as shown in the Materials table. If the object is composed of multiple materials, use the shortest duration. Using any object created by this spell as another spell's Material component causes the other spell to fail.

**Materials**

<table>
  <thead>
    <tr>
      <th>Material</th>
      <th>Duration</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Vegetable matter</td>
      <td>24 hours</td>
    </tr>
    <tr>
      <td>Stone or crystal</td>
      <td>12 hours</td>
    </tr>
    <tr>
      <td>Precious metals</td>
      <td>1 hour</td>
    </tr>
    <tr>
      <td>Gems</td>
      <td>10 minutes</td>
    </tr>
    <tr>
      <td>Adamantine or mithral</td>
      <td>1 minute</td>
    </tr>
  </tbody>
</table>

_Using a Higher-Level Spell Slot._ The Cube increases by 5 feet for each spell slot level above 5.

#### Cure Wounds

_Level 1 Abjuration (Bard, Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

A creature you touch regains a number of Hit Points equal to 2d8 plus your spellcasting ability modifier.

_Using a Higher-Level Spell Slot._ The healing increases by 2d8 for each spell slot level above 1.

#### Dancing Lights

_Illusion Cantrip (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a bit of phosphorus)
**Duration:** Concentration, up to 1 minute
You create up to four torch-size lights within range, making them appear as torches, lanterns, or glowing orbs that hover for the duration. Alternatively, you combine the four lights into one glowing Medium form that is vaguely humanlike. Whichever form you choose, each light sheds Dim Light in a 10-foot radius.

As a Bonus Action, you can move the lights up to 60 feet to a space within range. A light must be within 20 feet of another light created by this spell, and a light vanishes if it exceeds the spell's range.

#### Darkness

_Level 2 Evocation (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, M (bat fur and a piece of coal)
**Duration:** Concentration, up to 10 minutes

For the duration, magical Darkness spreads from a point within range and fills a 15-foot-radius Sphere. Darkvision can't see through it, and nonmagical light can't illuminate it.

Alternatively, you cast the spell on an object that isn't being worn or carried, causing the Darkness to fill a 15-foot Emanation originating from that object. Covering that object with something opaque, such as a bowl or helm, blocks the Darkness.

If any of this spell's area overlaps with an area of Bright Light or Dim Light created by a spell of level 2 or lower, that other spell is dispelled.

#### Darkvision

_Level 2 Transmutation (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a dried carrot)
**Duration:** 8 hours

For the duration, a willing creature you touch has Darkvision with a range of 150 feet.

#### Daylight

_Level 3 Evocation (Cleric, Druid, Paladin, Ranger, Sorcerer)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** 1 hour

For the duration, sunlight spreads from a point within range and fills a 60-foot-radius Sphere. The sunlight's area is Bright Light and sheds Dim Light for an additional 60 feet.

Alternatively, you cast the spell on an object that isn't being worn or carried, causing the sunlight to fill a 60-foot Emanation originating from that object. Covering that object with something opaque, such as a bowl or helm, blocks the sunlight.

If any of this spell's area overlaps with an area of Darkness created by a spell of level 3 or lower, that other spell is dispelled.

#### Death Ward

_Level 4 Abjuration (Cleric, Paladin)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** 8 hours

You touch a creature and grant it a measure of protection from death. The first time the target would drop to 0 Hit Points before the spell ends, the target instead drops to 1 Hit Point, and the spell ends.

If the spell is still in effect when the target is subjected to an effect that would kill it instantly without dealing damage, that effect is negated against the target, and the spell ends.

#### Delayed Blast Fireball

_Level 7 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a ball of bat guano and sulfur)
**Duration:** Concentration, up to 1 minute

A beam of yellow light flashes from you, then condenses at a chosen point within range as a glowing bead for the duration. When the spell ends, the bead explodes, and each creature in a 20-foot-radius Sphere centered on that point makes a Dexterity saving throw. A creature takes Fire damage equal to the total accumulated damage on a failed save or half as much damage on a successful one.

The spell's base damage is 12d6, and the damage increases by 1d6 whenever your turn ends and the spell hasn't ended.

If a creature touches the glowing bead before the spell ends, that creature makes a Dexterity saving throw. On a failed save, the spell ends, causing the bead to explode. On a successful save, the creature can throw the bead up to 40 feet. If the thrown bead enters a creature's space or collides with a solid object, the spell ends, and the bead explodes.

When the bead explodes, flammable objects in the explosion that aren't being worn or carried start burning.

_Using a Higher-Level Spell Slot._ The base damage increases by 1d6 for each spell slot level above 7.

#### Demiplane

_Level 8 Conjuration (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** S
**Duration:** 1 hour
You create a shadowy Medium door on a flat solid surface that you can see within range. This door can be opened and closed, and it leads to a demiplane that is an empty room 30 feet in each dimension, made of wood or stone (your choice).

When the spell ends, the door vanishes, and any objects inside the demiplane remain there. Any creatures inside also remain unless they opt to be shunted through the door as it vanishes, landing with the Prone condition in the unoccupied spaces closest to the door's former space.

Each time you cast this spell, you can create a new demiplane or connect the shadowy door to a demiplane you created with a previous casting of this spell. Additionally, if you know the nature and contents of a demiplane created by a casting of this spell by another creature, you can connect the shadowy door to that demiplane instead.

#### Detect Evil and Good

_Level 1 Divination (Cleric, Paladin)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

For the duration, you sense the location of any Aberration, Celestial, Elemental, Fey, Fiend, or Undead within 30 feet of yourself. You also sense whether the _Hallow_ spell is active there and, if so, where.

The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

#### Detect Magic

_Level 1 Divination (Bard, Cleric, Druid, Paladin, Ranger, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

For the duration, you sense the presence of magical effects within 30 feet of yourself. If you sense such effects, you can take the Magic action to see a faint aura around any visible creature or object in the area that bears the magic, and if an effect was created by a spell, you learn the spell's school of magic.

The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

#### Detect Poison and Disease

_Level 1 Divination (Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S, M (a yew leaf)
**Duration:** Concentration, up to 10 minutes

For the duration, you sense the location of poisons, poisonous or venomous creatures, and magical contagions within 30 feet of yourself. You sense the kind of poison, creature, or contagion in each case.

The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

#### Detect Thoughts

_Level 2 Divination (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (1 Copper Piece)
**Duration:** Concentration, up to 1 minute

You activate one of the effects below. Until the spell ends, you can activate either effect as a Magic action on your later turns.

_Sense Thoughts._ You sense the presence of thoughts within 30 feet of yourself that belong to creatures that know languages or are telepathic. You don't read the thoughts, but you know that a thinking creature is present.

The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

_Read Thoughts._ Target one creature you can see within 30 feet of yourself or one creature within 30 feet of yourself that you detected with the Sense Thoughts option. You learn what is most on the target's mind right now. If the target doesn't know any languages and isn't telepathic, you learn nothing.

As a Magic action on your next turn, you can try to probe deeper into the target's mind. If you probe deeper, the target makes a Wisdom saving throw. On a failed save, you discern the target's reasoning, emotions, and something that looms large in its mind (such as a worry, love, or hate). On a successful save, the spell ends. Either way, the target knows that you are probing into its mind, and until you shift your attention away from the target's mind, the target can take an action on its turn to make an Intelligence (Arcana) check against your spell save DC, ending the spell on a success.

#### Dimension Door

_Level 4 Conjuration (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 500 feet
**Components:** V
**Duration:** Instantaneous

You teleport to a location within range. You arrive at exactly the spot desired. It can be a place you can see, one you can visualize, or one you can describe by stating distance and direction, such as "200 feet straight downward" or "300 feet upward to the northwest at a 45-degree angle."

You can also teleport one willing creature. The creature must be within 5 feet of you when you teleport, and it teleports to a space within 5 feet of your destination space.
If you, the other creature, or both would arrive in a space occupied by a creature or completely filled by one or more objects, you and any creature traveling with you each take 4d6 Force damage, and the teleportation fails.

#### Disguise Self

_Level 1 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** 1 hour

You make yourself—including your clothing, armor, weapons, and other belongings on your person—look different until the spell ends. You can seem 1 foot shorter or taller and can appear heavier or lighter. You must adopt a form that has the same basic arrangement of limbs as you have. Otherwise, the extent of the illusion is up to you.

The changes wrought by this spell fail to hold up to physical inspection. For example, if you use this spell to add a hat to your outfit, objects pass through the hat, and anyone who touches it would feel nothing.

To discern that you are disguised, a creature must take the Study action to inspect your appearance and succeed on an Intelligence (Investigation) check against your spell save DC.

#### Disintegrate

_Level 6 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a lodestone and dust)
**Duration:** Instantaneous

You launch a green ray at a target you can see within range. The target can be a creature, a nonmagical object, or a creation of magical force, such as the wall created by _Wall of Force_.

A creature targeted by this spell makes a Dexterity saving throw. On a failed save, the target takes 10d6 + 40 Force damage. If this damage reduces it to 0 Hit Points, it and everything nonmagical it is wearing and carrying are disintegrated into gray dust. The target can be revived only by a _True Resurrection_ or a _Wish_ spell.

This spell automatically disintegrates a Large or smaller nonmagical object or a creation of magical force. If such a target is Huge or larger, this spell disintegrates a 10-foot-Cube portion of it.

_Using a Higher-Level Spell Slot._ The damage increases by 3d6 for each spell slot level above 6.

#### Dispel Evil and Good

_Level 5 Abjuration (Cleric, Paladin)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (powdered silver and iron)
**Duration:** Concentration, up to 1 minute

For the duration, Celestials, Elementals, Fey, Fiends, and Undead have Disadvantage on attack rolls against you. You can end the spell early by using either of the following special functions.

_Break Enchantment._ As a Magic action, you touch a creature that is possessed by or has the Charmed or Frightened condition from one or more creatures of the types above. The target is no longer possessed, Charmed, or Frightened by such creatures.

_Dismissal._ As a Magic action, you target one creature you can see within 5 feet of you that has one of the creature types above. The target must succeed on a Charisma saving throw or be sent back to its home plane if it isn't there already. If they aren't on their home plane, Undead are sent to the Shadowfell, and Fey are sent to the Feywild.

#### Dispel Magic

_Level 3 Abjuration (Bard, Cleric, Druid, Paladin, Ranger, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

Choose one creature, object, or magical effect within range. Any ongoing spell of level 3 or lower on the target ends. For each ongoing spell of level 4 or higher on the target, make an ability check using your spellcasting ability (DC 10 plus that spell's level). On a successful check, the spell ends.

_Using a Higher-Level Spell Slot._ You automatically end a spell on the target if the spell's level is equal to or less than the level of the spell slot you use.

#### Dissonant Whispers

_Level 1 Enchantment (Bard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

One creature of your choice that you can see within range hears a discordant melody in its mind. The target makes a Wisdom saving throw. On a failed save, it takes 3d6 Psychic damage and must immediately use its Reaction, if available, to move as far away from you as it can, using the safest route. On a successful save, the target takes half as much damage only.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 1.

#### Divination

_Level 4 Divination (Cleric, Druid, Wizard)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S, M (incense worth 25+ GP, which the spell consumes)
**Duration:** Instantaneous

This spell puts you in contact with a god or a god's servants. You ask one question about a specific goal, event, or activity to occur within 7 days. The GM offers a truthful reply, which might be a short phrase or cryptic rhyme. The spell doesn't account for circumstances that might change the answer, such as the casting of other spells.

If you cast the spell more than once before finishing a Long Rest, there is a cumulative 25 percent chance for each casting after the first that you get no answer.

#### Divine Favor

_Level 1 Transmutation (Paladin)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V, S
**Duration:** 1 minute

Until the spell ends, your attacks with weapons deal an extra 1d4 Radiant damage on a hit.

#### Divine Smite

_Level 1 Evocation (Paladin)_

**Casting Time:** Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
**Range:** Self
**Component:** V
**Duration:** Instantaneous

The target takes an extra 2d8 Radiant damage from the attack. The damage increases by 1d8 if the target is a Fiend or an Undead.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 1.

#### Divine Word

_Level 7 Evocation (Cleric)_

**Casting Time:** Bonus Action
**Range:** 30 feet
**Components:** V
**Duration:** Instantaneous

You utter a word imbued with power from the Upper Planes. Each creature of your choice in range makes a Charisma saving throw. On a failed save, a target that has 50 Hit Points or fewer suffers an effect based on its current Hit Points, as shown in the Divine Word Effects table. Regardless of its Hit Points, a Celestial, an Elemental, a Fey, or a Fiend target that fails its save is forced back to its plane of origin (if it isn't there already) and can't return to the current plane for 24 hours by any means short of a _Wish_ spell.

**Divine Word Effects**

<table>
  <thead>
    <tr>
      <th>Hit Points</th>
      <th>Effect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0–20</td>
      <td>The target dies.</td>
    </tr>
    <tr>
      <td>21–30</td>
      <td>The target has the Blinded, Deafened, and Stunned conditions for 1 hour.</td>
    </tr>
    <tr>
      <td>31–40</td>
      <td>The target has the Blinded and Deafened conditions for 10 minutes.</td>
    </tr>
    <tr>
      <td>41–50</td>
      <td>The target has the Deafened condition for 1 minute.</td>
    </tr>
  </tbody>
</table>

#### Dominate Beast

_Level 4 Enchantment (Druid, Ranger, Sorcerer)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

One Beast you can see within range must succeed on a Wisdom saving throw or have the Charmed condition for the duration. The target has Advantage on the save if you or your allies are fighting it. Whenever the target takes damage, it repeats the save, ending the spell on itself on a success.

You have a telepathic link with the Charmed target while the two of you are on the same plane of existence. On your turn, you can use this link to issue commands to the target (no action required), such as "Attack that creature," "Move over there," or "Fetch that object." The target does its best to obey on its turn. If it completes an order and doesn't receive further direction from you, it acts and moves as it likes, focusing on protecting itself.

You can command the target to take a Reaction but must take your own Reaction to do so.

_Using a Higher-Level Spell Slot._ Your Concentration can last longer with a spell slot of level 5 (up to 10 minutes), 6 (up to 1 hour), or 7+ (up to 8 hours).

#### Dominate Monster

_Level 8 Enchantment (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 hour

One creature you can see within range must succeed on a Wisdom saving throw or have the Charmed condition for the duration. The target has Advantage on the save if you or your allies are fighting it. Whenever the target takes damage, it repeats the save, ending the spell on itself on a success.
You have a telepathic link with the Charmed target while the two of you are on the same plane of existence. On your turn, you can use this link to issue commands to the target (no action required), such as "Attack that creature," "Move over there," or "Fetch that object." The target does its best to obey on its turn. If it completes an order and doesn't receive further direction from you, it acts and moves as it likes, focusing on protecting itself.

You can command the target to take a Reaction but must take your own Reaction to do so.

_Using a Higher-Level Spell Slot._ Your Concentration can last longer with a level 9 spell slot (up to 8 hours).

#### Dominate Person

_Level 5 Enchantment (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

One Humanoid you can see within range must succeed on a Wisdom saving throw or have the Charmed condition for the duration. The target has Advantage on the save if you or your allies are fighting it. Whenever the target takes damage, it repeats the save, ending the spell on itself on a success.

You have a telepathic link with the Charmed target while the two of you are on the same plane of existence. On your turn, you can use this link to issue commands to the target (no action required), such as "Attack that creature," "Move over there," or "Fetch that object." The target does its best to obey on its turn. If it completes an order and doesn't receive further direction from you, it acts and moves as it likes, focusing on protecting itself.

You can command the target to take a Reaction but must take your own Reaction to do so.

_Using a Higher-Level Spell Slot._ Your Concentration can last longer with a spell slot of level 6 (up to 10 minutes), 7 (up to 1 hour), or 8+ (up to 8 hours).

#### Dragon's Breath

_Level 2 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Bonus Action
**Range:** Touch
**Components:** V, S, M (a hot pepper)
**Duration:** Concentration, up to 1 minute

You touch one willing creature, and choose Acid, Cold, Fire, Lightning, or Poison. Until the spell ends, the target can take a Magic action to exhale a 15-foot Cone. Each creature in that area makes a Dexterity saving throw, taking 3d6 damage of the chosen type on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 2.

#### Dream

_Level 5 Illusion (Bard, Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** Special
**Components:** V, S, M (a handful of sand)
**Duration:** 8 hours

You target a creature you know on the same plane of existence. You or a willing creature you touch enters a trance state to act as a dream messenger. While in the trance, the messenger is Incapacitated and has a Speed of 0.

If the target is asleep, the messenger appears in the target's dreams and can converse with the target as long as it remains asleep, through the spell's duration. The messenger can also shape the dream's environment, creating landscapes, objects, and other images. The messenger can emerge from the trance at any time, ending the spell. The target recalls the dream perfectly upon waking.

If the target is awake when you cast the spell, the messenger knows it and can either end the trance (and the spell) or wait for the target to sleep, at which point the messenger enters its dreams.

You can make the messenger terrifying to the target. If you do so, the messenger can deliver a message of no more than ten words, and then the target makes a Wisdom saving throw. On a failed save, the target gains no benefit from its rest, and it takes 3d6 Psychic damage when it wakes up.

#### Druidcraft

_Transmutation Cantrip (Druid)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Instantaneous

Whispering to the spirits of nature, you create one of the following effects within range.

_Weather Sensor._ You create a Tiny, harmless sensory effect that predicts what the weather will be at your location for the next 24 hours. The effect might manifest as a golden orb for clear skies, a cloud for rain, falling snowflakes for snow, and so on. This effect persists for 1 round.

_Bloom._ You instantly make a flower blossom, a seed pod open, or a leaf bud bloom.

_Sensory Effect._ You create a harmless sensory effect, such as falling leaves, spectral dancing fairies, a gentle breeze, the sound of an animal, or the faint odor of skunk. The effect must fit in a 5-foot Cube.

_Fire Play._ You light or snuff out a candle, a torch, or a campfire.

#### Earthquake

_Level 8 Transmutation (Cleric, Druid, Sorcerer)_

**Casting Time:** Action
**Range:** 500 feet
**Components:** V, S, M (a fractured rock)
**Duration:** Concentration, up to 1 minute

Choose a point on the ground that you can see within range. For the duration, an intense tremor rips through the ground in a 100-foot-radius circle centered on that point. The ground there is Difficult Terrain.

When you cast this spell and at the end of each of your turns for the duration, each creature on the ground in the area makes a Dexterity saving throw. On a failed save, a creature has the Prone condition, and its Concentration is broken.

You can also cause the effects below.

_Fissures._ A total of 1d6 fissures open in the spell's area at the end of the turn you cast it. You choose the fissures' locations, which can't be under structures. Each fissure is 1d10 × 10 feet deep and 10 feet wide, and it extends from one edge of the spell's area to another edge. A creature in the same space as a fissure must succeed on a Dexterity saving throw or fall in. A creature that successfully saves moves with the fissure's edge as it opens.

_Structures._ The tremor deals 50 Bludgeoning damage to any structure in contact with the ground in the area when you cast the spell and at the end of each of your turns until the spell ends. If a structure drops to 0 Hit Points, it collapses.

A creature within a distance from a collapsing structure equal to half the structure's height makes a Dexterity saving throw. On a failed save, the creature takes 12d6 Bludgeoning damage, has the Prone condition, and is buried in the rubble, requiring a DC 20 Strength (Athletics) check as an action to escape. On a successful save, the creature takes half as much damage only.

#### Eldritch Blast

_Evocation Cantrip (Warlock)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You hurl a beam of crackling energy. Make a ranged spell attack against one creature or object in range. On a hit, the target takes 1d10 Force damage.

_Cantrip Upgrade._ The spell creates two beams at level 5, three beams at level 11, and four beams at level 17. You can direct the beams at the same target or at different ones. Make a separate attack roll for each beam.

#### Elementalism

_Transmutation Cantrip (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Instantaneous

You exert control over the elements, creating one of the following effects within range.

_Beckon Air._ You create a breeze strong enough to ripple cloth, stir dust, rustle leaves, and close open doors and shutters, all in a 5-foot Cube. Doors and shutters being held open by someone or something aren't affected.

_Beckon Earth._ You create a thin shroud of dust or sand that covers surfaces in a 5-foot-square area, or you cause a single word to appear in your handwriting in a patch of dirt or sand.

_Beckon Fire._ You create a thin cloud of harmless embers and colored, scented smoke in a 5-foot Cube. You choose the color and scent, and the embers can light candles, torches, or lamps in that area. The smoke's scent lingers for 1 minute.

_Beckon Water._ You create a spray of cool mist that lightly dampens creatures and objects in a 5-foot Cube. Alternatively, you create 1 cup of clean water either in an open container or on a surface, and the water evaporates in 1 minute.

_Sculpt Element._ You cause dirt, sand, fire, smoke, mist, or water that can fit in a 1-foot Cube to assume a crude shape (such as that of a creature) for 1 hour.

#### Enhance Ability

_Level 2 Transmutation (Bard, Cleric, Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (fur or a feather)
**Duration:** Concentration, up to 1 hour

You touch a creature and choose Strength, Dexterity, Intelligence, Wisdom, or Charisma. For the duration, the target has Advantage on ability checks using the chosen ability.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 2. You can choose a different ability for each target.

#### Enlarge/Reduce

_Level 2 Transmutation (Bard, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a pinch of powdered iron)
**Duration:** Concentration, up to 1 minute

For the duration, the spell enlarges or reduces a creature or an object you can see within range (see the chosen effect below). A targeted object must be neither worn nor carried. If the target is an unwilling creature, it can make a Constitution saving throw. On a successful save, the spell has no effect.

Everything that a targeted creature is wearing and carrying changes size with it. Any item it drops returns to normal size at once. A thrown weapon or piece of ammunition returns to normal size immediately after it hits or misses a target.

_Enlarge._ The target's size increases by one category—from Medium to Large, for example. The target also has Advantage on Strength checks and Strength saving throws. The target's attacks with its enlarged weapons or Unarmed Strikes deal an extra 1d4 damage on a hit.

_Reduce._ The target's size decreases by one category—from Medium to Small, for example. The target also has Disadvantage on Strength checks and Strength saving throws. The target's attacks with its reduced weapons or Unarmed Strikes deal 1d4 less damage on a hit (this can't reduce the damage below 1).

#### Ensnaring Strike

_Level 1 Conjuration (Ranger)_

**Casting Time:** Bonus Action, which you take immediately after hitting a creature with a weapon
**Range:** Self
**Components:** V
**Duration:** Concentration, up to 1 minute

As you hit the target, grasping vines appear on it, and it makes a Strength saving throw. A Large or larger creature has Advantage on this save. On a failed save, the target has the Restrained condition until the spell ends. On a successful save, the vines shrivel away, and the spell ends.

While Restrained, the target takes 1d6 Piercing damage at the start of each of its turns. The target or a creature within reach of it can take an action to make a Strength (Athletics) check against your spell save DC. On a success, the spell ends.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 1.

#### Entangle

_Level 1 Conjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

Grasping plants sprout from the ground in a 20-foot square within range. For the duration, these plants turn the ground in the area into Difficult Terrain. They disappear when the spell ends.

Each creature (other than you) in the area when you cast the spell must succeed on a Strength saving throw or have the Restrained condition until the spell ends. A Restrained creature can take an action to make a Strength (Athletics) check against your spell save DC. On a success, it frees itself from the grasping plants and is no longer Restrained by them.

#### Enthrall

_Level 2 Enchantment (Bard, Warlock)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You weave a distracting string of words, causing creatures of your choice that you can see within range to make a Wisdom saving throw. Any creature you or your companions are fighting automatically succeeds on this save. On a failed save, a target has a −10 penalty to Wisdom (Perception) checks and Passive Perception until the spell ends.

#### Etherealness

_Level 7 Conjuration (Bard, Cleric, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Up to 8 hours

You step into the border regions of the Ethereal Plane, where it overlaps with your current plane. You remain in the Border Ethereal for the duration. During this time, you can move in any direction. If you move up or down, every foot of movement costs an extra foot. You can perceive the plane you left, which looks gray, and you can't see anything there more than 60 feet away.

While on the Ethereal Plane, you can affect and be affected only by creatures, objects, and effects on that plane. Creatures that aren't on the Ethereal Plane can't perceive or interact with you unless a feature gives them the ability to do so.

When the spell ends, you return to the plane you left in the spot that corresponds to your space in the Border Ethereal. If you appear in an occupied space, you are shunted to the nearest unoccupied space and take Force damage equal to twice the number of feet you are moved.

This spell ends instantly if you cast it while you are on the Ethereal Plane or a plane that doesn't border it, such as one of the Outer Planes.

_Using a Higher-Level Spell Slot._ You can target up to three willing creatures (including yourself) for each spell slot level above 7. The creatures must be within 10 feet of you when you cast the spell.

#### Expeditious Retreat

_Level 1 Transmutation (Sorcerer, Warlock, Wizard)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You take the Dash action, and until the spell ends, you can take that action again as a Bonus Action.

#### Eyebite

_Level 6 Necromancy (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 1 minute

For the duration, your eyes become an inky void. One creature of your choice within 60 feet of you that you can see must succeed on a Wisdom saving throw or be affected by one of the following effects of your choice for the duration.

On each of your turns until the spell ends, you can take a Magic action to target another creature but can't target a creature again if it has succeeded on a save against this casting of the spell.

_Asleep._ The target has the Unconscious condition. It wakes up if it takes any damage or if another creature takes an action to shake it awake.

_Panicked._ The target has the Frightened condition. On each of its turns, the Frightened target must take the Dash action and move away from you by the safest and shortest route available. If the target moves to a space at least 60 feet away from you where it can't see you, this effect ends.

_Sickened._ The target has the Poisoned condition.

#### Fabricate

_Level 4 Transmutation (Wizard)_

**Casting Time:** 10 minutes
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You convert raw materials into products of the same material. For example, you can fabricate a wooden bridge from a clump of trees, a rope from a patch of hemp, or clothes from flax or wool.

Choose raw materials that you can see within range. You can fabricate a Large or smaller object (contained within a 10-foot Cube or eight connected 5-foot Cubes) given a sufficient quantity of material. If you're working with metal, stone, or another mineral substance, however, the fabricated object can be no larger than Medium (contained within a 5-foot Cube). The quality of any fabricated objects is based on the quality of the raw materials.

Creatures and magic items can't be created by this spell. You also can't use it to create items that require a high degree of skill—such as weapons and armor—unless you have proficiency with the type of Artisan's Tools used to craft such objects.

#### Faerie Fire

_Level 1 Evocation (Bard, Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Concentration, up to 1 minute

Objects in a 20-foot Cube within range are outlined in blue, green, or violet light (your choice). Each creature in the Cube is also outlined if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed Dim Light in a 10-foot radius and can't benefit from the Invisible condition.

Attack rolls against an affected creature or object have Advantage if the attacker can see it.

#### Faithful Hound

_Level 4 Conjuration (Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a silver whistle)
**Duration:** 8 hours

You conjure a phantom watchdog in an unoccupied space that you can see within range. The hound remains for the duration or until the two of you are more than 300 feet apart from each other.

No one but you can see the hound, and it is intangible and invulnerable. When a Small or larger creature comes within 30 feet of it without first speaking the password that you specify when you cast this spell, the hound starts barking loudly. The hound has Truesight with a range of 30 feet.

At the start of each of your turns, the hound attempts to bite one enemy within 5 feet of it. That enemy must succeed on a Dexterity saving throw or take 4d8 Force damage.

On your later turns, you can take a Magic action to move the hound up to 30 feet.

#### False Life

_Level 1 Necromancy (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a drop of alcohol)
**Duration:** Instantaneous

You gain 2d4 + 4 Temporary Hit Points.

_Using a Higher-Level Spell Slot._ You gain 5 additional Temporary Hit Points for each spell slot level above 1.

#### Fear

_Level 3 Illusion (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a white feather)
**Duration:** Concentration, up to 1 minute

Each creature in a 30-foot Cone must succeed on a Wisdom saving throw or drop whatever it is holding and have the Frightened condition for the duration.

A Frightened creature takes the Dash action and moves away from you by the safest route on each of its turns unless there is nowhere to move. If the creature ends its turn in a space where it doesn't have line of sight to you, the creature makes a Wisdom saving throw. On a successful save, the spell ends on that creature.

#### Feather Fall

_Level 1 Transmutation (Bard, Sorcerer, Wizard)_

**Casting Time:** Reaction, which you take when you or a creature you can see within 60 feet of you falls
**Range:** 60 feet
**Components:** V, M (a small feather or piece of down)
**Duration:** 1 minute

Choose up to five falling creatures within range. A falling creature's rate of descent slows to 60 feet per round until the spell ends. If a creature lands before the spell ends, the creature takes no damage from the fall, and the spell ends for that creature.

#### Find Familiar

_Level 1 Conjuration (Wizard)_

**Casting Time:** 1 hour or Ritual
**Range:** 10 feet
**Components:** V, S, M (burning incense worth 10+ GP, which the spell consumes)
**Duration:** Instantaneous

You gain the service of a familiar, a spirit that takes an animal form you choose: **Bat, Cat, Frog, Hawk, Lizard, Octopus, Owl, Rat, Raven, Spider, Weasel**, or another Beast that has a Challenge Rating of 0. Appearing in an unoccupied space within range, the familiar has the statistics of the chosen form (see "Monsters"), though it is a Celestial, Fey, or Fiend (your choice) instead of a Beast. Your familiar acts independently of you, but it obeys your commands.

_Telepathic Connection._ While your familiar is within 100 feet of you, you can communicate with it telepathically. Additionally, as a Bonus Action, you can see through the familiar's eyes and hear what it hears until the start of your next turn, gaining the benefits of any special senses it has.

Finally, when you cast a spell with a range of touch, your familiar can deliver the touch. Your familiar must be within 100 feet of you, and it must take a Reaction to deliver the touch when you cast the spell.

_Combat._ The familiar is an ally to you and your allies. It rolls its own Initiative and acts on its own turn. A familiar can't attack, but it can take other actions as normal.

_Disappearance of the Familiar._ When the familiar drops to 0 Hit Points, it disappears. It reappears after you cast this spell again. As a Magic action, you can temporarily dismiss the familiar to a pocket dimension. Alternatively, you can dismiss it forever. As a Magic action while it is temporarily dismissed, you can cause it to reappear in an unoccupied space within 30 feet of you. Whenever the familiar drops to 0 Hit Points or disappears into the pocket dimension, it leaves behind in its space anything it was wearing or carrying.

_One Familiar Only._ You can't have more than one familiar at a time. If you cast this spell while you have a familiar, you instead cause it to adopt a new eligible form.

#### Find Steed

_Level 2 Conjuration (Paladin)_

**Casting Time:** Action
**Range:** 30 feet
**Component:** V, S
**Duration:** Instantaneous

You summon an otherworldly being that appears as a loyal steed in an unoccupied space of your choice within range. This creature uses the **Otherworldly Steed** stat block. If you already have a steed from this spell, the steed is replaced by the new one.

The steed resembles a Large, rideable animal of your choice, such as a horse, a camel, a dire wolf, or an elk. Whenever you cast the spell, choose the steed's creature type—Celestial, Fey, or Fiend—which determines certain traits in the stat block.

_Combat._ The steed is an ally to you and your allies. In combat, it shares your Initiative count, and it functions as a controlled mount while you ride it (as defined in the rules on mounted combat). If you have the Incapacitated condition, the steed takes its turn immediately after yours and acts independently, focusing on protecting you.

_Disappearance of the Steed._ The steed disappears if it drops to 0 Hit Points or if you die. When it disappears, it leaves behind anything it was wearing or carrying. If you cast this spell again, you decide whether you summon the steed that disappeared or a different one.

_Using a Higher-Level Spell Slot._ Use the spell slot's level for the spell's level in the stat block.

## Otherworldly Steed

_Large Celestial, Fey, or Fiend (Your Choice), Neutral_

**AC** 10 + 1 per spell level
**HP** 5 + 10 per spell level (the steed has a number of Hit Dice [d10s] equal to the spell's level)
**Speed** 60 ft., Fly 60 ft. (requires level 4+ spell)

<table>
  <tbody>
    <tr>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td colspan="4"></td>
    </tr>
    <tr>
      <td>STR</td>
      <td>18</td>
      <td>+4</td>
      <td>+4</td>
      <td>DEX</td>
      <td>12</td>
      <td>+1</td>
      <td>+1</td>
      <td>CON</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
    </tr>
    <tr>
      <td>INT</td>
      <td>6</td>
      <td>−2</td>
      <td>−2</td>
      <td>WIS</td>
      <td>12</td>
      <td>+1</td>
      <td>+1</td>
      <td>CHA</td>
      <td>8</td>
      <td>−1</td>
      <td>−1</td>
    </tr>
  </tbody>
</table>

**Senses** Passive Perception 11
**Languages** Telepathy 1 mile (works only with you)
**CR** None (XP 0; PB equals your Proficiency Bonus)

#### Traits

**_Life Bond._** When you regain Hit Points from a level 1+ spell, the steed regains the same number of Hit Points if you're within 5 feet of it.

#### Actions

**_Otherworldly Slam._** _Melee Attack Roll:_ Bonus equals your spell attack modifier, reach 5 ft. _Hit:_ 1d8 plus the spell's level of Radiant (Celestial), Psychic (Fey), or Necrotic (Fiend) damage.

#### Bonus Actions

**_Fell Glare (Fiend Only; Recharges after a Long Rest)._** _Wisdom Saving Throw:_ DC equals your spell save DC, one creature within 60 feet the steed can see. _Failure:_ The target has the Frightened condition until the end of your next turn.

**_Fey Step (Fey Only; Recharges after a Long Rest)._** The steed teleports, along with its rider, to an unoccupied space of your choice up to 60 feet away from itself.

**_Healing Touch (Celestial Only; Recharges after a Long Rest)._** One creature within 5 feet of the steed regains a number of Hit Points equal to 2d8 plus the spell's level.

#### Find the Path

_Level 6 Divination (Bard, Cleric, Druid)_

**Casting Time:** 1 minute
**Range:** Self
**Components:** V, S, M (a set of divination tools—such as cards or runes—worth 100+ GP)
**Duration:** Concentration, up to 1 day

You magically sense the most direct physical route to a location you name. You must be familiar with the location, and the spell fails if you name a destination on another plane of existence, a moving destination (such as a mobile fortress), or an unspecific destination (such as "a green dragon's lair").

For the duration, as long as you are on the same plane of existence as the destination, you know how far it is and in what direction it lies. Whenever you face a choice of paths along the way there, you know which path is the most direct.

#### Find Traps

_Level 2 Divination (Cleric, Druid, Ranger)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You sense any trap within range that is within line of sight. A trap, for the purpose of this spell, includes any object or mechanism that was created to cause damage or other danger. Thus, the spell would sense the _Alarm_ or _Glyph of Warding_ spell or a mechanical pit trap, but it wouldn't reveal a natural weakness in the floor, an unstable ceiling, or a hidden sinkhole.

This spell reveals that a trap is present but not its location. You do learn the general nature of the danger posed by a trap you sense.

#### Finger of Death

_Level 7 Necromancy (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You unleash negative energy toward a creature you can see within range. The target makes a Constitution saving throw, taking 7d8 + 30 Necrotic damage on a failed save or half as much damage on a successful one.

A Humanoid killed by this spell rises at the start of your next turn as a **Zombie** (see "Monsters") that follows your verbal orders.

#### Fireball

_Level 3 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a ball of bat guano and sulfur)
**Duration:** Instantaneous

A bright streak flashes from you to a point you choose within range and then blossoms with a low roar into a fiery explosion. Each creature in a 20-foot-radius Sphere centered on that point makes a Dexterity saving throw, taking 8d6 Fire damage on a failed save or half as much damage on a successful one.

Flammable objects in the area that aren't being worn or carried start burning.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 3.

#### Fire Bolt

_Evocation Cantrip (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You hurl a mote of fire at a creature or an object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 Fire damage. A flammable object hit by this spell starts burning if it isn't being worn or carried.

_Cantrip Upgrade._ The damage increases by 1d10 when you reach levels 5 (2d10), 11 (3d10), and 17 (4d10).

#### Fire Shield

_Level 4 Evocation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a bit of phosphorus or a firefly)
**Duration:** 10 minutes

Wispy flames wreathe your body for the duration, shedding Bright Light in a 10-foot radius and Dim Light for an additional 10 feet.

The flames provide you with a warm shield or a chill shield, as you choose. The warm shield grants you Resistance to Cold damage, and the chill shield grants you Resistance to Fire damage.

In addition, whenever a creature within 5 feet of you hits you with a melee attack roll, the shield erupts with flame. The attacker takes 2d8 Fire damage from a warm shield or 2d8 Cold damage from a chill shield.

#### Fire Storm

_Level 7 Evocation (Cleric, Druid, Sorcerer)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S
**Duration:** Instantaneous

A storm of fire appears within range. The area of the storm consists of up to ten 10-foot Cubes, which you arrange as you like. Each Cube must be contiguous with at least one other Cube. Each creature in the area makes a Dexterity saving throw, taking 7d10 Fire damage on a failed save or half as much damage on a successful one.

Flammable objects in the area that aren't being worn or carried start burning.

#### Flame Blade

_Level 2 Evocation (Druid, Sorcerer)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V, S, M (a sumac leaf)
**Duration:** Concentration, up to 10 minutes

You evoke a fiery blade in your free hand. The blade is similar in size and shape to a scimitar, and it lasts for the duration. If you let go of the blade, it disappears, but you can evoke it again as a Bonus Action.

As a Magic action, you can make a melee spell attack with the fiery blade. On a hit, the target takes Fire damage equal to 3d6 plus your spellcasting ability modifier.

The flaming blade sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 2.

#### Flame Strike

_Level 5 Evocation (Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a pinch of sulfur)
**Duration:** Instantaneous

A vertical column of brilliant fire roars down from above. Each creature in a 10-foot-radius, 40-foot-high Cylinder centered on a point within range makes a Dexterity saving throw, taking 5d6 Fire damage and 5d6 Radiant damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The Fire damage and the Radiant damage increase by 1d6 for each spell slot level above 5.

#### Flaming Sphere

_Level 2 Conjuration (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a ball of wax)
**Duration:** Concentration, up to 1 minute

You create a 5-foot-diameter sphere of fire in an unoccupied space on the ground within range. It lasts for the duration. Any creature that ends its turn within 5 feet of the sphere makes a Dexterity saving throw, taking 2d6 Fire damage on a failed save or half as much damage on a successful one.

As a Bonus Action, you can move the sphere up to 30 feet, rolling it along the ground. If you move the sphere into a creature's space, that creature makes the save against the sphere, and the sphere stops moving for the turn.

When you move the sphere, you can direct it over barriers up to 5 feet tall and jump it across pits up to 10 feet wide. Flammable objects that aren't being worn or carried start burning if touched by the sphere, and it sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 2.

#### Flesh to Stone

_Level 6 Transmutation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a cockatrice feather)
**Duration:** Concentration, up to 1 minute

You attempt to turn one creature that you can see within range into stone. The target makes a Constitution saving throw. On a failed save, it has the Restrained condition for the duration. On a successful save, its Speed is 0 until the start of your next turn. Constructs automatically succeed on the save.

A Restrained target makes another Constitution saving throw at the end of each of its turns. If it successfully saves against this spell three times, the spell ends. If it fails its saves three times, it is turned to stone and has the Petrified condition for the duration. The successes and failures needn't be consecutive; keep track of both until the target collects three of a kind.

If you maintain your Concentration on this spell for the entire possible duration, the target is Petrified until the condition is ended by _Greater Restoration_ or similar magic.

#### Floating Disk

_Level 1 Conjuration (Wizard)_

**Casting Time:** Action or Ritual
**Range:** 30 feet
**Components:** V, S, M (a drop of mercury)
**Duration:** 1 hour

This spell creates a circular, horizontal plane of force, 3 feet in diameter and 1 inch thick, that floats 3 feet above the ground in an unoccupied space of your choice that you can see within range. The disk remains for the duration and can hold up to 500 pounds. If more weight is placed on it, the spell ends, and everything on the disk falls to the ground.

The disk is immobile while you are within 20 feet of it. If you move more than 20 feet away from it, the disk follows you so that it remains within 20 feet of you. It can move across uneven terrain, up or down stairs, slopes and the like, but it can't cross an elevation change of 10 feet or more. For example, the disk can't move across a 10-foot-deep pit, nor could it leave such a pit if it was created at the bottom.

If you move more than 100 feet from the disk (typically because it can't move around an obstacle to follow you), the spell ends.

#### Fly

_Level 3 Transmutation (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a feather)
**Duration:** Concentration, up to 10 minutes

You touch a willing creature. For the duration, the target gains a Fly Speed of 60 feet and can hover. When the spell ends, the target falls if it is still aloft unless it can stop the fall.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 3.

#### Fog Cloud

_Level 1 Conjuration (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 1 hour

You create a 20-foot-radius Sphere of fog centered on a point within range. The Sphere is Heavily Obscured. It lasts for the duration or until a strong wind (such as one created by _Gust of Wind_) disperses it.

_Using a Higher-Level Spell Slot._ The fog's radius increases by 20 feet for each spell slot level above 1.

#### Forbiddance

_Level 6 Abjuration (Cleric)_

**Casting Time:** 10 minutes or Ritual
**Range:** Touch
**Components:** V, S, M (ruby dust worth 1,000+ GP)
**Duration:** 1 day

You create a ward against magical travel that protects up to 40,000 square feet of floor space to a height of 30 feet above the floor. For the duration, creatures can't teleport into the area or use portals, such as those created by the _Gate_ spell, to enter the area. The spell proofs the area against planar travel, and therefore prevents creatures from accessing the area by way of the Astral Plane, the Ethereal Plane, the Feywild, the Shadowfell, or the _Plane Shift_ spell.

In addition, the spell damages types of creatures that you choose when you cast it. Choose one or more of the following: Aberrations, Celestials, Elementals, Fey, Fiends, and Undead. When a creature of a chosen type enters the spell's area for the first time on a turn or ends its turn there, the creature takes 5d10 Radiant or Necrotic damage (your choice when you cast this spell).

You can designate a password when you cast the spell. A creature that speaks the password as it enters the area takes no damage from the spell.

The spell's area can't overlap with the area of another _Forbiddance_ spell. If you cast _Forbiddance_ every day for 30 days in the same location, the spell lasts until it is dispelled, and the Material components are consumed on the last casting.

#### Forcecage

_Level 7 Evocation (Bard, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 100 feet
**Components:** V, S, M (ruby dust worth 1,500+ GP, which the spell consumes)
**Duration:** Concentration, up to 1 hour

An immobile, Invisible, Cube-shaped prison composed of magical force springs into existence around an area you choose within range. The prison can be a cage or a solid box, as you choose.

A prison in the shape of a cage can be up to 20 feet on a side and is made from 1/2-inch diameter bars spaced 1/2 inch apart. A prison in the shape of a box can be up to 10 feet on a side, creating a solid barrier that prevents any matter from passing through it and blocking any spells cast into or out from the area.

When you cast the spell, any creature that is completely inside the cage's area is trapped. Creatures only partially within the area, or those too large to fit inside it, are pushed away from the center of the area until they are completely outside it.

A creature inside the cage can't leave it by nonmagical means. If the creature tries to use teleportation or interplanar travel to leave, it must first make a Charisma saving throw. On a successful save, the creature can use that magic to exit the cage. On a failed save, the creature doesn't exit the cage and wastes the spell or effect. The cage also extends into the Ethereal Plane, blocking ethereal travel.

This spell can't be dispelled by _Dispel Magic_.

#### Foresight

_Level 9 Divination (Bard, Druid, Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** Touch
**Components:** V, S, M (a hummingbird feather)
**Duration:** 8 hours

You touch a willing creature and bestow a limited ability to see into the immediate future. For the duration, the target has Advantage on D20 Tests, and other creatures have Disadvantage on attack rolls against it. The spell ends early if you cast it again.

#### Freedom of Movement

_Level 4 Abjuration (Bard, Cleric, Druid, Ranger)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a leather strap)
**Duration:** 1 hour

You touch a willing creature. For the duration, the target's movement is unaffected by Difficult Terrain, and spells and other magical effects can neither reduce the target's Speed nor cause the target to have the Paralyzed or Restrained conditions. The target also has a Swim Speed equal to its Speed.

In addition, the target can spend 5 feet of movement to automatically escape from nonmagical restraints, such as manacles or a creature imposing the Grappled condition on it.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 4.

#### Freezing Sphere

_Level 6 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 300 feet
**Components:** V, S, M (a miniature crystal sphere)
**Duration:** Instantaneous

A frigid globe streaks from you to a point of your choice within range, where it explodes in a 60-foot-radius Sphere. Each creature in that area makes a Constitution saving throw, taking 10d6 Cold damage on failed save or half as much damage on a successful one.

If the globe strikes a body of water, it freezes the water to a depth of 6 inches over an area 30 feet square. This ice lasts for 1 minute. Creatures that were swimming on the surface of frozen water are trapped in the ice and have the Restrained condition. A trapped creature can take an action to make a Strength (Athletics) check against your spell save DC to break free.

You can refrain from firing the globe after completing the spell's casting. If you do so, a globe about the size of a sling bullet, cool to the touch, appears in your hand. At any time, you or a creature you give the globe to can throw the globe (to a range of 40 feet) or hurl it with a sling (to the sling's normal range). It shatters on impact, with the same effect as a normal casting of the spell. You can also set the globe down without shattering it. After 1 minute, if the globe hasn't already shattered, it explodes.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 6.

#### Gaseous Form

_Level 3 Transmutation (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a bit of gauze)
**Duration:** Concentration, up to 1 hour

A willing creature you touch shape-shifts, along with everything it's wearing and carrying, into a misty cloud for the duration. The spell ends on the target if it drops to 0 Hit Points or if it takes a Magic action to end the spell on itself.

While in this form, the target's only method of movement is a Fly Speed of 10 feet, and it can hover. The target can enter and occupy the space of another creature. The target has Resistance to Bludgeoning, Piercing, and Slashing damage; it has Immunity to the Prone condition; and it has Advantage on Strength, Dexterity, and Constitution saving throws. The target can pass through narrow openings, but it treats liquids as though they were solid surfaces.

The target can't talk or manipulate objects, and any objects it was carrying or holding can't be dropped, used, or otherwise interacted with. Finally, the target can't attack or cast spells.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 3.

#### Gate

_Level 9 Conjuration (Cleric, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a diamond worth 5,000+ GP)
**Duration:** Concentration, up to 1 minute

You conjure a portal linking an unoccupied space you can see within range to a precise location on a different plane of existence. The portal is a circular opening, which you can make 5 to 20 feet in diameter. You can orient the portal in any direction you choose. The portal lasts for the duration, and the portal's destination is visible through it.

The portal has a front and a back on each plane where it appears. Travel through the portal is possible only by moving through its front. Anything that does so is instantly transported to the other plane, appearing in the unoccupied space nearest to the portal.

Deities and other planar rulers can prevent portals created by this spell from opening in their presence or anywhere within their domains.

When you cast this spell, you can speak the name of a specific creature (a pseudonym, title, or nickname doesn't work). If that creature is on a plane other than the one you are on, the portal opens next to the named creature and transports it to the nearest unoccupied space on your side of the portal. You gain no special power over the creature, and it is free to act as the GM deems appropriate. It might leave, attack you, or help you.

#### Geas

_Level 5 Enchantment (Bard, Cleric, Druid, Paladin, Wizard)_

**Casting Time:** 1 minute
**Range:** 60 feet
**Components:** V
**Duration:** 30 days

You give a verbal command to a creature that you can see within range, ordering it to carry out some service or refrain from an action or a course of activity as you decide. The target must succeed on a Wisdom saving throw or have the Charmed condition for the duration. The target automatically succeeds if it can't understand your command.

While Charmed, the creature takes 5d10 Psychic damage if it acts in a manner directly counter to your command. It takes this damage no more than once each day.

You can issue any command you choose, short of an activity that would result in certain death. Should you issue a suicidal command, the spell ends.

A _Remove Curse_, _Greater Restoration_, or _Wish_ spell ends this spell.

_Using a Higher-Level Spell Slot._ If you use a level 7 or 8 spell slot, the duration is 365 days. If you use a level 9 spell slot, the spell lasts until it is ended by one of the spells mentioned above.

#### Gentle Repose

_Level 2 Necromancy (Cleric, Paladin, Wizard)_

**Casting Time:** Action or Ritual
**Range:** Touch
**Components:** V, S, M (2 Copper Pieces, which the spell consumes)
**Duration:** 10 days

You touch a corpse or other remains. For the duration, the target is protected from decay and can't become Undead.

The spell also effectively extends the time limit on raising the target from the dead, since days spent under the influence of this spell don't count against the time limit of spells such as _Raise Dead_.

#### Giant Insect

_Level 4 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You summon a giant centipede, spider, or wasp (chosen when you cast the spell). It manifests in an unoccupied space you can see within range and uses the Giant Insect stat block. The form you choose determines certain details in its stat block. The creature disappears when it drops to 0 Hit Points or when the spell ends.

The creature is an ally to you and your allies. In combat, the creature shares your Initiative count, but it takes its turn immediately after yours. It obeys your verbal commands (no action required by you). If you don't issue any, it takes the Dodge action and uses its movement to avoid danger.
_Using a Higher-Level Spell Slot._ Use the spell slot's level for the spell's level in the stat block.

## Giant Insect

_Large Beast, Unaligned_

**AC** 11 + the spell's level
**HP** 30 + 10 for each spell level above 4
**Speed** 40 ft., Climb 40 ft., Fly 40 ft. (Wasp only)

<table>
  <thead>
    <tr>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th></th>
      <th>MOD</th>
      <th>SAVE</th>
      <th colspan="3"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>STR</td>
      <td>17</td>
      <td>+3</td>
      <td>+3</td>
      <td>DEX</td>
      <td>13</td>
      <td>+1</td>
      <td>+1</td>
      <td>CON</td>
      <td>15</td>
      <td>+2</td>
      <td>+2</td>
    </tr>
    <tr>
      <td>INT</td>
      <td>4</td>
      <td>−3</td>
      <td>−3</td>
      <td>WIS</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
      <td>CHA</td>
      <td>3</td>
      <td>−4</td>
      <td>−4</td>
    </tr>
  </tbody>
</table>

**Senses** Darkvision 60 ft.; Passive Perception 12
**Languages** Understands the languages you know
**CR** None (XP 0; PB equals your Proficiency Bonus)

#### Traits

_Spider Climb._ The insect can climb difficult surfaces, including along ceilings, without needing to make an ability check.

#### Actions

_Multiattack._ The insect makes a number of attacks equal to half this spell's level (round down).

_Poison Jab. Melee Attack Roll:_ Bonus equals your spell attack modifier, reach 10 ft. _Hit:_ 1d6 + 3 plus the spell's level Piercing damage plus 1d4 Poison damage.

_Web Bolt (Spider Only). Ranged Attack Roll:_ Bonus equals your spell attack modifier, range 60 ft. _Hit:_ 1d10 + 3 plus the spell's level Bludgeoning damage, and the target's Speed is reduced to 0 until the start of the insect's next turn.

#### Bonus Actions

_Venomous Spew (Centipede Only). Constitution Saving Throw:_ Your spell save DC, one creature the insect can see within 10 feet. _Failure:_ The target has the Poisoned condition until the start of the insect's next turn.

#### Glibness

_Level 8 Enchantment (Bard, Warlock)_

**Casting Time:** Action
**Range:** Self
**Components:** V
**Duration:** 1 hour

Until the spell ends, when you make a Charisma check, you can replace the number you roll with a 15. Additionally, no matter what you say, magic that would determine if you are telling the truth indicates that you are being truthful.

#### Globe of Invulnerability

_Level 6 Abjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a glass bead)
**Duration:** Concentration, up to 1 minute

An immobile, shimmering barrier appears in a 10-foot Emanation around you and remains for the duration.

Any spell of level 5 or lower cast from outside the barrier can't affect anything within it. Such a spell can target creatures and objects within the barrier, but the spell has no effect on them. Similarly, the area within the barrier is excluded from areas of effect created by such spells.

_Using a Higher-Level Spell Slot._ The barrier blocks spells of 1 level higher for each spell slot level above 6.

#### Glyph of Warding

_Level 3 Abjuration (Bard, Cleric, Wizard)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (powdered diamond worth 200+ GP, which the spell consumes)
**Duration:** Until dispelled or triggered

You inscribe a glyph that later unleashes a magical effect. You inscribe it either on a surface (such as a table or a section of floor) or within an object that can be closed (such as a book or chest) to conceal the glyph. The glyph can cover an area no larger than 10 feet in diameter. If the surface or object is moved more than 10 feet from where you cast this spell, the glyph is broken, and the spell ends without being triggered.

The glyph is nearly imperceptible and requires a successful Wisdom (Perception) check against your spell save DC to notice.

When you inscribe the glyph, you set its trigger and choose whether it's an explosive rune or a spell glyph, as explained below.

_Set the Trigger._ You decide what triggers the glyph when you cast the spell. For glyphs inscribed on a surface, common triggers include touching or stepping on the glyph, removing another object covering it, or approaching within a certain distance of it. For glyphs inscribed within an object, common triggers include opening that object or seeing the glyph. Once a glyph is triggered, this spell ends.

You can refine the trigger so that only creatures of certain types activate it (for example, the glyph could be set to affect Aberrations). You can also set conditions for creatures that don't trigger the glyph, such as those who say a certain password.

_Explosive Rune._ When triggered, the glyph erupts with magical energy in a 20-foot-radius Sphere centered on the glyph. Each creature in the area makes a Dexterity saving throw. A creature takes 5d8 Acid, Cold, Fire, Lightning, or Thunder damage (your
choice when you create the glyph) on a failed save or half as much damage on a successful one.

_Spell Glyph._ You can store a prepared spell of level 3 or lower in the glyph by casting it as part of creating the glyph. The spell must target a single creature or an area. The spell being stored has no immediate effect when cast in this way.

When the glyph is triggered, the stored spell takes effect. If the spell has a target, it targets the creature that triggered the glyph. If the spell affects an area, the area is centered on that creature. If the spell summons Hostile creatures or creates harmful objects or traps, they appear as close as possible to the intruder and attack it. If the spell requires Concentration, it lasts until the end of its full duration.

_Using a Higher-Level Spell Slot._ The damage of an explosive rune increases by 1d8 for each spell slot level above 3. If you create a spell glyph, you can store any spell of up to the same level as the spell slot you use for the _Glyph of Warding_.

#### Goodberry

_Level 1 Conjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a sprig of mistletoe)
**Duration:** 24 hours

Ten berries appear in your hand and are infused with magic for the duration. A creature can take a Bonus Action to eat one berry. Eating a berry restores 1 Hit Point, and the berry provides enough nourishment to sustain a creature for one day.

Uneaten berries disappear when the spell ends.

#### Grease

_Level 1 Conjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a bit of pork rind or butter)
**Duration:** 1 minute

Nonflammable grease covers the ground in a 10-foot square centered on a point within range and turns it into Difficult Terrain for the duration.

When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or have the Prone condition. A creature that enters the area or ends its turn there must also succeed on that save or fall Prone.

#### Greater Invisibility

_Level 4 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Concentration, up to 1 minute

A creature you touch has the Invisible condition until the spell ends.

#### Greater Restoration

_Level 5 Abjuration (Bard, Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (diamond dust worth 100+ GP, which the spell consumes)
**Duration:** Instantaneous

You touch a creature and magically remove one of the following effects from it:

- 1 Exhaustion level
- The Charmed or Petrified condition
- A curse, including the target's Attunement to a cursed magic item
- Any reduction to one of the target's ability scores
- Any reduction to the target's Hit Point maximum

#### Guardian of Faith

_Level 4 Conjuration (Cleric)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V
**Duration:** 8 hours

A Large spectral guardian appears and hovers for the duration in an unoccupied space that you can see within range. The guardian occupies that space and is invulnerable, and it appears in a form appropriate for your deity or pantheon.

Any enemy that moves to a space within 10 feet of the guardian for the first time on a turn or starts its turn there makes a Dexterity saving throw, taking 20 Radiant damage on a failed save or half as much damage on a successful one. The guardian vanishes when it has dealt a total of 60 damage.

#### Guards and Wards

_Level 6 Abjuration (Bard, Wizard)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (a silver rod worth 10+ GP)
**Duration:** 24 hours

You create a ward that protects up to 2,500 square feet of floor space. The warded area can be up to 20 feet tall, and you shape it as one 50-foot square, one hundred 5-foot squares that are contiguous, or twenty-five 10-foot squares that are contiguous.

When you cast this spell, you can specify individuals that are unaffected by the spell's effects. You can also specify a password that, when spoken aloud within 5 feet of the warded area, makes the speaker immune to its effects.
The spell creates the effects below within the warded area. _Dispel Magic_ has no effect on _Guards and Wards_ itself, but each of the following effects can be dispelled. If all four are dispelled, _Guards and Wards_ ends. If you cast the spell every day for 365 days on the same area, the spell thereafter lasts until all its effects are dispelled.

**Corridors.** Fog fills all the warded corridors, making them Heavily Obscured. In addition, at each intersection or branching passage offering a choice of direction, there is a 50 percent chance that a creature other than you believes it is going in the opposite direction from the one it chooses.

**Doors.** All doors in the warded area are magically locked, as if sealed by the _Arcane Lock_ spell. In addition, you can cover up to ten doors with an illusion to make them appear as plain sections of wall.

**Stairs.** Webs fill all stairs in the warded area from top to bottom, as in the _Web_ spell. These strands regrow in 10 minutes if they are destroyed while _Guards and Wards_ lasts.

**Other Spell Effect.** Place one of the following magical effects within the warded area:

- _Dancing Lights_ in four corridors, with a simple program that the lights repeat as long as _Guards and Wards_ lasts
- _Magic Mouth_ in two locations
- _Stinking Cloud_ in two locations (the vapors return within 10 minutes if dispersed while _Guards and Wards_ lasts)
- _Gust of Wind_ in one corridor or room (the wind blows continuously while the spell lasts)
- _Suggestion_ in one 5-foot square; any creature that enters that square receives the suggestion mentally

#### Guidance

_Divination Cantrip (Cleric, Druid)_

**Casting Time:** Action
**Range:** Touch
**Component:** V, S
**Duration:** Concentration, up to 1 minute

You touch a willing creature and choose a skill. Until the spell ends, the creature adds 1d4 to any ability check using the chosen skill.

#### Guiding Bolt

_Level 1 Evocation (Cleric)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** 1 round

You hurl a bolt of light toward a creature within range. Make a ranged spell attack against the target. On a hit, it takes 4d6 Radiant damage, and the next attack roll made against it before the end of your next turn has Advantage.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 1.

#### Gust of Wind

_Level 2 Evocation (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a legume seed)
**Duration:** Concentration, up to 1 minute

A Line of strong wind 60 feet long and 10 feet wide blasts from you in a direction you choose for the duration. Each creature in the Line must succeed on a Strength saving throw or be pushed 15 feet away from you in a direction following the Line. A creature that ends its turn in the Line must make the same save.

Any creature in the Line must spend 2 feet of movement for every 1 foot it moves when moving closer to you.

The gust disperses gas or vapor, and it extinguishes candles and similar unprotected flames in the area. It causes protected flames, such as those of lanterns, to dance wildly and has a 50 percent chance to extinguish them.

As a Bonus Action on your later turns, you can change the direction in which the Line blasts from you.

#### Hallow

_Level 5 Abjuration (Cleric)_

**Casting Time:** 24 hours
**Range:** Touch
**Components:** V, S, M (incense worth 1,000+ GP, which the spell consumes)
**Duration:** Until dispelled

You touch a point and infuse an area around it with holy or unholy power. The area can have a radius up to 60 feet, and the spell fails if the radius includes an area already under the effect of _Hallow_. The affected area has the following effects.

**Hallowed Ward.** Choose any of these creature types: Aberration, Celestial, Elemental, Fey, Fiend, or Undead. Creatures of the chosen types can't willingly enter the area, and any creature that is possessed by or that has the Charmed or Frightened condition from such creatures isn't possessed, Charmed, or Frightened by them while in the area.

**Extra Effect.** You bind an extra effect to the area from the list below:

**Courage.** Creatures of any types you choose can't gain the Frightened condition while in the area.

**Darkness.** Darkness fills the area. Normal light, as well as magical light created by spells of a level lower than this spell, can't illuminate the area.
**Daylight.** Bright light fills the area. Magical Darkness created by spells of a level lower than this spell can't extinguish the light.

**Peaceful Rest.** Dead bodies interred in the area can't be turned into Undead.

**Extradimensional Interference.** Creatures of any types you choose can't enter or exit the area using teleportation or interplanar travel.

**Fear.** Creatures of any types you choose have the Frightened condition while in the area.

**Resistance.** Creatures of any types you choose have Resistance to one damage type of your choice while in the area.

**Silence.** No sound can emanate from within the area, and no sound can reach into it.

**Tongues.** Creatures of any types you choose can communicate with any other creature in the area even if they don't share a common language.

**Vulnerability.** Creatures of any types you choose have Vulnerability to one damage type of your choice while in the area.

#### Hallucinatory Terrain

_Level 4 Illusion (Bard, Druid, Warlock, Wizard)_

**Casting Time:** 10 minutes
**Range:** 300 feet
**Components:** V, S, M (a mushroom)
**Duration:** 24 hours

You make natural terrain in a 150-foot Cube in range look, sound, and smell like another sort of natural terrain. Thus, open fields or a road can be made to resemble a swamp, hill, crevasse, or some other difficult or impassable terrain. A pond can be made to seem like a grassy meadow, a precipice like a gentle slope, or a rock-strewn gully like a wide and smooth road. Manufactured structures, equipment, and creatures within the area aren't changed.

The tactile characteristics of the terrain are unchanged, so creatures entering the area are likely to notice the illusion. If the difference isn't obvious by touch, a creature examining the illusion can take the Study action to make an Intelligence (Investigation) check against your spell save DC to disbelieve it. If a creature discerns that the terrain is illusory, the creature sees a vague image superimposed on the real terrain.

#### Harm

_Level 6 Necromancy (Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You unleash virulent magic on a creature you can see within range. The target makes a Constitution saving throw. On a failed save, it takes 14d6 Necrotic damage, and its Hit Point maximum is reduced by an amount equal to the Necrotic damage it took. On a successful save, it takes half as much damage only. This spell can't reduce a target's Hit Point maximum below 1.

#### Haste

_Level 3 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a shaving of licorice root)
**Duration:** Concentration, up to 1 minute

Choose a willing creature that you can see within range. Until the spell ends, the target's Speed is doubled, it gains a +2 bonus to Armor Class, it has Advantage on Dexterity saving throws, and it gains an additional action on each of its turns. That action can be used to take only the Attack (one attack only), Dash, Disengage, Hide, or Utilize action.

When the spell ends, the target is Incapacitated and has a Speed of 0 until the end of its next turn, as a wave of lethargy washes over it.

#### Heal

_Level 6 Abjuration (Cleric, Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

Choose a creature that you can see within range. Positive energy washes through the target, restoring 70 Hit Points. This spell also ends the Blinded, Deafened, and Poisoned conditions on the target.

_Using a Higher-Level Spell Slot._ The healing increases by 10 for each spell slot level above 6.

#### Healing Word

_Level 1 Abjuration (Bard, Cleric, Druid)_

**Casting Time:** Bonus Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

A creature of your choice that you can see within range regains Hit Points equal to 2d4 plus your spellcasting ability modifier.

_Using a Higher-Level Spell Slot._ The healing increases by 2d4 for each spell slot level above 1.

#### Heat Metal

_Level 2 Transmutation (Bard, Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a piece of iron and a flame)
**Duration:** Concentration, up to 1 minute
Choose a manufactured metal object, such as a metal weapon or a suit of Heavy or Medium metal armor, that you can see within range. You cause the object to glow red-hot. Any creature in physical contact with the object takes 2d8 Fire damage when you cast the spell. Until the spell ends, you can take a Bonus Action on each of your later turns to deal this damage again if the object is within range.

If a creature is holding or wearing the object and takes the damage from it, the creature must succeed on a Constitution saving throw or drop the object if it can. If it doesn't drop the object, it has Disadvantage on attack rolls and ability checks until the start of your next turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 2.

#### Hellish Rebuke

_Level 1 Evocation (Warlock)_

**Casting Time:** Reaction, which you take in response to taking damage from a creature that you can see within 60 feet of yourself
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

The creature that damaged you is momentarily surrounded by green flames. It makes a Dexterity saving throw, taking 2d10 Fire damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 1.

#### Heroes' Feast

_Level 6 Conjuration (Bard, Cleric, Druid)_

**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (a gem-encrusted bowl worth 1,000+ GP, which the spell consumes)
**Duration:** Instantaneous

You conjure a feast that appears on a surface in an unoccupied 10-foot Cube next to you. The feast takes 1 hour to consume and disappears at the end of that time, and the beneficial effects don't set in until this hour is over. Up to twelve creatures can partake of the feast.

A creature that partakes gains several benefits, which last for 24 hours. The creature has Resistance to Poison damage, and it has Immunity to the Frightened and Poisoned conditions. Its Hit Point maximum also increases by 2d10, and it gains the same number of Hit Points.

#### Heroism

_Level 1 Enchantment (Bard, Paladin)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Concentration, up to 1 minute

A willing creature you touch is imbued with bravery. Until the spell ends, the creature is immune to the Frightened condition and gains Temporary Hit Points equal to your spellcasting ability modifier at the start of each of its turns.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Hex

_Level 1 Enchantment (Warlock)_

**Casting Time:** Bonus Action
**Range:** 90 feet
**Components:** V, S, M (the petrified eye of a newt)
**Duration:** Concentration, up to 1 hour

You place a curse on a creature that you can see within range. Until the spell ends, you deal an extra 1d6 Necrotic damage to the target whenever you hit it with an attack roll. Also, choose one ability when you cast the spell. The target has Disadvantage on ability checks made with the chosen ability.

If the target drops to 0 Hit Points before this spell ends, you can take a Bonus Action on a later turn to curse a new creature.

_Using a Higher-Level Spell Slot._ Your Concentration can last longer with a spell slot of level 2 (up to 4 hours), 3–4 (up to 8 hours), or 5+ (24 hours).

#### Hideous Laughter

_Level 1 Enchantment (Bard, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a tart and a feather)
**Duration:** Concentration, up to 1 minute

One creature of your choice that you can see within range makes a Wisdom saving throw. On a failed save, it has the Prone and Incapacitated conditions for the duration. During that time, it laughs uncontrollably if it's capable of laughter, and it can't end the Prone condition on itself.

At the end of each of its turns and each time it takes damage, it makes another Wisdom saving throw. The target has Advantage on the save if the save is triggered by damage. On a successful save, the spell ends.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Hold Monster

_Level 5 Enchantment (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (a straight piece of iron)
**Duration:** Concentration, up to 1 minute

Choose a creature that you can see within range. The target must succeed on a Wisdom saving throw or have the Paralyzed condition for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 5.

#### Hold Person

_Level 2 Enchantment (Bard, Cleric, Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a straight piece of iron)
**Duration:** Concentration, up to 1 minute

Choose a Humanoid that you can see within range. The target must succeed on a Wisdom saving throw or have the Paralyzed condition for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success.

_Using a Higher-Level Spell Slot._ You can target one additional Humanoid for each spell slot level above 2.

#### Holy Aura

_Level 8 Abjuration (Cleric)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a reliquary worth 1,000+ GP)
**Duration:** Concentration, up to 1 minute

For the duration, you emit an aura in a 30-foot Emanation. While in the aura, creatures of your choice have Advantage on all saving throws, and other creatures have Disadvantage on attack rolls against them. In addition, when a Fiend or an Undead hits an affected creature with a melee attack roll, the attacker must succeed on a Constitution saving throw or have the Blinded condition until the end of its next turn.

#### Hunter's Mark

_Level 1 Divination (Ranger)_

**Casting Time:** Bonus Action
**Range:** 90 feet
**Components:** V
**Duration:** Concentration, up to 1 hour

You magically mark one creature you can see within range as your quarry. Until the spell ends, you deal an extra 1d6 Force damage to the target whenever you hit it with an attack roll. You also have Advantage on any Wisdom (Perception or Survival) check you make to find it.

If the target drops to 0 Hit Points before this spell ends, you can take a Bonus Action to move the mark to a new creature you can see within range.

_Using a Higher-Level Spell Slot._ Your Concentration can last longer with a spell slot of level 3–4 (up to 8 hours) or 5+ (up to 24 hours).

#### Hypnotic Pattern

_Level 3 Illusion (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** S, M (a pinch of confetti)
**Duration:** Concentration, up to 1 minute

You create a twisting pattern of colors in a 30-foot Cube within range. The pattern appears for a moment and vanishes. Each creature in the area who can see the pattern must succeed on a Wisdom saving throw or have the Charmed condition for the duration. While Charmed, the creature has the Incapacitated condition and a Speed of 0.

The spell ends for an affected creature if it takes any damage or if someone else uses an action to shake the creature out of its stupor.

#### Ice Knife

_Level 1 Conjuration (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** S, M (a drop of water or a piece of ice)
**Duration:** Instantaneous

You create a shard of ice and fling it at one creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 Piercing damage. Hit or miss, the shard then explodes. The target and each creature within 5 feet of it must succeed on a Dexterity saving throw or take 2d6 Cold damage.

_Using a Higher-Level Spell Slot._ The Cold damage increases by 1d6 for each spell slot level above 1.

#### Ice Storm

_Level 4 Evocation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 300 feet
**Components:** V, S, M (a mitten)
**Duration:** Instantaneous

Hail falls in a 20-foot-radius, 40-foot-high Cylinder centered on a point within range. Each creature in the Cylinder makes a Dexterity saving throw. A creature takes 2d10 Bludgeoning damage and 4d6 Cold damage on a failed save or half as much damage on a successful one.

Hailstones turn ground in the Cylinder into Difficult Terrain until the end of your next turn.
_Using a Higher-Level Spell Slot._ The Bludgeoning damage increases by 1d10 for each spell slot level above 4.

#### Identify

_Level 1 Divination (Bard, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Touch
**Components:** V, S, M (a pearl worth 100+ GP)
**Duration:** Instantaneous

You touch an object throughout the spell's casting. If the object is a magic item or some other magical object, you learn its properties and how to use them, whether it requires Attunement, and how many charges it has, if any. You learn whether any ongoing spells are affecting the item and what they are. If the item was created by a spell, you learn that spell's name.

If you instead touch a creature throughout the casting, you learn which ongoing spells, if any, are currently affecting it.

#### Illusory Script

_Level 1 Illusion (Bard, Warlock, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Touch
**Components:** S, M (ink worth 10+ GP, which the spell consumes)
**Duration:** 10 days

You write on parchment, paper, or another suitable material and imbue it with an illusion that lasts for the duration. To you and any creatures you designate when you cast the spell, the writing appears normal, seems to be written in your hand, and conveys whatever meaning you intended when you wrote the text. To all others, the writing appears as if it were written in an unknown or magical script that is unintelligible. Alternatively, the illusion can alter the meaning, handwriting, and language of the text, though the language must be one you know.

If the spell is dispelled, the original script and the illusion both disappear.

A creature that has Truesight can read the hidden message.

#### Imprisonment

_Level 9 Abjuration (Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** 30 feet
**Components:** V, S, M (a statuette of the target worth 5,000+ GP)
**Duration:** Until dispelled

You create a magical restraint to hold a creature that you can see within range. The target must make a Wisdom saving throw. On a successful save, the target is unaffected, and it is immune to this spell for the next 24 hours. On a failed save, the target is imprisoned. While imprisoned, the target doesn't need to breathe, eat, or drink, and it doesn't age. Divination spells can't locate or perceive the imprisoned target, and the target can't teleport.

Until the spell ends, the target is also affected by one of the following effects of your choice:

**Burial.** The target is entombed beneath the earth in a hollow globe of magical force that is just large enough to contain the target. Nothing can pass into or out of the globe.

**Chaining.** Chains firmly rooted in the ground hold the target in place. The target has the Restrained condition and can't be moved by any means.

**Hedged Prison.** The target is trapped in a demiplane that is warded against teleportation and planar travel. The demiplane is your choice of a labyrinth, a cage, a tower, or the like.

**Minimus Containment.** The target becomes 1 inch tall and is trapped inside an indestructible gemstone or a similar object. Light can pass through the gemstone (allowing the target to see out and other creatures to see in), but nothing else can pass through by any means.

**Slumber.** The target has the Unconscious condition and can't be awoken.

_Ending the Spell._ When you cast the spell, specify a trigger that will end it. The trigger can be as simple or as elaborate as you choose, but the GM must agree that it has a high likelihood of happening within the next decade. The trigger must be an observable action, such as someone making a particular offering at the temple of your god, saving your true love, or defeating a specific monster.

A _Dispel Magic_ spell can end the spell only if it is cast with a level 9 spell slot, targeting either the prison or the component used to create it.

#### Incendiary Cloud

_Level 8 Conjuration (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

A swirling cloud of embers and smoke fills a 20-foot-radius Sphere centered on a point within range. The cloud's area is Heavily Obscured. It lasts for the duration or until a strong wind (like that created by _Gust of Wind_) disperses it.

When the cloud appears, each creature in it makes a Dexterity saving throw, taking 10d8 Fire damage on a failed save or half as much damage on a successful one. A creature must also make this save when the Sphere moves into its space and when it enters the Sphere or ends its turn there. A creature makes this save only once per turn.
The cloud moves 10 feet away from you in a direction you choose at the start of each of your turns.

#### Inflict Wounds

_Level 1 Necromancy (Cleric)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

A creature you touch makes a Constitution saving throw, taking 2d10 Necrotic damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 1.

#### Insect Plague

_Level 5 Conjuration (Cleric, Druid, Sorcerer)_

**Casting Time:** Action
**Range:** 300 feet
**Components:** V, S, M (a locust)
**Duration:** Concentration, up to 10 minutes

Swarming locusts fill a 20-foot-radius Sphere centered on a point you choose within range. The Sphere remains for the duration, and its area is Lightly Obscured and Difficult Terrain.

When the swarm appears, each creature in it makes a Constitution saving throw, taking 4d10 Piercing damage on a failed save or half as much damage on a successful one. A creature also makes this save when it enters the spell's area for the first time on a turn or ends its turn there. A creature makes this save only once per turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 5.

#### Instant Summons

_Level 6 Conjuration (Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Touch
**Components:** V, S, M (a sapphire worth 1,000+ GP)
**Duration:** Until dispelled

You touch the sapphire used in the casting and an object weighing 10 pounds or less whose longest dimension is 6 feet or less. The spell leaves an Invisible mark on that object and invisibly inscribes the object's name on the sapphire. Each time you cast this spell, you must use a different sapphire.

Thereafter, you can take a Magic action to speak the object's name and crush the sapphire. The object instantly appears in your hand regardless of physical or planar distances, and the spell ends.

If another creature is holding or carrying the object, crushing the sapphire doesn't transport it, but instead you learn who that creature is and where that creature is currently located.

#### Irresistible Dance

_Level 6 Enchantment (Bard, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V
**Duration:** Concentration, up to 1 minute

One creature that you can see within range must make a Wisdom saving throw. On a successful save, the target dances comically until the end of its next turn, during which it must spend all its movement to dance in place.

On a failed save, the target has the Charmed condition for the duration. While Charmed, the target dances comically, must use all its movement to dance in place, and has Disadvantage on Dexterity saving throws and attack rolls, and other creatures have Advantage on attack rolls against it. On each of its turns, the target can take an action to collect itself and repeat the save, ending the spell on itself on a success.

#### Invisibility

_Level 2 Illusion (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (an eyelash in gum arabic)
**Duration:** Concentration, up to 1 hour

A creature you touch has the Invisible condition until the spell ends. The spell ends early immediately after the target makes an attack roll, deals damage, or casts a spell.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 2.

#### Jump

_Level 1 Transmutation (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Bonus Action
**Range:** Touch
**Component:** V, S, M (a grasshopper's hind leg)
**Duration:** 1 minute

You touch a willing creature. Once on each of its turns until the spell ends, that creature can jump up to 30 feet by spending 10 feet of movement.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Knock

_Level 2 Transmutation (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous
Choose an object that you can see within range. The object can be a door, a box, a chest, a set of manacles, a padlock, or another object that contains a mundane or magical means that prevents access.

A target that is held shut by a mundane lock or that is stuck or barred becomes unlocked, unstuck, or unbarred. If the object has multiple locks, only one of them is unlocked.

If the target is held shut by _Arcane Lock_, that spell is suppressed for 10 minutes, during which time the target can be opened and closed.

When you cast the spell, a loud knock, audible up to 300 feet away, emanates from the target.

#### Legend Lore

_Level 5 Divination (Bard, Cleric, Wizard)_

**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (incense worth 250+ GP, which the spell consumes, and four ivory strips worth 50+ GP each)
**Duration:** Instantaneous

Name or describe a famous person, place, or object. The spell brings to your mind a brief summary of the significant lore about that famous thing, as described by the GM.

The lore might consist of important details, amusing revelations, or even secret lore that has never been widely known. The more information you already know about the thing, the more precise and detailed the information you receive is. That information is accurate but might be couched in figurative language or poetry, as determined by the GM.

If the famous thing you chose isn't actually famous, you hear sad musical notes played on a trombone, and the spell fails.

#### Lesser Restoration

_Level 2 Abjuration (Bard, Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Bonus Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

You touch a creature and end one condition on it: Blinded, Deafened, Paralyzed, or Poisoned.

#### Levitate

_Level 2 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a metal spring)
**Duration:** Concentration, up to 10 minutes

One creature or loose object of your choice that you can see within range rises vertically up to 20 feet and remains suspended there for the duration. The spell can levitate an object that weighs up to 500 pounds. An unwilling creature that succeeds on a Constitution saving throw is unaffected.

The target can move only by pushing or pulling against a fixed object or surface within reach (such as a wall or a ceiling), which allows it to move as if it were climbing. You can change the target's altitude by up to 20 feet in either direction on your turn. If you are the target, you can move up or down as part of your move. Otherwise, you can take a Magic action to move the target, which must remain within the spell's range.

When the spell ends, the target floats gently to the ground if it is still aloft.

#### Light

_Evocation Cantrip (Bard, Cleric, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, M (a firefly or phosphorescent moss)
**Duration:** 1 hour

You touch one Large or smaller object that isn't being worn or carried by someone else. Until the spell ends, the object sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. The light can be colored as you like.

Covering the object with something opaque blocks the light. The spell ends if you cast it again.

#### Lightning Bolt

_Level 3 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a bit of fur and a crystal rod)
**Duration:** Instantaneous

A stroke of lightning forming a 100-foot-long, 5-foot-wide Line blasts out from you in a direction you choose. Each creature in the Line makes a Dexterity saving throw, taking 8d6 Lightning damage on a failed save or half as much damage on a successful one.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 3.

#### Locate Animals or Plants

_Level 2 Divination (Bard, Druid, Ranger)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S, M (fur from a bloodhound)
**Duration:** Instantaneous

Describe or name a specific kind of Beast, Plant creature, or nonmagical plant. You learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present.

#### Locate Creature

_Level 4 Divination (Bard, Cleric, Druid, Paladin, Ranger, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (fur from a bloodhound)
**Duration:** Concentration, up to 1 hour

Describe or name a creature that is familiar to you. You sense the direction to the creature's location if that creature is within 1,000 feet of you. If the creature is moving, you know the direction of its movement.

The spell can locate a specific creature known to you or the nearest creature of a specific kind (such as a human or a unicorn) if you have seen such a creature up close—within 30 feet—at least once. If the creature you described or named is in a different form, such as under the effects of a _Flesh to Stone_ or _Polymorph_ spell, this spell doesn't locate the creature.

This spell can't locate a creature if any thickness of lead blocks a direct path between you and the creature.

#### Locate Object

_Level 2 Divination (Bard, Cleric, Druid, Paladin, Ranger, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a forked twig)
**Duration:** Concentration, up to 10 minutes

Describe or name an object that is familiar to you. You sense the direction to the object's location if that object is within 1,000 feet of you. If the object is in motion, you know the direction of its movement.

The spell can locate a specific object known to you if you have seen it up close—within 30 feet—at least once. Alternatively, the spell can locate the nearest object of a particular kind, such as a certain kind of apparel, jewelry, furniture, tool, or weapon.

This spell can't locate an object if any thickness of lead blocks a direct path between you and the object.

#### Longstrider

_Level 1 Transmutation (Bard, Druid, Ranger, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a pinch of dirt)
**Duration:** 1 hour

You touch a creature. The target's Speed increases by 10 feet until the spell ends.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 1.

#### Mage Armor

_Level 1 Abjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a piece of cured leather)
**Duration:** 8 hours

You touch a willing creature who isn't wearing armor. Until the spell ends, the target's base AC becomes 13 plus its Dexterity modifier. The spell ends early if the target dons armor.

#### Mage Hand

_Conjuration Cantrip (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** 1 minute

A spectral, floating hand appears at a point you choose within range. The hand lasts for the duration. The hand vanishes if it is ever more than 30 feet away from you or if you cast this spell again.

When you cast the spell, you can use the hand to manipulate an object, open an unlocked door or container, stow or retrieve an item from an open container, or pour the contents out of a vial.

As a Magic action on your later turns, you can control the hand thus again. As part of that action, you can move the hand up to 30 feet.

The hand can't attack, activate magic items, or carry more than 10 pounds.

#### Magic Circle

_Level 3 Abjuration (Cleric, Paladin, Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** 10 feet
**Components:** V, S, M (salt and powdered silver worth 100+ GP, which the spell consumes)
**Duration:** 1 hour

You create a 10-foot-radius, 20-foot-tall Cylinder of magical energy centered on a point on the ground that you can see within range. Glowing runes appear wherever the Cylinder intersects with the floor or other surface.

Choose one or more of the following types of creatures: Celestials, Elementals, Fey, Fiends, or Undead. The circle affects a creature of the chosen type in the following ways:

• The creature can't willingly enter the Cylinder by nonmagical means. If the creature tries to use teleportation or interplanar travel to do so, it must first succeed on a Charisma saving throw.
• The creature has Disadvantage on attack rolls against targets within the Cylinder.
• Targets within the Cylinder can't be possessed by or gain the Charmed or Frightened condition from the creature.

Each time you cast this spell, you can cause its magic to operate in the reverse direction, preventing a creature of the specified type from leaving the Cylinder and protecting targets outside it.

_Using a Higher-Level Spell Slot._ The duration increases by 1 hour for each spell slot level above 3.

#### Magic Jar

_Level 6 Necromancy (Wizard)_

**Casting Time:** 1 minute
**Range:** Self
**Components:** V, S, M (a gem, crystal, or reliquary worth 500+ GP)
**Duration:** Until dispelled

Your body falls into a catatonic state as your soul leaves it and enters the container you used for the spell's Material component. While your soul inhabits the container, you are aware of your surroundings as if you were in the container's space. You can't move or take Reactions. The only action you can take is to project your soul up to 100 feet out of the container, either returning to your living body (and ending the spell) or attempting to possess a Humanoid's body.

You can attempt to possess any Humanoid within 100 feet of you that you can see (creatures warded by a _Protection from Evil and Good_ or _Magic Circle_ spell can't be possessed). The target makes a Charisma saving throw. On a failed save, your soul enters the target's body, and the target's soul becomes trapped in the container. On a successful save, the target resists your efforts to possess it, and you can't attempt to possess it again for 24 hours.

Once you possess a creature's body, you control it. Your Hit Points, Hit Point Dice, Strength, Dexterity, Constitution, Speed, and senses are replaced by the creature's. You otherwise keep your game statistics.

Meanwhile, the possessed creature's soul can perceive from the container using its own senses, but it can't move and it is Incapacitated.

While possessing a body, you can take a Magic action to return from the host body to the container if it is within 100 feet of you, returning the host creature's soul to its body. If the host body dies while you're in it, the creature dies, and you make a Charisma saving throw against your own spellcasting DC. On a success, you return to the container if it is within 100 feet of you. Otherwise, you die.

If the container is destroyed or the spell ends, your soul returns to your body. If your body is more than 100 feet away from you or if your body is dead, you die. If another creature's soul is in the container when it is destroyed, the creature's soul returns to its body if the body is alive and within 100 feet. Otherwise, that creature dies.

When the spell ends, the container is destroyed.

#### Magic Missile

_Level 1 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You create three glowing darts of magical force. Each dart strikes a creature of your choice that you can see within range. A dart deals 1d4 + 1 Force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several.

_Using a Higher-Level Spell Slot._ The spell creates one more dart for each spell slot level above 1.

#### Magic Mouth

_Level 2 Illusion (Bard, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** 30 feet
**Components:** V, S, M (jade dust worth 10+ GP, which the spell consumes)
**Duration:** Until dispelled

You implant a message within an object in range—a message that is uttered when a trigger condition is met. Choose an object that you can see and that isn't being worn or carried by another creature. Then speak the message, which must be 25 words or fewer, though it can be delivered over as long as 10 minutes. Finally, determine the circumstance that will trigger the spell to deliver your message.

When that trigger occurs, a magical mouth appears on the object and recites the message in your voice and at the same volume you spoke. If the object you chose has a mouth or something that looks like a mouth (for example, the mouth of a statue), the magical mouth appears there, so the words appear to come from the object's mouth. When you cast this spell, you can have the spell end after it delivers its message, or it can remain and repeat its message whenever the trigger occurs.

The trigger can be as general or as detailed as you like, though it must be based on visual or audible conditions that occur within 30 feet of the object. For example, you could instruct the mouth to speak when any creature moves within 30 feet of the object or when a silver bell rings within 30 feet of it.

#### Magic Weapon

_Level 2 Transmutation (Paladin, Ranger, Sorcerer, Wizard)_

**Casting Time:** Bonus Action
**Range:** Touch
**Components:** V, S
**Duration:** 1 hour

You touch a nonmagical weapon. Until the spell ends, that weapon becomes a magic weapon with a +1 bonus to attack rolls and damage rolls. The spell ends early if you cast it again.

_Using a Higher-Level Spell Slot._ The bonus increases to +2 with a level 3–5 spell slot. The bonus increases to +3 with a level 6+ spell slot.

#### Magnificent Mansion

_Level 7 Conjuration (Bard, Wizard)_

**Casting Time:** 1 minute
**Range:** 300 feet
**Components:** V, S, M (a miniature door worth 15+ GP)
**Duration:** 24 hours

You conjure a shimmering door in range that lasts for the duration. The door leads to an extradimensional dwelling and is 5 feet wide and 10 feet tall. You and any creature you designate when you cast the spell can enter the extradimensional dwelling as long as the door remains open. You can open or close it (no action required) if you are within 30 feet of it. While closed, the door is imperceptible.

Beyond the door is a magnificent foyer with numerous chambers beyond. The dwelling's atmosphere is clean, fresh, and warm.

You can create any floor plan you like for the dwelling, but it can't exceed 50 contiguous 10-foot Cubes. The place is furnished and decorated as you choose. It contains sufficient food to serve a nine-course banquet for up to 100 people. Furnishings and other objects created by this spell dissipate into smoke if removed from it.

A staff of 100 near-transparent servants attends all who enter. You determine the appearance of these servants and their attire. They are invulnerable and obey your commands. Each servant can perform tasks that a human could perform, but they can't attack or take any action that would directly harm another creature. Thus the servants can fetch things, clean, mend, fold clothes, light fires, serve food, pour wine, and so on. The servants can't leave the dwelling.

When the spell ends, any creatures or objects left inside the extradimensional space are expelled into the unoccupied spaces nearest to the entrance.

#### Major Image

_Level 3 Illusion (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a bit of fleece)
**Duration:** Concentration, up to 10 minutes

You create the image of an object, a creature, or some other visible phenomenon that is no larger than a 20-foot Cube. The image appears at a spot that you can see within range and lasts for the duration. It seems real, including sounds, smells, and temperature appropriate to the thing depicted, but it can't deal damage or cause conditions.

If you are within range of the illusion, you can take a Magic action to cause the image to move to any other spot within range. As the image changes location, you can alter its appearance so that its movements appear natural for the image. For example, if you create an image of a creature and move it, you can alter the image so that it appears to be walking. Similarly, you can cause the illusion to make different sounds at different times, even making it carry on a conversation, for example.

Physical interaction with the image reveals it to be an illusion, for things can pass through it. A creature that takes a Study action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and its other sensory qualities become faint to the creature.

_Using a Higher-Level Spell Slot._ The spell lasts until dispelled, without requiring Concentration, if cast with a level 4+ spell slot.

#### Mass Cure Wounds

_Level 5 Abjuration (Bard, Cleric, Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

A wave of healing energy washes out from a point you can see within range. Choose up to six creatures in a 30-foot-radius Sphere centered on that point. Each target regains Hit Points equal to 5d8 plus your spellcasting ability modifier.

_Using a Higher-Level Spell Slot._ The healing increases by 1d8 for each spell slot level above 5.

#### Mass Heal

_Level 9 Abjuration (Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

A flood of healing energy flows from you into creatures around you. You restore up to 700 Hit Points, divided as you choose among any number of creatures that you can see within range. Creatures healed by this spell also have the Blinded, Deafened, and Poisoned conditions removed from them.

#### Mass Healing Word

_Level 3 Abjuration (Bard, Cleric)_

**Casting Time:** Bonus Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

Up to six creatures of your choice that you can see within range regain Hit Points equal to 2d4 plus your spellcasting ability modifier.

_Using a Higher-Level Spell Slot._ The healing increases by 1d4 for each spell slot level above 3.

#### Mass Suggestion

_Level 6 Enchantment (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, M (a snake's tongue)
**Duration:** 24 hours

You suggest a course of activity—described in no more than 25 words—to twelve or fewer creatures you can see within range that can hear and understand you. The suggestion must sound achievable and not involve anything that would obviously deal damage to any of the targets or their allies. For example, you could say, "Walk to the village down that road, and help the villagers there harvest crops until sunset." Or you could say, "Now is not the time for violence. Drop your weapons, and dance! Stop in an hour."

Each target must succeed on a Wisdom saving throw or have the Charmed condition for the duration or until you or your allies deal damage to the target. Each Charmed target pursues the suggestion to the best of its ability. The suggested activity can continue for the entire duration, but if the suggested activity can be completed in a shorter time, the spell ends for a target upon completing it.

_Using a Higher-Level Spell Slot._ The duration is longer with a spell slot of level 7 (10 days), 8 (30 days), or 9 (366 days).

#### Maze

_Level 8 Conjuration (Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You banish a creature that you can see within range into a labyrinthine demiplane. The target remains there for the duration or until it escapes the maze.

The target can take a Study action to try to escape. When it does so, it makes a DC 20 Intelligence (Investigation) check. If it succeeds, it escapes, and the spell ends.

When the spell ends, the target reappears in the space it left or, if that space is occupied, in the nearest unoccupied space.

#### Meld into Stone

_Level 3 Transmutation (Cleric, Druid, Ranger)_

**Casting Time:** Action or Ritual
**Range:** Touch
**Components:** V, S
**Duration:** 8 hours

You step into a stone object or surface large enough to fully contain your body, merging yourself and your equipment with the stone for the duration. You must touch the stone to do so. Nothing of your presence remains visible or otherwise detectable by nonmagical senses.

While merged with the stone, you can't see what occurs outside it, and any Wisdom (Perception) checks you make to hear sounds outside it are made with Disadvantage. You remain aware of the passage of time and can cast spells on yourself while merged in the stone. You can use 5 feet of movement to leave the stone where you entered it, which ends the spell. You otherwise can't move.

Minor physical damage to the stone doesn't harm you, but its partial destruction or a change in its shape (to the extent that you no longer fit within it) expels you and deals 6d6 Force damage to you. The stone's complete destruction (or transmutation into a different substance) expels you and deals 50 Force damage to you. If expelled, you move into an unoccupied space closest to where you first entered and have the Prone condition.

#### Mending

_Transmutation Cantrip (Bard, Cleric, Druid, Sorcerer, Wizard)_

**Casting Time:** 1 minute
**Range:** Touch
**Components:** V, S, M (two lodestones)
**Duration:** Instantaneous

This spell repairs a single break or tear in an object you touch, such as a broken chain link, two halves of a broken key, a torn cloak, or a leaking wineskin. As long as the break or tear is no larger than 1 foot in any dimension, you mend it, leaving no trace of the former damage.

This spell can physically repair a magic item, but it can't restore magic to such an object.

#### Message

_Transmutation Cantrip (Bard, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** S, M (a copper wire)
**Duration:** 1 round
You point toward a creature within range and whisper a message. The target (and only the target) hears the message and can reply in a whisper that only you can hear.

You can cast this spell through solid objects if you are familiar with the target and know it is beyond the barrier. Magical silence; 1 foot of stone, metal, or wood; or a thin sheet of lead blocks the spell.

#### Meteor Swarm

_Level 9 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 1 mile
**Components:** V, S
**Duration:** Instantaneous

Blazing orbs of fire plummet to the ground at four different points you can see within range. Each creature in a 40-foot-radius Sphere centered on each of those points makes a Dexterity saving throw. A creature takes 20d6 Fire damage and 20d6 Bludgeoning damage on a failed save or half as much damage on a successful one. A creature in the area of more than one fiery Sphere is affected only once.

A nonmagical object that isn't being worn or carried also takes the damage if it's in the spell's area, and the object starts burning if it's flammable.

#### Mind Blank

_Level 8 Abjuration (Bard, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** 24 hours

Until the spell ends, one willing creature you touch has Immunity to Psychic damage and the Charmed condition. The target is also unaffected by anything that would sense its emotions or alignment, read its thoughts, or magically detect its location, and no spell—not even _Wish_—can gather information about the target, observe it remotely, or control its mind.

#### Mind Spike

_Level 2 Divination (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** S
**Duration:** Concentration, up to 1 hour

You drive a spike of psionic energy into the mind of one creature you can see within range. The target makes a Wisdom saving throw, taking 3d8 Psychic damage on a failed save or half as much damage on a successful one. On a failed save, you also always know the target's location until the spell ends, but only while the two of you are on the same plane

of existence. While you have this knowledge, the target can't become hidden from you, and if it has the Invisible condition, it gains no benefit from that condition against you.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 2.

#### Minor Illusion

_Illusion Cantrip (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** S, M (a bit of fleece)
**Duration:** 1 minute

You create a sound or an image of an object within range that lasts for the duration. See the descriptions below for the effects of each. The illusion ends if you cast this spell again.

If a creature takes a Study action to examine the sound or image, the creature can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the illusion becomes faint to the creature.

_Sound._ If you create a sound, its volume can range from a whisper to a scream. It can be your voice, someone else's voice, a lion's roar, a beating of drums, or any other sound you choose. The sound continues unabated throughout the duration, or you can make discrete sounds at different times before the spell ends.

_Image._ If you create an image of an object—such as a chair, muddy footprints, or a small chest—it must be no larger than a 5-foot Cube. The image can't create sound, light, smell, or any other sensory effect. Physical interaction with the image reveals it to be an illusion, since things can pass through it.

#### Mirage Arcane

_Level 7 Illusion (Bard, Druid, Wizard)_

**Casting Time:** 10 minutes
**Range:** Sight
**Components:** V, S
**Duration:** 10 days

You make terrain in an area up to 1 mile square look, sound, smell, and even feel like some other sort of terrain. Open fields or a road could be made to resemble a swamp, hill, crevasse, or some other rough or impassable terrain. A pond can be made to seem like a grassy meadow, a precipice like a gentle slope, or a rock-strewn gully like a wide and smooth road.

Similarly, you can alter the appearance of structures or add them where none are present. The spell doesn't disguise, conceal, or add creatures.

The illusion includes audible, visual, tactile, and olfactory elements, so it can turn clear ground
into Difficult Terrain (or vice versa) or otherwise impede movement through the area. Any piece of the illusory terrain (such as a rock or stick) that is removed from the spell's area disappears immediately.

Creatures with Truesight can see through the illusion to the terrain's true form; however, all other elements of the illusion remain, so while the creature is aware of the illusion's presence, the creature can still physically interact with the illusion.

#### Mirror Image

_Level 2 Illusion (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** 1 minute

Three illusory duplicates of yourself appear in your space. Until the spell ends, the duplicates move with you and mimic your actions, shifting position so it's impossible to track which image is real.

Each time a creature hits you with an attack roll during the spell's duration, roll a d6 for each of your remaining duplicates. If any of the d6s rolls a 3 or higher, one of the duplicates is hit instead of you, and the duplicate is destroyed. The duplicates otherwise ignore all other damage and effects. The spell ends when all three duplicates are destroyed.

A creature is unaffected by this spell if it has the Blinded condition, Blindsight, or Truesight.

#### Mislead

_Level 5 Illusion (Bard, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** S
**Duration:** Concentration, up to 1 hour

You gain the Invisible condition at the same time that an illusory double of you appears where you are standing. The double lasts for the duration, but the invisibility ends immediately after you make an attack roll, deal damage, or cast a spell.

As a Magic action, you can move the illusory double up to twice your Speed and make it gesture, speak, and behave in whatever way you choose. It is intangible and invulnerable.

You can see through its eyes and hear through its ears as if you were located where it is.

#### Misty Step

_Level 2 Conjuration (Sorcerer, Warlock, Wizard)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V
**Duration:** Instantaneous

Briefly surrounded by silvery mist, you teleport up to 30 feet to an unoccupied space you can see.

#### Modify Memory

_Level 5 Enchantment (Bard, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You attempt to reshape another creature's memories. One creature that you can see within range makes a Wisdom saving throw. If you are fighting the creature, it has Advantage on the save. On a failed save, the target has the Charmed condition for the duration. While Charmed in this way, the target also has the Incapacitated condition and is unaware of its surroundings, though it can hear you. If it takes any damage or is targeted by another spell, this spell ends, and no memories are modified.

While this charm lasts, you can affect the target's memory of an event that it experienced within the last 24 hours and that lasted no more than 10 minutes. You can permanently eliminate all memory of the event, allow the target to recall the event with perfect clarity, change its memory of the event's details, or create a memory of some other event.

You must speak to the target to describe how its memories are affected, and it must be able to understand your language for the modified memories to take root. Its mind fills in any gaps in the details of your description. If the spell ends before you finish describing the modified memories, the creature's memory isn't altered. Otherwise, the modified memories take hold when the spell ends.

A modified memory doesn't necessarily affect how a creature behaves, particularly if the memory contradicts the creature's natural inclinations, alignment, or beliefs. An illogical modified memory, such as a false memory of how much the creature enjoyed swimming in acid, is dismissed as a bad dream. The GM might deem a modified memory too nonsensical to affect a creature.

A _Remove Curse_ or _Greater Restoration_ spell cast on the target restores the creature's true memory.

_Using a Higher-Level Spell Slot._ You can alter the target's memories of an event that took place up to 7 days ago (level 6 spell slot), 30 days ago (level 7 spell slot), 365 days ago (level 8 spell slot), or any time in the creature's past (level 9 spell slot).

#### Moonbeam

_Level 2 Evocation (Druid)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a moonseed leaf)
**Duration:** Concentration, up to 1 minute
A silvery beam of pale light shines down in a 5-foot-radius, 40-foot-high Cylinder centered on a point within range. Until the spell ends, Dim Light fills the Cylinder, and you can take a Magic action on later turns to move the Cylinder up to 60 feet.

When the Cylinder appears, each creature in it makes a Constitution saving throw. On a failed save, a creature takes 2d10 Radiant damage, and if the creature is shape-shifted (as a result of the _Polymorph_ spell, for example), it reverts to its true form and can't shape-shift until it leaves the Cylinder. On a successful save, a creature takes half as much damage only. A creature also makes this save when the spell's area moves into its space and when it enters the spell's area or ends its turn there. A creature makes this save only once per turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 2.

#### Move Earth

_Level 6 Transmutation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a miniature shovel)
**Duration:** Concentration, up to 2 hours

Choose an area of terrain no larger than 40 feet on a side within range. You can reshape dirt, sand, or clay in the area in any manner you choose for the duration. You can raise or lower the area's elevation, create or fill in a trench, erect or flatten a wall, or form a pillar. The extent of any such changes can't exceed half the area's largest dimension. For example, if you affect a 40-foot square, you can create a pillar up to 20 feet high, raise or lower the square's elevation by up to 20 feet, dig a trench up to 20 feet deep, and so on. It takes 10 minutes for these changes to complete. Because the terrain's transformation occurs slowly, creatures in the area can't usually be trapped or injured by the ground's movement.

At the end of every 10 minutes you spend concentrating on the spell, you can choose a new area of terrain to affect within range.

This spell can't manipulate natural stone or stone construction. Rocks and structures shift to accommodate the new terrain. If the way you shape the terrain would make a structure unstable, it might collapse.

Similarly, this spell doesn't directly affect plant growth. The moved earth carries any plants along with it.

#### Nondetection

_Level 3 Abjuration (Bard, Ranger, Wizard)_

**Casting Time:** Action
**Range:** Touch

**Components:** V, S, M (a pinch of diamond dust worth 25+ GP, which the spell consumes)
**Duration:** 8 hours

For the duration, you hide a target that you touch from Divination spells. The target can be a willing creature, or it can be a place or an object no larger than 10 feet in any dimension. The target can't be targeted by any Divination spell or perceived through magical scrying sensors.

#### Passwall

_Level 5 Transmutation (Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a pinch of sesame seeds)
**Duration:** 1 hour

A passage appears at a point that you can see on a wooden, plaster, or stone surface (such as a wall, ceiling, or floor) within range and lasts for the duration. You choose the opening's dimensions: up to 5 feet wide, 8 feet tall, and 20 feet deep. The passage creates no instability in a structure surrounding it.

When the opening disappears, any creatures or objects still in the passage created by the spell are safely ejected to an unoccupied space nearest to the surface on which you cast the spell.

#### Pass without Trace

_Level 2 Abjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (ashes from burned mistletoe)
**Duration:** Concentration, up to 1 hour

You radiate a concealing aura in a 30-foot Emanation for the duration. While in the aura, you and each creature you choose have a +10 bonus to Dexterity (Stealth) checks and leave no tracks.

#### Phantasmal Force

_Level 2 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a bit of fleece)
**Duration:** Concentration, up to 1 minute

You attempt to craft an illusion in the mind of a creature you can see within range. The target makes an Intelligence saving throw. On a failed save, you create a phantasmal object, creature, or other phenomenon that is no larger than a 10-foot Cube and that is perceivable only to the target for the duration. The phantasm includes sound, temperature, and other stimuli.

The target can take a Study action to examine the phantasm with an Intelligence (Investigation) check against your spell save DC. If the check succeeds, the target realizes that the phantasm is an illusion, and the spell ends.

While affected by the spell, the target treats the phantasm as if it were real and rationalizes any illogical outcomes from interacting with it. For example, if the target steps through a phantasmal bridge and survives the fall, it believes the bridge exists and something else caused it to fall.

An affected target can even take damage from the illusion if the phantasm represents a dangerous creature or hazard. On each of your turns, such a phantasm can deal 2d8 Psychic damage to the target if it is in the phantasm's area or within 5 feet of the phantasm. The target perceives the damage as a type appropriate to the illusion.

#### Phantasmal Killer

_Level 4 Illusion (Bard, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You tap into the nightmares of a creature you can see within range and create an illusion of its deepest fears, visible only to that creature. The target makes a Wisdom saving throw. On a failed save, the target takes 4d10 Psychic damage and has Disadvantage on ability checks and attack rolls for the duration. On a successful save, the target takes half as much damage, and the spell ends.

For the duration, the target makes a Wisdom saving throw at the end of each of its turns. On a failed save, it takes the Psychic damage again. On a successful save, the spell ends.

_Using a Higher-Level Spell Slot._ The damage increases by 1d10 for each spell slot level above 4.

#### Phantom Steed

_Level 3 Illusion (Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** 30 feet
**Components:** V, S
**Duration:** 1 hour

A Large, quasi-real, horselike creature appears on the ground in an unoccupied space of your choice within range. You decide the creature's appearance, and it is equipped with a saddle, bit, and bridle. Any of the equipment created by the spell vanishes in a puff of smoke if it is carried more than 10 feet away from the steed.

For the duration, you or a creature you choose can ride the steed. The steed uses the Riding Horse stat block (see "Monsters"), except it has a Speed of 100 feet and can travel 13 miles in an hour. When the spell ends, the steed gradually fades, giving the rider 1 minute to dismount. The spell ends early if the steed takes any damage.

#### Planar Ally

_Level 6 Conjuration (Cleric)_

**Casting Time:** 10 minutes
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You beseech an otherworldly entity for aid. The being must be known to you: a god, a demon prince, or some other being of cosmic power. That entity sends a Celestial, an Elemental, or a Fiend loyal to it to aid you, making the creature appear in an unoccupied space within range. If you know a specific creature's name, you can speak that name when you cast this spell to request that creature, though you might get a different creature anyway (GM's choice).

When the creature appears, it is under no compulsion to behave a particular way. You can ask it to perform a service in exchange for payment, but it isn't obliged to do so. The requested task could range from simple (fly us across the chasm, or help us fight a battle) to complex (spy on our enemies, or protect us during our foray into the dungeon). You must be able to communicate with the creature to bargain for its services.

Payment can take a variety of forms. A Celestial might require a sizable donation of gold or magic items to an allied temple, while a Fiend might demand a living sacrifice or a gift of treasure. Some creatures might exchange their service for a quest undertaken by you.

A task that can be measured in minutes requires a payment worth 100 GP per minute. A task measured in hours requires 1,000 GP per hour. And a task measured in days (up to 10 days) requires 10,000 GP per day. The GM can adjust these payments based on the circumstances under which you cast the spell. If the task is aligned with the creature's ethos, the payment might be halved or even waived. Nonhazardous tasks typically require only half the suggested payment, while especially dangerous tasks might require a greater gift. Creatures rarely accept tasks that seem suicidal.

After the creature completes the task, or when the agreed-upon duration of service expires, the creature returns to its home plane after reporting back to you if possible. If you are unable to agree on a price for the creature's service, the creature immediately returns to its home plane.

#### Planar Binding

_Level 5 Abjuration (Bard, Cleric, Druid, Warlock, Wizard)_

**Casting Time:** 1 hour
**Range:** 60 feet
**Components:** V, S, M (a jewel worth 1,000+ GP, which the spell consumes)
**Duration:** 24 hours
You attempt to bind a Celestial, an Elemental, a Fey, or a Fiend to your service. The creature must be within range for the entire casting of the spell. (Typically, the creature is first summoned into the center of the inverted version of the _Magic Circle_ spell to trap it while this spell is cast.) At the completion of the casting, the target must succeed on a Charisma saving throw or be bound to serve you for the duration. If the creature was summoned or created by another spell, that spell's duration is extended to match the duration of this spell.

A bound creature must follow your commands to the best of its ability. You might command the creature to accompany you on an adventure, to guard a location, or to deliver a message. If the creature is Hostile, it strives to twist your commands to achieve its own objectives. If the creature carries out your commands completely before the spell ends, it travels to you to report this fact if you are on the same plane of existence. If you are on a different plane, it returns to the place where you bound it and remains there until the spell ends.

_Using a Higher-Level Spell Slot._ The duration increases with a spell slot of level 6 (10 days), 7 (30 days), 8 (180 days), and 9 (366 days).

#### Plane Shift

_Level 7 Conjuration (Cleric, Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a forked, metal rod worth 250+ GP and attuned to a plane of existence)
**Duration:** Instantaneous

You and up to eight willing creatures who link hands in a circle are transported to a different plane of existence. You can specify a target destination in general terms, such as a specific city on the Elemental Plane of Fire or palace on the second level of the Nine Hells, and you appear in or near that destination, as determined by the GM.

Alternatively, if you know the sigil sequence of a teleportation circle on another plane of existence, this spell can take you to that circle. If the teleportation circle is too small to hold all the creatures you transported, they appear in the closest unoccupied spaces next to the circle.

#### Plant Growth

_Level 3 Transmutation (Bard, Druid, Ranger)_

**Casting Time:** Action (Overgrowth) or 8 hours (Enrichment)
**Range:** 150 feet
**Components:** V, S
**Duration:** Instantaneous

This spell channels vitality into plants. The casting time you use determines whether the spell has the Overgrowth or the Enrichment effect below.

_Overgrowth._ Choose a point within range. All normal plants in a 100-foot-radius Sphere centered on that point become thick and overgrown. A creature moving through that area must spend 4 feet of movement for every 1 foot it moves. You can exclude one or more areas of any size within the spell's area from being affected.

_Enrichment._ All plants in a half-mile radius centered on a point within range become enriched for 365 days. The plants yield twice the normal amount of food when harvested. They can benefit from only one _Plant Growth_ per year.

#### Poison Spray

_Necromancy Cantrip (Druid, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** Instantaneous

You spray toxic mist at a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d12 Poison damage.

_Cantrip Upgrade._ The damage increases by 1d12 when you reach levels 5 (2d12), 11 (3d12), and 17 (4d12).

#### Polymorph

_Level 4 Transmutation (Bard, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a caterpillar cocoon)
**Duration:** Concentration, up to 1 hour

You attempt to transform a creature that you can see within range into a Beast. The target must succeed on a Wisdom saving throw or shape-shift into a Beast form for the duration. That form can be any Beast you choose that has a Challenge Rating equal to or less than the target's (or the target's level if it doesn't have a Challenge Rating). The target's game statistics are replaced by the stat block of the chosen Beast, but the target retains its alignment, personality, creature type, Hit Points, and Hit Point Dice. See the "Animals" section of "Monsters" for a sample of Beast stat blocks.

The target gains a number of Temporary Hit Points equal to the Hit Points of the Beast form. These Temporary Hit Points vanish if any remain when the spell ends. The spell ends early on the target if it has no Temporary Hit Points left.

The target is limited in the actions it can perform by the anatomy of its new form, and it can't speak or cast spells.
The target's gear melds into the new form. The creature can't use or otherwise benefit from any of that equipment.

#### Power Word Heal

_Level 9 Enchantment (Bard, Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Component:** V
**Duration:** Instantaneous

A wave of healing energy washes over one creature you can see within range. The target regains all its Hit Points. If the creature has the Charmed, Frightened, Paralyzed, Poisoned, or Stunned condition, the condition ends. If the creature has the Prone condition, it can use its Reaction to stand up.

#### Power Word Kill

_Level 9 Enchantment (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Component:** V
**Duration:** Instantaneous

You compel one creature you can see within range to die. If the target has 100 Hit Points or fewer, it dies. Otherwise, it takes 12d12 Psychic damage.

#### Power Word Stun

_Level 8 Enchantment (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

You overwhelm the mind of one creature you can see within range. If the target has 150 Hit Points or fewer, it has the Stunned condition. Otherwise, its Speed is 0 until the start of your next turn.

The Stunned target makes a Constitution saving throw at the end of each of its turns, ending the condition on itself on a success.

#### Prayer of Healing

_Level 2 Abjuration (Cleric, Paladin)_

**Casting Time:** 10 minutes
**Range:** 30 feet
**Components:** V
**Duration:** Instantaneous

Up to five creatures of your choice who remain within range for the spell's entire casting gain the benefits of a Short Rest and also regain 2d8 Hit Points. A creature can't be affected by this spell again until that creature finishes a Long Rest.

_Using a Higher-Level Spell Slot._ The healing increases by 1d8 for each spell slot level above 2.

#### Prestidigitation

_Transmutation Cantrip (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 10 feet
**Components:** V, S
**Duration:** Up to 1 hour

You create a magical effect within range. Choose the effect from the options below. If you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time.

_Sensory Effect._ You create an instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.

_Fire Play._ You instantaneously light or snuff out a candle, a torch, or a small campfire.

_Clean or Soil._ You instantaneously clean or soil an object no larger than 1 cubic foot.

_Minor Sensation._ You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.

_Magic Mark._ You make a color, a small mark, or a symbol appear on an object or a surface for 1 hour.

_Minor Creation._ You create a nonmagical trinket or an illusory image that can fit in your hand. It lasts until the end of your next turn. A trinket can deal no damage and has no monetary worth.

#### Prismatic Spray

_Level 7 Evocation (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Instantaneous

Eight rays of light flash from you in a 60-foot Cone. Each creature in the Cone makes a Dexterity saving throw. For each target, roll 1d8 to determine which color ray affects it, consulting the Prismatic Rays table.

**Prismatic Rays**

<table>
  <thead>
    <tr>
      <th>1d8</th>
      <th>Ray</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>**Red.** *Failed Save:* 12d6 Fire damage. *Successful Save:* Half as much damage.</td>
    </tr>
    <tr>
      <td>2</td>
      <td>**Orange.** *Failed Save:* 12d6 Acid damage. *Successful Save:* Half as much damage.</td>
    </tr>
    <tr>
      <td>3</td>
      <td>**Yellow.** *Failed Save:* 12d6 Lightning damage. *Successful Save:* Half as much damage.</td>
    </tr>
    <tr>
      <td>4</td>
      <td>**Green.** *Failed Save:* 12d6 Poison damage. *Successful Save:* Half as much damage.</td>
    </tr>
    <tr>
      <td>5</td>
      <td>**Blue.** *Failed Save:* 12d6 Cold damage. *Successful Save:* Half as much damage.</td>
    </tr>
    <tr>
      <td>6</td>
      <td>**Indigo.** *Failed Save:* The target has the Restrained condition and makes a Constitution saving throw at the end of each of its turns. If it successfully saves three times, the condition ends. If it fails three times, it has the Petrified condition until it is freed by an effect like the *Greater Restoration* spell. The successes and failures needn't be consecutive; keep track of both until the target collects three of a kind.</td>
    </tr>
    <tr>
      <td>7</td>
      <td>**Violet.** *Failed Save:* The target has the Blinded condition and makes a Wisdom saving throw at the start of your next turn. On a successful save, the condition ends. On a failed save, the condition ends, and the creature teleports to another plane of existence (GM's choice).</td>
    </tr>
    <tr>
      <td>8</td>
      <td>**Special.** The target is struck by two rays. Roll twice, rerolling any 8.</td>
    </tr>
  </tbody>
</table>

#### Prismatic Wall

_Level 9 Abjuration (Bard, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** 10 minutes

A shimmering, multicolored plane of light forms a vertical opaque wall—up to 90 feet long, 30 feet high, and 1 inch thick—centered on a point within range. Alternatively, you shape the wall into a globe up to 30 feet in diameter centered on a point within range. The wall lasts for the duration. If you position the wall in a space occupied by a creature, the spell ends instantly without effect.

The wall sheds Bright Light within 100 feet and Dim Light for an additional 100 feet. You and creatures you designate when you cast the spell can pass through and be near the wall without harm. If another creature that can see the wall moves within 20 feet of it or starts its turn there, the creature must succeed on a Constitution saving throw or have the Blinded condition for 1 minute.

The wall consists of seven layers, each with a different color. When a creature reaches into or passes through the wall, it does so one layer at a time through all the layers. Each layer forces the creature to make a Dexterity saving throw or be affected by that layer's properties as described in the Prismatic Layers table.

The wall, which has AC 10, can be destroyed one layer at a time, in order from red to violet, by means specific to each layer. If a layer is destroyed, it is gone for the duration. _Antimagic Field_ has no effect on the wall, and _Dispel Magic_ can affect only the violet layer.

**Prismatic Layers**

<table>
  <thead>
    <tr>
      <th>Order</th>
      <th>Effects</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>**Red.** *Failed Save:* 12d6 Fire damage. *Successful Save:* Half as much damage. *Additional Effects:* Nonmagical ranged attacks can't pass through this layer, which is destroyed if it takes at least 25 Cold damage.</td>
    </tr>
    <tr>
      <td>2</td>
      <td>**Orange.** *Failed Save:* 12d6 Acid damage. *Successful Save:* Half as much damage. *Additional Effects:* Magical ranged attacks can't pass through this layer, which is destroyed by a strong wind (such as the one created by *Gust of Wind*).</td>
    </tr>
    <tr>
      <td>3</td>
      <td>**Yellow.** *Failed Save:* 12d6 Lightning damage. *Successful Save:* Half as much damage. *Additional Effects:* The layer is destroyed if it takes at least 60 Force damage.</td>
    </tr>
    <tr>
      <td>4</td>
      <td>**Green.** *Failed Save:* 12d6 Poison damage. *Successful Save:* Half as much damage. *Additional Effects:* A *Passwall* spell, or another spell of equal or greater level that can open a portal on a solid surface, destroys this layer.</td>
    </tr>
    <tr>
      <td>5</td>
      <td>**Blue.** *Failed Save:* 12d6 Cold damage. *Successful Save:* Half as much damage. *Additional Effects:* The layer is destroyed if it takes at least 25 Fire damage.</td>
    </tr>
    <tr>
      <td>6</td>
      <td>**Indigo.** *Failed Save:* The target has the Restrained condition and makes a Constitution saving throw at the end of each of its turns. If it successfully saves three times, the condition ends. If it fails three times, it has the Petrified condition until it is freed by an effect like the *Greater Restoration* spell. The successes and failures needn't be consecutive; keep track of both until the target collects three of a kind. *Additional Effects:* Spells can't be cast through this layer, which is destroyed by Bright Light shed by the *Daylight* spell.</td>
    </tr>
    <tr>
      <td>7</td>
      <td>**Violet.** *Failed Save:* The target has the Blinded condition and makes a Wisdom saving throw at the start of your next turn. On a successful save, the condition ends. On a failed save, the condition ends, and the creature teleports to another plane of existence (GM's choice). *Additional Effects:* This layer is destroyed by *Dispel Magic*.</td>
    </tr>
  </tbody>
</table>

#### Private Sanctum

_Level 4 Abjuration (Wizard)_

**Casting Time:** 10 minutes
**Range:** 120 feet
**Components:** V, S, M (a thin sheet of lead)
**Duration:** 24 hours

You make an area within range magically secure. The area is a Cube that can be as small as 5 feet to as large as 100 feet on each side. The spell lasts for the duration.

When you cast the spell, you decide what sort of security the spell provides, choosing any of the following properties:

- Sound can't pass through the barrier at the edge of the warded area.
- The barrier of the warded area appears dark and foggy, preventing vision (including Darkvision) through it.
- Sensors created by Divination spells can't appear inside the protected area or pass through the barrier at its perimeter.
- Creatures in the area can't be targeted by Divination spells.
- Nothing can teleport into or out of the warded area.
- Planar travel is blocked within the warded area.

Casting this spell on the same spot every day for 365 days makes the spell last until dispelled.

_Using a Higher-Level Spell Slot._ You can increase the size of the Cube by 100 feet for each spell slot level above 4.

#### Produce Flame

_Conjuration Cantrip (Druid)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V, S
**Duration:** 10 minutes

A flickering flame appears in your hand and remains there for the duration. While there, the flame emits no heat and ignites nothing, and it sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. The spell ends if you cast it again.

Until the spell ends, you can take a Magic action to hurl fire at a creature or an object within 60 feet of you. Make a ranged spell attack. On a hit, the target takes 1d8 Fire damage.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Programmed Illusion

_Level 6 Illusion (Bard, Wizard)_

**Casting Time:** Action
**Range:** 120 feet

**Components:** V, S, M (jade dust worth 25+ GP)
**Duration:** Until dispelled

You create an illusion of an object, a creature, or some other visible phenomenon within range that activates when a specific trigger occurs. The illusion is imperceptible until then. It must be no larger than a 30-foot Cube, and you decide when you cast the spell how the illusion behaves and what sounds it makes. This scripted performance can last up to 5 minutes.

When the trigger you specify occurs, the illusion springs into existence and performs in the manner you described. Once the illusion finishes performing, it disappears and remains dormant for 10 minutes, after which the illusion can be activated again.

The trigger can be as general or as detailed as you like, though it must be based on visual or audible phenomena that occur within 30 feet of the area. For example, you could create an illusion of yourself to appear and warn off others who attempt to open a trapped door.

Physical interaction with the image reveals it to be illusory, since things can pass through it. A creature that takes the Study action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and any noise it makes sounds hollow to the creature.

#### Project Image

_Level 7 Illusion (Bard, Wizard)_

**Casting Time:** Action
**Range:** 500 miles
**Components:** V, S, M (a statuette of yourself worth 5+ GP)
**Duration:** Concentration, up to 1 day

You create an illusory copy of yourself that lasts for the duration. The copy can appear at any location within range that you have seen before, regardless of intervening obstacles. The illusion looks and sounds like you, but it is intangible. If the illusion takes any damage, it disappears, and the spell ends.

You can see through the illusion's eyes and hear through its ears as if you were in its space. As a Magic action, you can move it up to 60 feet and make it gesture, speak, and behave in whatever way you choose. It mimics your mannerisms perfectly.

Physical interaction with the image reveals it to be illusory, since things can pass through it. A creature that takes the Study action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and any noise it makes sounds hollow to the creature.

#### Protection from Energy

_Level 3 Abjuration (Cleric, Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Concentration, up to 1 hour

For the duration, the willing creature you touch has Resistance to one damage type of your choice: Acid, Cold, Fire, Lightning, or Thunder.

#### Protection from Evil and Good

_Level 1 Abjuration (Cleric, Druid, Paladin, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a flask of Holy Water worth 25+ GP, which the spell consumes)
**Duration:** Concentration, up to 10 minutes

Until the spell ends, one willing creature you touch is protected against creatures that are Aberrations, Celestials, Elementals, Fey, Fiends, or Undead.

The protection grants several benefits. Creatures of those types have Disadvantage on attack rolls against the target. The target also can't be possessed by or gain the Charmed or Frightened conditions from them. If the target is already possessed, Charmed, or Frightened by such a creature, the target has Advantage on any new saving throw against the relevant effect.

#### Protection from Poison

_Level 2 Abjuration (Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** 1 hour

You touch a creature and end the Poisoned condition on it. For the duration, the target has Advantage on saving throws to avoid or end the Poisoned condition, and it has Resistance to Poison damage.

#### Purify Food and Drink

_Level 1 Transmutation (Cleric, Druid, Paladin)_

**Casting Time:** Action or Ritual
**Range:** 10 feet
**Components:** V, S
**Duration:** Instantaneous

You remove poison and rot from nonmagical food and drink in a 5-foot-radius Sphere centered on a point within range.

#### Raise Dead

_Level 5 Necromancy (Bard, Cleric, Paladin)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (a diamond worth 500+ GP, which the spell consumes)
**Duration:** Instantaneous

With a touch, you revive a dead creature if it has been dead no longer than 10 days and it wasn't Undead when it died.

The creature returns to life with 1 Hit Point. This spell also neutralizes any poisons that affected the creature at the time of death.

This spell closes all mortal wounds, but it doesn't restore missing body parts. If the creature is lacking body parts or organs integral for its survival—its head, for instance—the spell automatically fails.

Coming back from the dead is an ordeal. The target takes a −4 penalty to D20 Tests. Every time the target finishes a Long Rest, the penalty is reduced by 1 until it becomes 0.

#### Ray of Enfeeblement

_Level 2 Necromancy (Warlock, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

A beam of enervating energy shoots from you toward a creature within range. The target must make a Constitution saving throw. On a successful save, the target has Disadvantage on the next attack roll it makes until the start of your next turn.

On a failed save, the target has Disadvantage on Strength-based D20 Tests for the duration. During that time, it also subtracts 1d8 from all its damage rolls. The target repeats the save at the end of each of its turns, ending the spell on a success.

#### Ray of Frost

_Evocation Cantrip (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

A frigid beam of blue-white light streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, it takes 1d8 Cold damage, and its Speed is reduced by 10 feet until the start of your next turn.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Regenerate

_Level 7 Transmutation (Bard, Cleric, Druid)_

**Casting Time:** 1 minute
**Range:** Touch
**Components:** V, S, M (a prayer wheel)
**Duration:** 1 hour

A creature you touch regains 4d8 + 15 Hit Points. For the duration, the target regains 1 Hit Point at the start of each of its turns, and any severed body parts regrow after 2 minutes.

#### Ray of Sickness

_Level 1 Necromancy (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You shoot a greenish ray at a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 Poison damage and has the Poisoned condition until the end of your next turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 1.

#### Reincarnate

_Level 5 Necromancy (Druid)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (rare oils worth 1,000+ GP, which the spell consumes)
**Duration:** Instantaneous

You touch a dead Humanoid or a piece of one. If the creature has been dead no longer than 10 days, the spell forms a new body for it and calls the soul to enter that body. Roll 1d10 and consult the table below to determine the body's species, or the GM chooses another playable species.

<table>
  <thead>
    <tr>
      <th>1d10</th>
      <th>Species</th>
      <th>1d10</th>
      <th>Species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Roll again.</td>
      <td>6</td>
      <td>Goliath</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Dragonborn</td>
      <td>7</td>
      <td>Halfling</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Dwarf</td>
      <td>8</td>
      <td>Human</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Elf</td>
      <td>9</td>
      <td>Orc</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Gnome</td>
      <td>10</td>
      <td>Tiefling</td>
    </tr>
  </tbody>
</table>

The reincarnated creature makes any choices that a species' description offers, and the creature recalls its former life. It retains the capabilities it had in its original form, except it loses the traits of its previous species and gains the traits of its new one.

#### Remove Curse

_Level 3 Abjuration (Cleric, Paladin, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch

**Components:** V, S
**Duration:** Instantaneous

At your touch, all curses affecting one creature or object end. If the object is a cursed magic item, its curse remains, but the spell breaks its owner's Attunement to the object so it can be removed or discarded.

#### Resilient Sphere

_Level 4 Abjuration (Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a glass sphere)
**Duration:** Concentration, up to 1 minute

A shimmering sphere encloses a Large or smaller creature or object within range. An unwilling creature must succeed on a Dexterity saving throw or be enclosed for the duration.

Nothing—not physical objects, energy, or other spell effects—can pass through the barrier, in or out, though a creature in the sphere can breathe there. The sphere is immune to all damage, and a creature or object inside can't be damaged by attacks or effects originating from outside, nor can a creature inside the sphere damage anything outside it.

The sphere is weightless and just large enough to contain the creature or object inside. An enclosed creature can take an action to push against the sphere's walls and thus roll the sphere at up to half the creature's Speed. Similarly, the globe can be picked up and moved by other creatures.

A _Disintegrate_ spell targeting the globe destroys it without harming anything inside.

#### Resistance

_Abjuration Cantrip (Cleric, Druid)_

**Casting Time:** Action
**Range:** Touch
**Component:** V, S
**Duration:** Concentration, up to 1 minute

You touch a willing creature and choose a damage type: Acid, Bludgeoning, Cold, Fire, Lightning, Necrotic, Piercing, Poison, Radiant, Slashing, or Thunder. When the creature takes damage of the chosen type before the spell ends, the creature reduces the total damage taken by 1d4. A creature can benefit from this spell only once per turn.

#### Resurrection

_Level 7 Necromancy (Bard, Cleric)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (a diamond worth 1,000+ GP, which the spell consumes)
**Duration:** Instantaneous
With a touch, you revive a dead creature that has been dead for no more than a century, didn't die of old age, and wasn't Undead when it died.

The creature returns to life with all its Hit Points. This spell also neutralizes any poisons that affected the creature at the time of death. This spell closes all mortal wounds and restores any missing body parts.

Coming back from the dead is an ordeal. The target takes a −4 penalty to D20 Tests. Every time the target finishes a Long Rest, the penalty is reduced by 1 until it becomes 0.

Casting this spell to revive a creature that has been dead for 365 days or longer taxes you. Until you finish a Long Rest, you can't cast spells again, and you have Disadvantage on D20 Tests.

#### Reverse Gravity

_Level 7 Transmutation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 100 feet
**Components:** V, S, M (a lodestone and iron filings)
**Duration:** Concentration, up to 1 minute

This spell reverses gravity in a 50-foot-radius, 100-foot high Cylinder centered on a point within range. All creatures and objects in that area that aren't anchored to the ground fall upward and reach the top of the Cylinder. A creature can make a Dexterity saving throw to grab a fixed object it can reach, thus avoiding the fall upward.

If a ceiling or an anchored object is encountered in this upward fall, creatures and objects strike it just as they would during a downward fall. If an affected creature or object reaches the Cylinder's top without striking anything, it hovers there for the duration. When the spell ends, affected objects and creatures fall downward.

#### Revivify

_Level 3 Necromancy (Cleric, Druid, Paladin, Ranger)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a diamond worth 300+ GP, which the spell consumes)
**Duration:** Instantaneous

You touch a creature that has died within the last minute. That creature revives with 1 Hit Point. This spell can't revive a creature that has died of old age, nor does it restore any missing body parts.

#### Rope Trick

_Level 2 Transmutation (Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a segment of rope)
**Duration:** 1 hour

You touch a rope. One end of it hovers upward until the rope hangs perpendicular to the ground or the rope reaches a ceiling. At the rope's upper end, an Invisible 3-foot-by-5-foot portal opens to an extradimensional space that lasts until the spell ends. That space can be reached by climbing the rope, which can be pulled into or dropped out of it.

The space can hold up to eight Medium or smaller creatures. Attacks, spells, and other effects can't pass into or out of the space, but creatures inside it can see through the portal. Anything inside the space drops out when the spell ends.

#### Sacred Flame

_Evocation Cantrip (Cleric)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

Flame-like radiance descends on a creature that you can see within range. The target must succeed on a Dexterity saving throw or take 1d8 Radiant damage. The target gains no benefit from Half Cover or Three-Quarters Cover for this save.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Sanctuary

_Level 1 Abjuration (Cleric)_

**Casting Time:** Bonus Action
**Range:** 30 feet
**Components:** V, S, M (a shard of glass from a mirror)
**Duration:** 1 minute

You ward a creature within range. Until the spell ends, any creature who targets the warded creature with an attack roll or a damaging spell must succeed on a Wisdom saving throw or either choose a new target or lose the attack or spell. This spell doesn't protect the warded creature from areas of effect. The spell ends if the warded creature makes an attack roll, casts a spell, or deals damage.

#### Scorching Ray

_Level 2 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You hurl three fiery rays. You can hurl them at one target within range or at several. Make a ranged spell attack for each ray. On a hit, the target takes 2d6 Fire damage.

_Using a Higher-Level Spell Slot._ You create one additional ray for each spell slot level above 2.

#### Scrying

_Level 5 Divination (Bard, Cleric, Druid, Warlock, Wizard)_

**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (a focus worth 1,000+ GP, such as a crystal ball, mirror, or water-filled font)
**Duration:** Concentration, up to 10 minutes

You can see and hear a creature you choose that is on the same plane of existence as you. The target makes a Wisdom saving throw, which is modified (see the tables below) by how well you know the target and the sort of physical connection you have to it. The target doesn't know what it is making the save against, only that it feels uneasy.

<table>
  <thead>
    <tr>
      <th>Your Knowledge of the Target Is …</th>
      <th>Save Modifier</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Secondhand (heard of the target)</td>
      <td>+5</td>
    </tr>
    <tr>
      <td>Firsthand (met the target)</td>
      <td>+0</td>
    </tr>
    <tr>
      <td>Extensive (know the target well)</td>
      <td>−5</td>
    </tr>
  </tbody>
</table>

<table>
  <thead>
    <tr>
      <th>You Have the Target's …</th>
      <th>Save Modifier</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Picture or other likeness</td>
      <td>−2</td>
    </tr>
    <tr>
      <td>Garment or other possession</td>
      <td>−4</td>
    </tr>
    <tr>
      <td>Body part, lock of hair, or bit of nail</td>
      <td>−10</td>
    </tr>
  </tbody>
</table>

On a successful save, the target isn't affected, and you can't use this spell on it again for 24 hours.

On a failed save, the spell creates an Invisible, intangible sensor within 10 feet of the target. You can see and hear through the sensor as if you were there. The sensor moves with the target, remaining within 10 feet of it for the duration. If something can see the sensor, it appears as a luminous orb about the size of your fist.

Instead of targeting a creature, you can target a location you have seen. When you do so, the sensor appears at that location and doesn't move.

#### Searing Smite

_Level 1 Evocation (Paladin)_

**Casting Time:** Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
**Range:** Self
**Component:** V
**Duration:** 1 minute

As you hit the target, it takes an extra 1d6 Fire damage from the attack. At the start of each of its turns until the spell ends, the target takes 1d6 Fire damage and then makes a Constitution saving throw. On a failed save, the spell continues. On a successful save, the spell ends.

_Using a Higher-Level Spell Slot._ All the damage increases by 1d6 for each spell slot level above 1.

#### Secret Chest

_Level 4 Conjuration (Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a chest, 3 feet by 2 feet by 2 feet, constructed from rare materials worth 5,000+ GP, and a Tiny replica of the chest made from the same materials worth 50+ GP)
**Duration:** Until dispelled

You hide a chest and all its contents on the Ethereal Plane. You must touch the chest and the miniature replica that serve as Material components for the spell. The chest can contain up to 12 cubic feet of nonliving material (3 feet by 2 feet by 2 feet).

While the chest remains on the Ethereal Plane, you can take a Magic action and touch the replica to recall the chest. It appears in an unoccupied space on the ground within 5 feet of you. You can send the chest back to the Ethereal Plane by taking a Magic action to touch the chest and the replica.

After 60 days, there is a cumulative 5 percent chance at the end of each day that the spell ends. The spell also ends if you cast this spell again or if the Tiny replica chest is destroyed. If the spell ends and the larger chest is on the Ethereal Plane, the chest remains there for you or someone else to find.

#### See Invisibility

_Level 2 Divination (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a pinch of talc)
**Duration:** 1 hour

For the duration, you see creatures and objects that have the Invisible condition as if they were visible, and you can see into the Ethereal Plane. Creatures and objects there appear ghostly.

#### Seeming

_Level 5 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** 8 hours

You give an illusory appearance to each creature of your choice that you can see within range. An unwilling target can make a Charisma saving throw, and if it succeeds, it is unaffected by this spell.

You can give the same appearance or different ones to the targets. The spell can change the appearance of the targets' bodies and equipment. You can make each creature seem 1 foot shorter or taller and appear heavier or lighter. A target's new appearance must have the same basic arrangement of limbs as the target, but the extent of the illusion is otherwise up to you. The spell lasts for the duration.

The changes wrought by this spell fail to hold up to physical inspection. For example, if you use this spell to add a hat to a creature's outfit, objects pass through the hat.

A creature that takes the Study action to examine a target can make an Intelligence (Investigation) check against your spell save DC. If it succeeds, it becomes aware that the target is disguised.

#### Sending

_Level 3 Divination (Bard, Cleric, Wizard)_

**Casting Time:** Action
**Range:** Unlimited
**Components:** V, S, M (a copper wire)
**Duration:** Instantaneous

You send a short message of 25 words or fewer to a creature you have met or a creature described to you by someone who has met it. The target hears the message in its mind, recognizes you as the sender if it knows you, and can answer in a like manner immediately. The spell enables targets to understand the meaning of your message.

You can send the message across any distance and even to other planes of existence, but if the target is on a different plane than you, there is a 5 percent chance that the message doesn't arrive. You know if the delivery fails.

Upon receiving your message, a creature can block your ability to reach it again with this spell for 8 hours. If you try to send another message during that time, you learn that you are blocked, and the spell fails.

#### Sequester

_Level 7 Transmutation (Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (gem dust worth 5,000+ GP, which the spell consumes)
**Duration:** Until dispelled

With a touch, you magically sequester an object or a willing creature. For the duration, the target has the Invisible condition and can't be targeted by Divination spells, detected by magic, or viewed remotely with magic.

If the target is a creature, it enters a state of suspended animation; it has the Unconscious condition, doesn't age, and doesn't need food, water, or air.

You can set a condition for the spell to end early. The condition can be anything you choose, but it must occur or be visible within 1 mile of the target. Examples include "after 1,000 years" or "when the tarrasque awakens." This spell also ends if the target takes any damage.

#### Shapechange

_Level 9 Transmutation (Druid, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a jade circlet worth 1,500+ GP)
**Duration:** Concentration, up to 1 hour

You shape-shift into another creature for the duration or until you take a Magic action to shape-shift into a different eligible form. The new form must be of a creature that has a Challenge Rating no higher than your level or Challenge Rating. You must have seen the sort of creature before, and it can't be a Construct or an Undead.

When you cast the spell, you gain a number of Temporary Hit Points equal to the Hit Points of the first form into which you shape-shift. These Temporary Hit Points vanish if any remain when the spell ends.

Your game statistics are replaced by the stat block of the chosen form, but you retain your creature type; alignment; personality; Intelligence, Wisdom, and Charisma scores; Hit Points; Hit Point Dice; proficiencies; and ability to communicate. If you have the Spellcasting feature, you retain it too.

Upon shape-shifting, you determine whether your equipment drops to the ground or changes in size and shape to fit the new form while you're in it.

#### Shatter

_Level 2 Evocation (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a chip of mica)
**Duration:** Instantaneous

A loud noise erupts from a point of your choice within range. Each creature in a 10-foot-radius Sphere centered there makes a Constitution saving throw, taking 3d8 Thunder damage on a failed save or half as much damage on a successful one. A Construct has Disadvantage on the save.

A nonmagical object that isn't being worn or carried also takes the damage if it's in the spell's area.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 2.

#### Shield

_Level 1 Abjuration (Sorcerer, Wizard)_

**Casting Time:** Reaction, which you take when you are hit by an attack roll or targeted by the _Magic Missile_ spell
**Range:** Self
**Components:** V, S
**Duration:** 1 round

An imperceptible barrier of magical force protects you. Until the start of your next turn, you have a +5
bonus to AC, including against the triggering attack, and you take no damage from _Magic Missile_.

#### Shield of Faith

_Level 1 Abjuration (Cleric, Paladin)_

**Casting Time:** Bonus Action
**Range:** 60 feet
**Components:** V, S, M (a prayer scroll)
**Duration:** Concentration, up to 10 minutes

A shimmering field surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration.

#### Shillelagh

_Transmutation Cantrip (Druid)_

**Casting Time:** Bonus Action
**Range:** Self
**Components:** V, S, M (mistletoe)
**Duration:** 1 minute

A Club or Quarterstaff you are holding is imbued with nature's power. For the duration, you can use your spellcasting ability instead of Strength for the attack and damage rolls of melee attacks using that weapon, and the weapon's damage die becomes a d8. If the attack deals damage, it can be Force damage or the weapon's normal damage type (your choice).

The spell ends early if you cast it again or if you let go of the weapon.

_Cantrip Upgrade._ The damage die changes when you reach levels 5 (d10), 11 (d12), and 17 (2d6).

#### Shining Smite

_Level 2 Transmutation (Paladin)_

**Casting Time:** Bonus Action, which you take immediately after hitting a creature with a Melee weapon or an Unarmed Strike
**Range:** Self
**Component:** V
**Duration:** Concentration, up to 1 minute

The target hit by the strike takes an extra 2d6 Radiant damage from the attack. Until the spell ends, the target sheds Bright Light in a 5-foot radius, attack rolls against it have Advantage, and it can't benefit from the Invisible condition.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 2.

#### Shocking Grasp

_Evocation Cantrip (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

Lightning springs from you to a creature that you try to touch. Make a melee spell attack against the target. On a hit, the target takes 1d8 Lightning damage, and it can't make Opportunity Attacks until the start of its next turn.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Silence

_Level 2 Illusion (Bard, Cleric, Ranger)_

**Casting Time:** Action or Ritual
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

For the duration, no sound can be created within or pass through a 20-foot-radius Sphere centered on a point you choose within range. Any creature or object entirely inside the Sphere has Immunity to Thunder damage, and creatures have the Deafened condition while entirely inside it. Casting a spell that includes a Verbal component is impossible there.

#### Silent Image

_Level 1 Illusion (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a bit of fleece)
**Duration:** Concentration, up to 10 minutes

You create the image of an object, a creature, or some other visible phenomenon that is no larger than a 15-foot Cube. The image appears at a spot within range and lasts for the duration. The image is purely visual; it isn't accompanied by sound, smell, or other sensory effects.

As a Magic action, you can cause the image to move to any spot within range. As the image changes location, you can alter its appearance so that its movements appear natural for the image. For example, if you create an image of a creature and move it, you can alter the image so that it appears to be walking.

Physical interaction with the image reveals it to be an illusion, since things can pass through it. A creature that takes a Study action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image.

#### Simulacrum

_Level 7 Illusion (Wizard)_

**Casting Time:** 12 hours
**Range:** Touch
**Components:** V, S, M (powdered ruby worth 1,500+ GP, which the spell consumes)
**Duration:** Until dispelled
You create a simulacrum of one Beast or Humanoid that is within 10 feet of you for the entire casting of the spell. You finish the casting by touching both the creature and a pile of ice or snow that is the same size as that creature, and the pile turns into the simulacrum, which is a creature. It uses the game statistics of the original creature at the time of casting, except it is a Construct, its Hit Point maximum is half as much, and it can't cast this spell.

The simulacrum is Friendly to you and creatures you designate. It obeys your commands and acts on your turn in combat. The simulacrum can't gain levels, and it can't take Short or Long Rests.

If the simulacrum takes damage, the only way to restore its Hit Points is to repair it as you take a Long Rest, during which you expend components worth 100 GP per Hit Point restored. The simulacrum must stay within 5 feet of you for the repair.

The simulacrum lasts until it drops to 0 Hit Points, at which point it reverts to snow and melts away. If you cast this spell again, any simulacrum you created with this spell is instantly destroyed.

#### Sleep

_Level 1 Enchantment (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a pinch of sand or rose petals)
**Duration:** Concentration, up to 1 minute

Each creature of your choice in a 5-foot-radius Sphere centered on a point within range must succeed on a Wisdom saving throw or have the Incapacitated condition until the end of its next turn, at which point it must repeat the save. If the target fails the second save, the target has the Unconscious condition for the duration. The spell ends on a target if it takes damage or someone within 5 feet of it takes an action to shake it out of the spell's effect.

Creatures that don't sleep, such as elves, or that have Immunity to the Exhaustion condition automatically succeed on saves against this spell.

#### Sleet Storm

_Level 3 Conjuration (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a miniature umbrella)
**Duration:** Concentration, up to 1 minute

Until the spell ends, sleet falls in a 40-foot-tall, 20-foot-radius Cylinder centered on a point you choose within range. The area is Heavily Obscured, and exposed flames in the area are doused.

Ground in the Cylinder is Difficult Terrain. When a creature enters the Cylinder for the first time on a turn or starts its turn there, it must succeed on a Dexterity saving throw or have the Prone condition and lose Concentration.

#### Slow

_Level 3 Transmutation (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a drop of molasses)
**Duration:** Concentration, up to 1 minute

You alter time around up to six creatures of your choice in a 40-foot Cube within range. Each target must succeed on a Wisdom saving throw or be affected by this spell for the duration.

An affected target's Speed is halved, it takes a −2 penalty to AC and Dexterity saving throws, and it can't take Reactions. On its turns, it can take either an action or a Bonus Action, not both, and it can make only one attack if it takes the Attack action. If it casts a spell with a Somatic component, there is a 25 percent chance the spell fails as a result of the target making the spell's gestures too slowly.

An affected target repeats the save at the end of each of its turns, ending the spell on itself on a success.

#### Sorcerous Burst

_Evocation Cantrip (Sorcerer)_

**Casting Time:** Action
**Range:** 120 feet
**Component:** V, S
**Duration:** Instantaneous

You cast sorcerous energy at one creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d8 damage of a type you choose: Acid, Cold, Fire, Lightning, Poison, Psychic, or Thunder.

If you roll an 8 on a d8 for this spell, you can roll another d8, and add it to the damage. When you cast this spell, the maximum number of these d8s you can add to the spell's damage equals your spellcasting ability modifier.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Spare the Dying

_Necromancy Cantrip (Cleric, Druid)_

**Casting Time:** Action
**Range:** 15 feet
**Components:** V, S
**Duration:** Instantaneous

Choose a creature within range that has 0 Hit Points and isn't dead. The creature becomes Stable.

_Cantrip Upgrade._ The range doubles when you reach levels 5 (30 feet), 11 (60 feet), and 17 (120 feet).

#### Speak with Animals

_Level 1 Divination (Bard, Druid, Ranger, Warlock)_

**Casting Time:** Action or Ritual
**Range:** Self
**Components:** V, S
**Duration:** 10 minutes

For the duration, you can comprehend and verbally communicate with Beasts, and you can use any of the Influence action's skill options with them.

Most Beasts have little to say about topics that don't pertain to survival or companionship, but at minimum, a Beast can give you information about nearby locations and monsters, including whatever it has perceived within the past day.

#### Speak with Dead

_Level 3 Necromancy (Bard, Cleric, Wizard)_

**Casting Time:** Action
**Range:** 10 feet
**Components:** V, S, M (burning incense)
**Duration:** 10 minutes

You grant the semblance of life to a corpse of your choice within range, allowing it to answer questions you pose. The corpse must have a mouth, and this spell fails if the deceased creature was Undead when it died. The spell also fails if the corpse was the target of this spell within the past 10 days.

Until the spell ends, you can ask the corpse up to five questions. The corpse knows only what it knew in life, including the languages it knew. Answers are usually brief, cryptic, or repetitive, and the corpse is under no compulsion to offer a truthful answer if you are antagonistic toward it or it recognizes you as an enemy. This spell doesn't return the creature's soul to its body, only its animating spirit. Thus, the corpse can't learn new information, doesn't comprehend anything that has happened since it died, and can't speculate about future events.

#### Speak with Plants

_Level 3 Transmutation (Bard, Druid, Ranger)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** 10 minutes

You imbue plants in an immobile 30-foot Emanation with limited sentience and animation, giving them the ability to communicate with you and follow your simple commands. You can question plants about events in the spell's area within the past day, gaining information about creatures that have passed, weather, and other circumstances.

You can also turn Difficult Terrain caused by plant growth (such as thickets and undergrowth) into ordinary terrain that lasts for the duration. Or you can turn ordinary terrain where plants are present into Difficult Terrain that lasts for the duration.

The spell doesn't enable plants to uproot themselves and move about, but they can move their branches, tendrils, and stalks for you.

If a Plant creature is in the area, you can communicate with it as if you shared a common language.

#### Spider Climb

_Level 2 Transmutation (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a drop of bitumen and a spider)
**Duration:** Concentration, up to 1 hour

Until the spell ends, one willing creature you touch gains the ability to move up, down, and across vertical surfaces and along ceilings, while leaving its hands free. The target also gains a Climb Speed equal to its Speed.

_Using a Higher-Level Spell Slot._ You can target one additional creature for each spell slot level above 2.

#### Spike Growth

_Level 2 Transmutation (Druid, Ranger)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (seven thorns)
**Duration:** Concentration, up to 10 minutes

The ground in a 20-foot-radius Sphere centered on a point within range sprouts hard spikes and thorns. The area becomes Difficult Terrain for the duration. When a creature moves into or within the area, it takes 2d4 Piercing damage for every 5 feet it travels.

The transformation of the ground is camouflaged to look natural. Any creature that can't see the area when the spell is cast must take a Search action and succeed on a Wisdom (Perception or Survival) check against your spell save DC to recognize the terrain as hazardous before entering it.

#### Spirit Guardians

_Level 3 Conjuration (Cleric)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a prayer scroll)
**Duration:** Concentration, up to 10 minutes

Protective spirits flit around you in a 15-foot Emanation for the duration. If you are good or neutral, their spectral form appears angelic or fey (your choice). If you are evil, they appear fiendish.

When you cast this spell, you can designate creatures to be unaffected by it. Any other creature's Speed is halved in the Emanation, and whenever the Emanation enters a creature's space and whenever a creature enters the Emanation or ends its turn there, the creature must make a Wisdom saving throw. On a failed save, the creature takes 3d8 Radiant damage (if you are good or neutral) or 3d8 Necrotic damage (if you are evil). On a successful save, the creature takes half as much damage. A creature makes this save only once per turn.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 3.

#### Spiritual Weapon

_Level 2 Evocation (Cleric)_

**Casting Time:** Bonus Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You create a floating, spectral force that resembles a weapon of your choice and lasts for the duration. The force appears within range in a space of your choice, and you can immediately make one melee spell attack against one creature within 5 feet of the force. On a hit, the target takes Force damage equal to 1d8 plus your spellcasting ability modifier.

As a Bonus Action on your later turns, you can move the force up to 20 feet and repeat the attack against a creature within 5 feet of it.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for every slot level above 2.

#### Starry Wisp

_Evocation Cantrip (Bard, Druid)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

You launch a mote of light at one creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d8 Radiant damage, and until the end of your next turn, it emits Dim Light in a 10-foot radius and can't benefit from the Invisible condition.

_Cantrip Upgrade._ The damage increases by 1d8 when you reach levels 5 (2d8), 11 (3d8), and 17 (4d8).

#### Stinking Cloud

_Level 3 Conjuration (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 90 feet
**Components:** V, S, M (a rotten egg)
**Duration:** Concentration, up to 1 minute

You create a 20-foot-radius Sphere of yellow, nauseating gas centered on a point within range. The cloud is Heavily Obscured. The cloud lingers in the air for the duration or until a strong wind (such as the one created by _Gust of Wind_) disperses it.

Each creature that starts its turn in the Sphere must succeed on a Constitution saving throw or have the Poisoned condition until the end of the current turn. While Poisoned in this way, the creature can't take an action or a Bonus Action.

#### Stone Shape

_Level 4 Transmutation (Cleric, Druid, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (soft clay)
**Duration:** Instantaneous

You touch a stone object of Medium size or smaller or a section of stone no more than 5 feet in any dimension and form it into any shape you like. For example, you could shape a large rock into a weapon, statue, or coffer, or you could make a small passage through a wall that is 5 feet thick. You could also shape a stone door or its frame to seal the door shut. The object you create can have up to two hinges and a latch, but finer mechanical detail isn't possible.

#### Stoneskin

_Level 4 Transmutation (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (diamond dust worth 100+ GP, which the spell consumes)
**Duration:** Concentration, up to 1 hour

Until the spell ends, one willing creature you touch has Resistance to Bludgeoning, Piercing, and Slashing damage.

#### Storm of Vengeance

_Level 9 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 1 mile
**Components:** V, S
**Duration:** Concentration, up to 1 minute

A churning storm cloud forms for the duration, centered on a point within range and spreading to a radius of 300 feet. Each creature under the cloud when it appears must succeed on a Constitution saving throw or take 2d6 Thunder damage and have the Deafened condition for the duration.

At the start of each of your later turns, the storm produces different effects, as detailed below.

_Turn 2._ Acidic rain falls. Each creature and object under the cloud takes 4d6 Acid damage.

_Turn 3._ You call six bolts of lightning from the cloud to strike six different creatures or objects beneath it. Each target makes a Dexterity saving throw, taking 10d6 Lightning damage on a failed save or half as much damage on a successful one.
_Turn 4._ Hailstones rain down. Each creature under the cloud takes 2d6 Bludgeoning damage.

_Turns 5–10._ Gusts and freezing rain assail the area under the cloud. Each creature there takes 1d6 Cold damage. Until the spell ends, the area is Difficult Terrain and Heavily Obscured, ranged attacks with weapons are impossible there, and strong wind blows through the area.

#### Suggestion

_Level 2 Enchantment (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, M (a drop of honey)
**Duration:** Concentration, up to 8 hours

You suggest a course of activity—described in no more than 25 words—to one creature you can see within range that can hear and understand you. The suggestion must sound achievable and not involve anything that would obviously deal damage to the target or its allies. For example, you could say, "Fetch the key to the cult's treasure vault, and give the key to me." Or you could say, "Stop fighting, leave this library peacefully, and don't return."

The target must succeed on a Wisdom saving throw or have the Charmed condition for the duration or until you or your allies deal damage to the target. The Charmed target pursues the suggestion to the best of its ability. The suggested activity can continue for the entire duration, but if the suggested activity can be completed in a shorter time, the spell ends for the target upon completing it.

#### Summon Dragon

_Level 5 Conjuration (Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (an object with the image of a dragon engraved on it worth 500+ GP)
**Duration:** Concentration, up to 1 hour

You call forth a Dragon spirit. It manifests in an unoccupied space that you can see within range and uses the Draconic Spirit stat block. The creature disappears when it drops to 0 Hit Points or when the spell ends.

The creature is an ally to you and your allies. In combat, the creature shares your Initiative count, but it takes its turn immediately after yours. It obeys your verbal commands (no action required by you). If you don't issue any, it takes the Dodge action and uses its movement to avoid danger.

_Using a Higher-Level Spell Slot._ Use the spell slot's level for the spell's level in the stat block.

## Draconic Spirit

_Large Dragon, Neutral_

**AC** 14 + the spell's level
**HP** 50 + 10 for each spell level above 5
**Speed** 30 ft., Fly 60 ft., Swim 30 ft.

<table>
  <tbody>
    <tr>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td></td>
      <td>MOD</td>
      <td>SAVE</td>
      <td colspan="4"></td>
    </tr>
    <tr>
      <td>STR</td>
      <td>19</td>
      <td>+4</td>
      <td>+4</td>
      <td>DEX</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
      <td>CON</td>
      <td>17</td>
      <td>+3</td>
      <td>+3</td>
    </tr>
    <tr>
      <td>INT</td>
      <td>10</td>
      <td>+0</td>
      <td>+0</td>
      <td>WIS</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
      <td>CHA</td>
      <td>14</td>
      <td>+2</td>
      <td>+2</td>
    </tr>
  </tbody>
</table>

**Resistances** Acid, Cold, Fire, Lightning, Poison
**Immunities** Charmed, Frightened, Poisoned
**Senses** Blindsight 30 ft., Darkvision 60 ft.; Passive Perception 12
**Languages** Draconic, understands the languages you know
**CR** None (XP 0; PB equals your Proficiency Bonus)

#### Traits

_Shared Resistances._ When you summon the spirit, choose one of its Resistances. You have Resistance to the chosen damage type until the spell ends.

#### Actions

_Multiattack._ The spirit makes a number of Rend attacks equal to half the spell's level (round down), and it uses Breath Weapon.

_Rend. Melee Attack Roll:_ Bonus equals your spell attack modifier, reach 10 feet. _Hit:_ 1d6 + 4 + the spell's level Piercing damage.

_Breath Weapon. Dexterity Saving Throw:_ DC equals your spell save DC, each creature in a 30-foot Cone. _Failure:_ 2d6 damage of a type this spirit has Resistance to (your choice when you cast the spell). _Success:_ Half damage.

#### Sunbeam

_Level 6 Evocation (Cleric, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a magnifying glass)
**Duration:** Concentration, up to 1 minute

You launch a sunbeam in a 5-foot-wide, 60-foot-long Line. Each creature in the Line makes a Constitution saving throw. On a failed save, a creature takes 6d8 Radiant damage and has the Blinded condition until the start of your next turn. On a successful save, it takes half as much damage only.

Until the spell ends, you can take a Magic action to create a new Line of radiance.

For the duration, a mote of brilliant radiance shines above you. It sheds Bright Light in a 30-foot radius and Dim Light for an additional 30 feet. This light is sunlight.

#### Sunburst

_Level 8 Evocation (Cleric, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a piece of sunstone)
**Duration:** Instantaneous

Brilliant sunlight flashes in a 60-foot-radius Sphere centered on a point you choose within range. Each creature in the Sphere makes a Constitution saving throw. On a failed save, a creature takes 12d6 Radiant damage and has the Blinded condition for 1 minute. On a successful save, it takes half as much damage only.

A creature Blinded by this spell makes another Constitution saving throw at the end of each of its turns, ending the effect on itself on a success.

This spell dispels Darkness in its area that was created by any spell.

#### Symbol

_Level 7 Abjuration (Bard, Cleric, Druid, Wizard)_

**Casting Time:** 1 minute
**Range:** Touch
**Components:** V, S, M (powdered diamond worth 1,000+ GP, which the spell consumes)
**Duration:** Until dispelled or triggered

You inscribe a harmful glyph either on a surface (such as a section of floor or wall) or within an object that can be closed (such as a book or chest). The glyph can cover an area no larger than 10 feet in diameter. If you choose an object, it must remain in place; if it is moved more than 10 feet from where you cast this spell, the glyph is broken, and the spell ends without being triggered.

The glyph is nearly imperceptible and requires a successful Wisdom (Perception) check against your spell save DC to notice.

When you inscribe the glyph, you set its trigger and choose which effect the symbol bears: Death, Discord, Fear, Pain, Sleep, or Stunning. Each one is explained below.

_Set the Trigger._ You decide what triggers the glyph when you cast the spell. For glyphs inscribed on a surface, common triggers include touching or stepping on the glyph, removing another object covering it, or approaching within a certain distance of it. For glyphs inscribed within an object, common triggers include opening that object or seeing the glyph.

You can refine the trigger so that only creatures of certain types activate it (for example, the glyph could be set to affect Aberrations). You can also set conditions for creatures that don't trigger the glyph, such as those who say a certain password.

Once triggered, the glyph glows, filling a 60-foot-radius Sphere with Dim Light for 10 minutes, after which time the spell ends. Each creature in the Sphere when the glyph activates is targeted by its effect, as is a creature that enters the Sphere for the first time on a turn or ends its turn there. A creature is targeted only once per turn.

_Death._ Each target makes a Constitution saving throw, taking 10d10 Necrotic damage on a failed save or half as much damage on a successful save.

_Discord._ Each target makes a Wisdom saving throw. On a failed save, a target argues with other creatures for 1 minute. During this time, it is incapable of meaningful communication and has Disadvantage on attack rolls and ability checks.

_Fear._ Each target must succeed on a Wisdom saving throw or have the Frightened condition for 1 minute. While Frightened, the target must move at least 30 feet away from the glyph on each of its turns, if able.

_Pain._ Each target must succeed on a Constitution saving throw or have the Incapacitated condition for 1 minute.

_Sleep._ Each target must succeed on a Wisdom saving throw or have the Unconscious condition for 10 minutes. A creature awakens if it takes damage or if someone takes an action to shake it awake.

_Stunning._ Each target must succeed on a Wisdom saving throw or have the Stunned condition for 1 minute.

#### Telekinesis

_Level 5 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Concentration, up to 10 minutes

You gain the ability to move or manipulate creatures or objects by thought. When you cast the spell and as a Magic action on your later turns before the spell ends, you can exert your will on one creature or object that you can see within range, causing the appropriate effect below. You can affect the same target round after round or choose a new one at any time. If you switch targets, the prior target is no longer affected by the spell.

_Creature._ You can try to move a Huge or smaller creature. The target must succeed on a Strength saving throw, or you move it up to 30 feet in any direction within the spell's range. Until the end of your next turn, the creature has the Restrained condition, and if you lift it into the air, it is suspended there. It falls at the end of your next turn unless you use this option on it again and it fails the save.

_Object._ You can try to move a Huge or smaller object. If the object isn't being worn or carried, you automatically move it up to 30 feet in any direction within the spell's range. If the object is worn or carried by a creature, that creature must succeed on a Strength saving throw, or you pull the object away and move it up to 30 feet in any direction within the spell's range.

You can exert fine control on objects with your telekinetic grip, such as manipulating a simple tool, opening a door or a container, stowing or retrieving an item from an open container, or pouring the contents from a vial.

#### Telepathic Bond

_Level 5 Divination (Bard, Wizard)_

**Casting Time:** Action or Ritual
**Range:** 30 feet
**Components:** V, S, M (two eggs)
**Duration:** 1 hour

You forge a telepathic link among up to eight willing creatures of your choice within range, psychically linking each creature to all the others for the duration. Creatures that can't communicate in any languages aren't affected by this spell.

Until the spell ends, the targets can communicate telepathically through the bond whether or not they share a language. The communication is possible over any distance, though it can't extend to other planes of existence.

#### Teleport

_Level 7 Conjuration (Bard, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 10 feet
**Components:** V
**Duration:** Instantaneous

This spell instantly transports you and up to eight willing creatures that you can see within range, or a single object that you can see within range, to a destination you select. If you target an object, it must be Large or smaller, and it can't be held or carried by an unwilling creature.

The destination you choose must be known to you, and it must be on the same plane of existence as you. Your familiarity with the destination determines whether you arrive there successfully. The GM rolls 1d100 and consults the Teleportation Outcome table and the explanations after it.

**Teleportation Outcome**

<table>
  <thead>
    <tr>
      <th>Familiarity</th>
      <th>Mishap</th>
      <th>Similar Area</th>
      <th>Off Target</th>
      <th>On Target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Permanent circle</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>01–00</td>
    </tr>
    <tr>
      <td>Linked object</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>01–00</td>
    </tr>
    <tr>
      <td>Very familiar</td>
      <td>01–05</td>
      <td>06–13</td>
      <td>14–24</td>
      <td>25–00</td>
    </tr>
    <tr>
      <td>Seen casually</td>
      <td>01–33</td>
      <td>34–43</td>
      <td>44–53</td>
      <td>54–00</td>
    </tr>
    <tr>
      <td>Viewed once or described</td>
      <td>01–43</td>
      <td>44–53</td>
      <td>54–73</td>
      <td>74–00</td>
    </tr>
    <tr>
      <td>False destination</td>
      <td>01–50</td>
      <td>51–00</td>
      <td>—</td>
      <td>—</td>
    </tr>
  </tbody>
</table>

_Familiarity._ Here are the meanings of the terms in the table's Familiarity column:

- "Permanent circle" means a permanent teleportation circle whose sigil sequence you know.
- "Linked object" means you possess an object taken from the desired destination within the last six months, such as a book from a wizard's library.
- "Very familiar" is a place you have visited often, a place you have carefully studied, or a place you can see when you cast the spell.
- "Seen casually" is a place you have seen more than once but with which you aren't very familiar.
- "Viewed once or described" is a place you have seen once, possibly using magic, or a place you know through someone else's description, perhaps from a map.
- "False destination" is a place that doesn't exist. Perhaps you tried to scry an enemy's sanctum but instead viewed an illusion, or you are attempting to teleport to a location that no longer exists.

_Mishap._ The spell's unpredictable magic results in a difficult journey. Each teleporting creature (or the target object) takes 3d10 Force damage, and the GM rerolls on the table to see where you wind up (multiple mishaps can occur, dealing damage each time).

_Similar Area._ You and your group (or the target object) appear in a different area that's visually or thematically similar to the target area. You appear in the closest similar place. If you are heading for your home laboratory, for example, you might appear in another person's laboratory in the same city.

_Off Target._ You and your group (or the target object) appear 2d12 miles away from the destination in a random direction. Roll 1d8 for the direction: 1, east; 2, southeast; 3, south; 4, southwest; 5, west; 6, northwest; 7, north; or 8, northeast.

_On Target._ You and your group (or the target object) appear where you intended.

#### Teleportation Circle

_Level 5 Conjuration (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** 1 minute
**Range:** 10 feet
**Components:** V, M (rare inks worth 50+ GP, which the spell consumes)
**Duration:** 1 round

As you cast the spell, you draw a 5-foot-radius circle on the ground inscribed with sigils that link your location to a permanent teleportation circle of your choice whose sigil sequence you know and that is on the same plane of existence as you. A shimmering portal opens within the circle you drew and remains open until the end of your next turn. Any creature that enters the portal instantly appears within 5 feet of the destination circle or in the nearest unoccupied space if that space is occupied.

Many major temples, guildhalls, and other important places have permanent teleportation circles. Each circle includes a unique sigil sequence—a string of runes arranged in a particular pattern.

When you first gain the ability to cast this spell, you learn the sigil sequences for two destinations on the Material Plane, determined by the GM. You might learn additional sigil sequences during your adventures. You can commit a new sigil sequence to memory after studying it for 1 minute.

You can create a permanent teleportation circle by casting this spell in the same location every day for 365 days.

#### Thaumaturgy

_Transmutation Cantrip (Cleric)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V
**Duration:** Up to 1 minute

You manifest a minor wonder within range. You create one of the effects below within range. If you cast this spell multiple times, you can have up to three of its 1-minute effects active at a time.

_Altered Eyes._ You alter the appearance of your eyes for 1 minute.

_Booming Voice._ Your voice booms up to three times as loud as normal for 1 minute. For the duration, you have Advantage on Charisma (Intimidation) checks.

_Fire Play._ You cause flames to flicker, brighten, dim, or change color for 1 minute.

_Invisible Hand._ You instantaneously cause an unlocked door or window to fly open or slam shut.

_Phantom Sound._ You create an instantaneous sound that originates from a point of your choice within range, such as a rumble of thunder, the cry of a raven, or ominous whispers.

_Tremors._ You cause harmless tremors in the ground for 1 minute.

#### Thunderwave

_Level 1 Evocation (Bard, Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Instantaneous

You unleash a wave of thunderous energy. Each creature in a 15-foot Cube originating from you makes a Constitution saving throw. On a failed save, a creature takes 2d8 Thunder damage and is pushed 10 feet away from you. On a successful save, a creature takes half as much damage only.

In addition, unsecured objects that are entirely within the Cube are pushed 10 feet away from you, and a thunderous boom is audible within 300 feet.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 1.

#### Time Stop

_Level 9 Transmutation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V
**Duration:** Instantaneous

You briefly stop the flow of time for everyone but yourself. No time passes for other creatures, while you take 1d4 + 1 turns in a row, during which you can use actions and move as normal.

This spell ends if one of the actions you use during this period, or any effects that you create during it, affects a creature other than you or an object being worn or carried by someone other than you. In addition, the spell ends if you move to a place more than 1,000 feet from the location where you cast it.

#### Tiny Hut

_Level 3 Evocation (Bard, Wizard)_

**Casting Time:** 1 minute or Ritual
**Range:** Self
**Components:** V, S, M (a crystal bead)
**Duration:** 8 hours

A 10-foot Emanation springs into existence around you and remains stationary for the duration. The spell fails when you cast it if the Emanation isn't big enough to fully encapsulate all creatures in its area.

Creatures and objects within the Emanation when you cast the spell can move through it freely. All other creatures and objects are barred from passing through it. Spells of level 3 or lower can't be cast through it, and the effects of such spells can't extend into it.

The atmosphere inside the Emanation is comfortable and dry, regardless of the weather outside. Until the spell ends, you can command the interior to have Dim Light or Darkness (no action required). The Emanation is opaque from the outside and of any color you choose, but it's transparent from the inside.

The spell ends early if you leave the Emanation or if you cast it again.

#### Tongues

_Level 3 Divination (Bard, Cleric, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, M (a miniature ziggurat)
**Duration:** 1 hour

This spell grants the creature you touch the ability to understand any spoken or signed language that it hears or sees. Moreover, when the target communicates by speaking or signing, any creature that knows at least one language can understand it if that creature can hear the speech or see the signing.

#### Transport via Plants

_Level 6 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 10 feet
**Components:** V, S
**Duration:** 1 minute

This spell creates a magical link between a Large or larger inanimate plant within range and another plant, at any distance, on the same plane of existence. You must have seen or touched the destination plant at least once before. For the duration, any creature can step into the target plant and exit from the destination plant by using 5 feet of movement.

#### Tree Stride

_Level 5 Conjuration (Druid, Ranger)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You gain the ability to enter a tree and move from inside it to inside another tree of the same kind within 500 feet. Both trees must be living and at least the same size as you. You must use 5 feet of movement to enter a tree. You instantly know the location of all other trees of the same kind within 500 feet and, as part of the move used to enter the tree, can either pass into one of those trees or step out of the tree you're in. You appear in a spot of your choice within 5 feet of the destination tree, using another 5 feet of movement. If you have no movement left, you appear within 5 feet of the tree you entered.

You can use this transportation ability only once on each of your turns. You must end each turn outside a tree.

#### True Polymorph

_Level 9 Transmutation (Bard, Warlock, Wizard)_

**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a drop of mercury, a dollop of gum arabic, and a wisp of smoke)
**Duration:** Concentration, up to 1 hour

Choose one creature or nonmagical object that you can see within range. The creature shape-shifts into a different creature or a nonmagical object, or the object shape-shifts into a creature (the object must be neither worn nor carried). The transformation lasts for the duration or until the target dies or is destroyed, but if you maintain Concentration on this spell for the full duration, the spell lasts until dispelled.

An unwilling creature can make a Wisdom saving throw, and if it succeeds, it isn't affected by this spell.

_Creature into Creature._ If you turn a creature into another kind of creature, the new form can be any kind you choose that has a Challenge Rating equal to or less than the target's Challenge Rating or level. The target's game statistics are replaced by the stat block of the new form, but it retains its Hit Points, Hit Point Dice, alignment, and personality.

The target gains a number of Temporary Hit Points equal to the Hit Points of the new form. These Temporary Hit Points vanish if any remain when the spell ends.

The target is limited in the actions it can perform by the anatomy of its new form, and it can't speak or cast spells.

The target's gear melds into the new form. The creature can't use or otherwise benefit from any of that equipment.

_Object into Creature._ You can turn an object into any kind of creature, as long as the creature's size is no larger than the object's size and the creature has a Challenge Rating of 9 or lower. The creature is Friendly to you and your allies. In combat, it takes its turns immediately after yours, and it obeys your commands.

If the spell lasts more than an hour, you no longer control the creature. It might remain Friendly to you, depending on how you have treated it.

_Creature into Object._ If you turn a creature into an object, it transforms along with whatever it is wearing and carrying into that form, as long as the object's size is no larger than the creature's size. The creature's statistics become those of the object, and the creature has no memory of time spent in this form after the spell ends and it returns to normal.

#### True Resurrection

_Level 9 Necromancy (Cleric, Druid)_

**Casting Time:** 1 hour
**Range:** Touch
**Components:** V, S, M (diamonds worth 25,000+ GP, which the spell consumes)
**Duration:** Instantaneous

You touch a creature that has been dead for no longer than 200 years and that died for any reason except old age. The creature is revived with all its Hit Points.

This spell closes all wounds, neutralizes any poison, cures all magical contagions, and lifts any curses affecting the creature when it died. The spell replaces damaged or missing organs and limbs. If the creature was Undead, it is restored to its non-Undead form.

The spell can provide a new body if the original no longer exists, in which case you must speak the creature's name. The creature then appears in an unoccupied space you choose within 10 feet of you.

#### True Seeing

_Level 6 Divination (Bard, Cleric, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (mushroom powder worth 25+ GP, which the spell consumes)
**Duration:** 1 hour

For the duration, the willing creature you touch has Truesight with a range of 120 feet.

#### True Strike

_Divination Cantrip (Bard, Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** S, M (a weapon with which you have proficiency and that is worth 1+ CP)
**Duration:** Instantaneous

Guided by a flash of magical insight, you make one attack with the weapon used in the spell's casting. The attack uses your spellcasting ability for the attack and damage rolls instead of using Strength or Dexterity. If the attack deals damage, it can be Radiant damage or the weapon's normal damage type (your choice).

_Cantrip Upgrade._ Whether you deal Radiant damage or the weapon's normal damage type, the attack deals extra Radiant damage when you reach levels 5 (1d6), 11 (2d6), and 17 (3d6).

#### Tsunami

_Level 8 Conjuration (Druid)_

**Casting Time:** 1 minute
**Range:** 1 mile
**Components:** V, S
**Duration:** Concentration, up to 6 rounds

A wall of water springs into existence at a point you choose within range. You can make the wall up to 300 feet long, 300 feet high, and 50 feet thick. The wall lasts for the duration.

When the wall appears, each creature in its area makes a Strength saving throw, taking 6d10 Bludgeoning damage on a failed save or half as much damage on a successful one.

At the start of each of your turns after the wall appears, the wall, along with any creatures in it, moves 50 feet away from you. Any Huge or smaller creature inside the wall or whose space the wall enters when it moves must succeed on a Strength saving throw or take 5d10 Bludgeoning damage. A creature can take this damage only once per round. At the end of the turn, the wall's height is reduced by 50 feet, and the damage the wall deals on later rounds is reduced by 1d10. When the wall reaches 0 feet in height, the spell ends.

A creature caught in the wall can move by swimming. Because of the wave's force, though, the creature must succeed on a Strength (Athletics) check against your spell save DC to move at all. If it fails the check, it can't move. A creature that moves out of the wall falls to the ground.

#### Unseen Servant

_Level 1 Conjuration (Bard, Warlock, Wizard)_

**Casting Time:** Action or Ritual
**Range:** 60 feet
**Components:** V, S, M (a bit of string and of wood)
**Duration:** 1 hour

This spell creates an Invisible, mindless, shapeless, Medium force that performs simple tasks at your command until the spell ends. The servant springs into existence in an unoccupied space on the ground within range. It has AC 10, 1 Hit Point, and a Strength of 2, and it can't attack. If it drops to 0 Hit Points, the spell ends.

Once on each of your turns as a Bonus Action, you can mentally command the servant to move up to 15 feet and interact with an object. The servant can perform simple tasks that a human could do, such as fetching things, cleaning, mending, folding clothes, lighting fires, serving food, and pouring drinks. Once you give the command, the servant performs the task to the best of its ability until it completes the task, then waits for your next command.

If you command the servant to perform a task that would move it more than 60 feet away from you, the spell ends.

#### Vampiric Touch

_Level 3 Necromancy (Sorcerer, Warlock, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** Concentration, up to 1 minute

The touch of your shadow-wreathed hand can siphon life force from others to heal your wounds. Make a melee spell attack against one creature within reach. On a hit, the target takes 3d6 Necrotic damage, and you regain Hit Points equal to half the amount of Necrotic damage dealt.

Until the spell ends, you can make the attack again on each of your turns as a Magic action, targeting the same creature or a different one.

_Using a Higher-Level Spell Slot._ The damage increases by 1d6 for each spell slot level above 3.

#### Vicious Mockery

_Enchantment Cantrip (Bard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V
**Duration:** Instantaneous

You unleash a string of insults laced with subtle enchantments at one creature you can see or hear within range. The target must succeed on a Wisdom saving throw or take 1d6 Psychic damage and have Disadvantage on the next attack roll it makes before the end of its next turn.

_Cantrip Upgrade._ The damage increases by 1d6 when you reach levels 5 (2d6), 11 (3d6), and 17 (4d6).

#### Vitriolic Sphere

_Level 4 Evocation (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a drop of bile)
**Duration:** Instantaneous

You point at a location within range, and a glowing, 1-foot-diameter ball of acid streaks there and explodes in a 20-foot-radius Sphere. Each creature in that area makes a Dexterity saving throw. On a failed save, a creature takes 10d4 Acid damage and another 5d4 Acid damage at the end of its next turn. On a successful save, a creature takes half the initial damage only.

_Using a Higher-Level Spell Slot._ The initial damage increases by 2d4 for each spell slot level above 4.

#### Wall of Fire

_Level 4 Evocation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a piece of charcoal)
**Duration:** Concentration, up to 1 minute

You create a wall of fire on a solid surface within range. You can make the wall up to 60 feet long, 20 feet high, and 1 foot thick, or a ringed wall up to 20 feet in diameter, 20 feet high, and 1 foot thick. The wall is opaque and lasts for the duration.

When the wall appears, each creature in its area makes a Dexterity saving throw, taking 5d8 Fire damage on a failed save or half as much damage on a successful one.

One side of the wall, selected by you when you cast this spell, deals 5d8 Fire damage to each creature that ends its turn within 10 feet of that side or inside the wall. A creature takes the same damage when it enters the wall for the first time on a turn or ends its turn there. The other side of the wall deals no damage.

_Using a Higher-Level Spell Slot._ The damage increases by 1d8 for each spell slot level above 4.

#### Wall of Force

_Level 5 Evocation (Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a shard of glass)
**Duration:** Concentration, up to 10 minutes

An Invisible wall of force springs into existence at a point you choose within range. The wall appears in any orientation you choose, as a horizontal or vertical barrier or at an angle. It can be free floating or resting on a solid surface. You can form it into a hemispherical dome or a globe with a radius of up to 10 feet, or you can shape a flat surface made up of ten 10-foot-by-10-foot panels. Each panel must be contiguous with another panel. In any form, the wall is 1/4 inch thick and lasts for the duration. If the wall cuts through a creature's space when it appears, the creature is pushed to one side of the wall (you choose which side).

Nothing can physically pass through the wall. It is immune to all damage and can't be dispelled by _Dispel Magic_. A _Disintegrate_ spell destroys the wall instantly, however. The wall also extends into the Ethereal Plane and blocks ethereal travel through the wall.

#### Wall of Ice

_Level 6 Evocation (Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a piece of quartz)
**Duration:** Concentration, up to 10 minutes

You create a wall of ice on a solid surface within range. You can form it into a hemispherical dome or a globe with a radius of up to 10 feet, or you can shape a flat surface made up of ten 10-foot-square panels. Each panel must be contiguous with another panel. In any form, the wall is 1 foot thick and lasts for the duration.

If the wall cuts through a creature's space when it appears, the creature is pushed to one side of the wall (you choose which side) and makes a Dexterity saving throw, taking 10d6 Cold damage on a failed save or half as much damage on a successful one.

The wall is an object that can be damaged and thus breached. It has AC 12 and 30 Hit Points per 10-foot section, and it has Immunity to Cold, Poison, and Psychic damage and Vulnerability to Fire damage. Reducing a 10-foot section of wall to 0 Hit Points destroys it and leaves behind a sheet of frigid air in the space the wall occupied.

A creature moving through the sheet of frigid air for the first time on a turn makes a Constitution saving throw, taking 5d6 Cold damage on a failed save or half as much damage on a successful one.
_Using a Higher-Level Spell Slot._ The damage the wall deals when it appears increases by 2d6 and the damage from passing through the sheet of frigid air increases by 1d6 for each spell slot level above 6.

#### Wall of Stone

_Level 5 Evocation (Druid, Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a cube of granite)
**Duration:** Concentration, up to 10 minutes

A nonmagical wall of solid stone springs into existence at a point you choose within range. The wall is 6 inches thick and is composed of ten 10-foot-by-10-foot panels. Each panel must be contiguous with another panel. Alternatively, you can create 10-foot-by-20-foot panels that are only 3 inches thick.

If the wall cuts through a creature's space when it appears, the creature is pushed to one side of the wall (you choose which side). If a creature would be surrounded on all sides by the wall (or the wall and another solid surface), that creature can make a Dexterity saving throw. On a success, it can use its Reaction to move up to its Speed so that it is no longer enclosed by the wall.

The wall can have any shape you desire, though it can't occupy the same space as a creature or object. The wall doesn't need to be vertical or rest on a firm foundation. It must, however, merge with and be solidly supported by existing stone. Thus, you can use this spell to bridge a chasm or create a ramp.

If you create a span greater than 20 feet in length, you must halve the size of each panel to create supports. You can crudely shape the wall to create battlements and the like.

The wall is an object made of stone that can be damaged and thus breached. Each panel has AC 15 and 30 Hit Points per inch of thickness, and it has Immunity to Poison and Psychic damage. Reducing a panel to 0 Hit Points destroys it and might cause connected panels to collapse at the GM's discretion.

If you maintain your Concentration on this spell for its full duration, the wall becomes permanent and can't be dispelled. Otherwise, the wall disappears when the spell ends.

#### Wall of Thorns

_Level 6 Conjuration (Druid)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a handful of thorns)
**Duration:** Concentration, up to 10 minutes

You create a wall of tangled brush bristling with needle-sharp thorns. The wall appears within range on a solid surface and lasts for the duration. You choose to make the wall up to 60 feet long, 10 feet high, and 5 feet thick or a circle that has a 20-foot diameter and is up to 20 feet high and 5 feet thick. The wall blocks line of sight.

When the wall appears, each creature in its area makes a Dexterity saving throw, taking 7d8 Piercing damage on a failed save or half as much damage on a successful one.

A creature can move through the wall, albeit slowly and painfully. For every 1 foot a creature moves through the wall, it must spend 4 feet of movement. Furthermore, the first time a creature enters a space in the wall on a turn or ends its turn there, the creature makes a Dexterity saving throw, taking 7d8 Slashing damage on a failed save or half as much damage on a successful one. A creature makes this save only once per turn.

_Using a Higher-Level Spell Slot._ Both types of damage increase by 1d8 for each spell slot level above 6.

#### Warding Bond

_Level 2 Abjuration (Cleric, Paladin)_

**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a pair of platinum rings worth 50+ GP each, which you and the target must wear for the duration)
**Duration:** 1 hour

You touch another creature that is willing and create a mystic connection between you and the target until the spell ends. While the target is within 60 feet of you, it gains a +1 bonus to AC and saving throws, and it has Resistance to all damage. Also, each time it takes damage, you take the same amount of damage.

The spell ends if you drop to 0 Hit Points or if you and the target become separated by more than 60 feet. It also ends if the spell is cast again on either of the connected creatures.

#### Water Breathing

_Level 3 Transmutation (Druid, Ranger, Sorcerer, Wizard)_

**Casting Time:** Action or Ritual
**Range:** 30 feet
**Components:** V, S, M (a short reed)
**Duration:** 24 hours

This spell grants up to ten willing creatures of your choice within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.

#### Water Walk

_Level 3 Transmutation (Cleric, Druid, Ranger, Sorcerer)_

**Casting Time:** Action or Ritual
**Range:** 30 feet
**Components:** V, S, M (a piece of cork)
**Duration:** 1 hour

This spell grants the ability to move across any liquid surface—such as water, acid, mud, snow, quicksand, or lava—as if it were harmless solid ground (creatures crossing molten lava can still take damage from the heat). Up to ten willing creatures of your choice within range gain this ability for the duration.

An affected target must take a Bonus Action to pass from the liquid's surface into the liquid itself and vice versa, but if the target falls into the liquid, the target passes through the surface into the liquid below.

#### Web

_Level 2 Conjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a bit of spiderweb)
**Duration:** Concentration, up to 1 hour

You conjure a mass of sticky webbing at a point within range. The webs fill a 20-foot Cube there for the duration. The webs are Difficult Terrain, and the area within them is Lightly Obscured.

If the webs aren't anchored between two solid masses (such as walls or trees) or layered across a floor, wall, or ceiling, the web collapses on itself, and the spell ends at the start of your next turn. Webs layered over a flat surface have a depth of 5 feet.

The first time a creature enters the webs on a turn or starts its turn there, it must succeed on a Dexterity saving throw or have the Restrained condition while in the webs or until it breaks free.

A creature Restrained by the webs can take an action to make a Strength (Athletics) check against your spell save DC. If it succeeds, it is no longer Restrained.

The webs are flammable. Any 5-foot Cube of webs exposed to fire burns away in 1 round, dealing 2d4 Fire damage to any creature that starts its turn in the fire.

#### Weird

_Level 9 Illusion (Warlock, Wizard)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Concentration, up to 1 minute

You try to create illusory terrors in others' minds. Each creature of your choice in a 30-foot-radius Sphere centered on a point within range makes a Wisdom saving throw. On a failed save, a target takes 10d10 Psychic damage and has the Frightened condition for the duration. On a successful save, a target takes half as much damage only.

A Frightened target makes a Wisdom saving throw at the end of each of its turns. On a failed save, it takes 5d10 Psychic damage. On a successful save, the spell ends on that target.

#### Wind Walk

_Level 6 Transmutation (Druid)_

**Casting Time:** 1 minute
**Range:** 30 feet
**Components:** V, S, M (a candle)
**Duration:** 8 hours

You and up to ten willing creatures of your choice within range assume gaseous forms for the duration, appearing as wisps of cloud. While in this cloud form, a target has a Fly Speed of 300 feet and can hover; it has Immunity to the Prone condition; and it has Resistance to Bludgeoning, Piercing, and Slashing damage. The only actions a target can take in this form are the Dash action or a Magic action to begin reverting to its normal form. Reverting takes 1 minute, during which the target has the Stunned condition. Until the spell ends, the target can revert to cloud form, which also requires a Magic action followed by a 1-minute transformation.

If a target is in cloud form and flying when the effect ends, the target descends 60 feet per round for 1 minute until it lands, which it does safely. If it can't land after 1 minute, it falls the remaining distance.

#### Wind Wall

_Level 3 Evocation (Druid, Ranger)_

**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S, M (a fan and a feather)
**Duration:** Concentration, up to 1 minute

A wall of strong wind rises from the ground at a point you choose within range. You can make the wall up to 50 feet long, 15 feet high, and 1 foot thick. You can shape the wall in any way you choose so long as it makes one continuous path along the ground. The wall lasts for the duration.

When the wall appears, each creature in its area makes a Strength saving throw, taking 4d8 Bludgeoning damage on a failed save or half as much damage on a successful one.

The strong wind keeps fog, smoke, and other gases at bay. Small or smaller flying creatures or objects can't pass through the wall. Loose, lightweight materials brought into the wall fly upward. Arrows, bolts, and other ordinary projectiles launched at targets behind the wall are deflected upward and miss automatically. Boulders hurled by Giants or siege engines, and similar projectiles, are unaffected. Creatures in gaseous form can't pass through it.

#### Wish

_Level 9 Conjuration (Sorcerer, Wizard)_

**Casting Time:** Action
**Range:** Self
**Components:** V
**Duration:** Instantaneous

_Wish_ is the mightiest spell a mortal can cast. By simply speaking aloud, you can alter reality itself.

The basic use of this spell is to duplicate any other spell of level 8 or lower. If you use it this way, you don't need to meet any requirements to cast that spell, including costly components. The spell simply takes effect.

Alternatively, you can create one of the following effects of your choice:

**Object Creation.** You create one object of up to 25,000 GP in value that isn't a magic item. The object can be no more than 300 feet in any dimension, and it appears in an unoccupied space that you can see on the ground.

**Instant Health.** You allow yourself and up to twenty creatures that you can see to regain all Hit Points, and you end all effects on them listed in the _Greater Restoration_ spell.

**Resistance.** You grant up to ten creatures that you can see Resistance to one damage type that you choose. This Resistance is permanent.

**Spell Immunity.** You grant up to ten creatures you can see immunity to a single spell or other magical effect for 8 hours.

**Sudden Learning.** You replace one of your feats with another feat for which you are eligible. You lose all the benefits of the old feat and gain the benefits of the new one. You can't replace a feat that is a prerequisite for any of your other feats or features.

**Roll Redo.** You undo a single recent event by forcing a reroll of any die roll made within the last round (including your last turn). Reality reshapes itself to accommodate the new result. For example, a _Wish_ spell could undo an ally's failed saving throw or a foe's Critical Hit. You can force the reroll to be made with Advantage or Disadvantage, and you choose whether to use the reroll or the original roll.

**Reshape Reality.** You may wish for something not included in any of the other effects. To do so, state your wish to the GM as precisely as possible. The GM has great latitude in ruling what occurs in such an instance; the greater the wish, the greater the likelihood that something goes wrong. This spell might simply fail, the effect you desire might be achieved only in part, or you might suffer an unforeseen consequence as a result of how you worded the wish. For example, wishing that a villain were dead might propel you forward in time to a period when that villain is no longer alive, effectively removing you from the game.

Similarly, wishing for a Legendary magic item or an Artifact might instantly transport you to the presence of the item's current owner. If your wish is granted and its effects have consequences for a whole community, region, or world, you are likely to attract powerful foes. If your wish would affect a god, the god's divine servants might instantly intervene to prevent it or to encourage you to craft the wish in a particular way. If your wish would undo the multiverse itself, your wish fails.

The stress of casting _Wish_ to produce any effect other than duplicating another spell weakens you. After enduring that stress, each time you cast a spell until you finish a Long Rest, you take 1d10 Necrotic damage per level of that spell. This damage can't be reduced or prevented in any way. In addition, your Strength score becomes 3 for 2d4 days. For each of those days that you spend resting and doing nothing more than light activity, your remaining recovery time decreases by 2 days. Finally, there is a 33 percent chance that you are unable to cast _Wish_ ever again if you suffer this stress.

#### Word of Recall

_Level 6 Conjuration (Cleric)_

**Casting Time:** Action
**Range:** 5 feet
**Components:** V
**Duration:** Instantaneous

You and up to five willing creatures within 5 feet of you instantly teleport to a previously designated sanctuary. You and any creatures that teleport with you appear in the nearest unoccupied space to the spot you designated when you prepared your sanctuary (see below). If you cast this spell without first preparing a sanctuary, the spell has no effect.

You must designate a location, such as a temple, as a sanctuary by casting this spell there.

#### Zone of Truth

_Level 2 Enchantment (Bard, Cleric, Paladin)_

**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** 10 minutes

You create a magical zone that guards against deception in a 15-foot-radius Sphere centered on a point within range. Until the spell ends, a creature that enters the spell's area for the first time on a turn or starts its turn there makes a Charisma saving throw. On a failed save, a creature can't speak a deliberate lie while in the radius. You know whether a creature succeeds or fails on this save.

An affected creature is aware of the spell and can avoid answering questions to which it would normally respond with a lie. Such a creature can be evasive yet must be truthful.
