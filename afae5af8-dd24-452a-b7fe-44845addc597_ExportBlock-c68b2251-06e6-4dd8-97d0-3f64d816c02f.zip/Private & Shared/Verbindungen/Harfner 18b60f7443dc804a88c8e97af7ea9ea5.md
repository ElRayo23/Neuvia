# Harfner

[Schwester Garaele](https://app.notion.com/p/Schwester-Garaele-18b60f7443dc80409362c38975b383b7?pvs=21)

[Asmael Beri](https://app.notion.com/p/Asmael-Beri-18b60f7443dc80a4808dc7acb459ec56?pvs=21) 

[Sir Tikka Massala](https://app.notion.com/p/Sir-Tikka-Massala-18b60f7443dc8009b859d7a6196e9f7b?pvs=21)

[Schroppen](https://app.notion.com/p/Schroppen-18b60f7443dc80929c54f433e239914e?pvs=21)