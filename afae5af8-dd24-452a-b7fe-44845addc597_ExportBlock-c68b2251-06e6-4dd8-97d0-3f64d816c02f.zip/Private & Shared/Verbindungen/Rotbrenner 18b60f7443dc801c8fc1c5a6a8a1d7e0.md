# Rotbrenner

[Iarno Albrek Glasstab](https://app.notion.com/p/Iarno-Albrek-Glasstab-18b60f7443dc8071b260c08555bc3073?pvs=21)

[Asmael Beri](https://app.notion.com/p/Asmael-Beri-18b60f7443dc80a4808dc7acb459ec56?pvs=21)

![3a158f537be6d703c4d86f401da21983.jpg](Rotbrenner/3a158f537be6d703c4d86f401da21983.jpg)

[Velik](https://app.notion.com/p/Velik-18e60f7443dc809ab979dcfec895f8f3?pvs=21) 

![image.png](Rotbrenner/image.png)

[Shan Tal](https://app.notion.com/p/Shan-Tal-1ae60f7443dc801b856fcf89953614a3?pvs=21) 

![bc5efb8c436952188ed800e49630aca1.jpg](Rotbrenner/bc5efb8c436952188ed800e49630aca1.jpg)

[Alma](https://app.notion.com/p/Alma-1ae60f7443dc809f851eea8236f29c55?pvs=21) 

![pAVzpLzEABUmzr37Du8D--4--pjijj.webp](Rotbrenner/pAVzpLzEABUmzr37Du8D--4--pjijj.webp)

[Merry](https://app.notion.com/p/Merry-1ae60f7443dc809c88bcf61bf4be5094?pvs=21) 

![4bcdf214-7d4a-4bc0-b6c8-4ab908403843.jpg](Rotbrenner/4bcdf214-7d4a-4bc0-b6c8-4ab908403843.jpg)

[Annok](https://app.notion.com/p/Annok-1ae60f7443dc809f9818d293b6036c73?pvs=21) 

![2pESnFIITFqpLjCBWDgNmg.webp](Rotbrenner/2pESnFIITFqpLjCBWDgNmg.webp)

[Prasheen](https://app.notion.com/p/Prasheen-1ae60f7443dc8051b350e8e405f388f0?pvs=21) 

[teenage-fantasy-indian-boy-standing-full-mystique_1077802-94596.avif](Rotbrenner/teenage-fantasy-indian-boy-standing-full-mystique_1077802-94596.avif)

Name	        HP	AC	Waffe	                                     Rasse	Spellcaster?
Grimnar (M)	28	16	Greatsword	                                 Mensch	Nein
Isla (W)	        24    15	Shortbow, Dagger                     	Halbelf	Nein
Fenn (M)	        32	14	        Mace	                                Zwerg	Nein
Kaelin (M)	26	16	Rapier	                                         Elf	Ja (1 Zauber)
Briella (W)	20	13	Handaxe, Light Crossbow	        Halbling	Nein
Eldrin (M)	30	15	Quarterstaff	                          Tiefling	Ja (Zauberer)
Varun (M)	34	17	Battleaxe	                           Halb-Ork	Nein
Dalia (W)	22	14	Spear	                                Mensch	Ja (Kleriker)
Jarek (M)	26	15	Longsword                        	Mensch	Nein
Hollis (M)	18	13	Dagger, Shortbow	                 Gnom	Nein
Lira (W)	        25	14	        Scimitar	                          Halbelf	Ja (Barde)
Marek (M)	22	16	Warhammer	                        Zwerg	Nein
Talia (W)	        28	15	        Longsword	                 Mensch	Ja (Zauberin)
Gorrik (M)	30	16	Greataxe	                               Halb-Ork	Nein
Zara (W)	        24	14	        Sling, Dagger	                 Tiefling	Nein