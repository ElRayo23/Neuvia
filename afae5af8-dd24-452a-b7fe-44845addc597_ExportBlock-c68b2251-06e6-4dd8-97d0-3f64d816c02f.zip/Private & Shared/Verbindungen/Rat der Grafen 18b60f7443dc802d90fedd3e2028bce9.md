# Rat der Grafen

[Sildar Hallwinter](https://app.notion.com/p/Sildar-Hallwinter-18b60f7443dc803fa10dca7c830a25ab?pvs=21)

[Iarno Albrek Glasstab](https://app.notion.com/p/Iarno-Albrek-Glasstab-18b60f7443dc8071b260c08555bc3073?pvs=21)