# Zwergbrüder

[Sören Lackmann](https://app.notion.com/p/S-ren-Lackmann-18b60f7443dc80638856ecd65c8bbd87?pvs=21)

[Nundro](https://app.notion.com/p/Nundro-1b360f7443dc80b683e8ccca5193052a?pvs=21) 

[Tharden Felssucher](https://app.notion.com/p/Tharden-Felssucher-1b360f7443dc80579619fabe69ff4265?pvs=21)