# Bergarbeiterbörse und Finanzamt

[Halia Thornton](https://app.notion.com/p/Halia-Thornton-18b60f7443dc8071bc06f682ff089711?pvs=21) 

- sammelt jegliche Steuereinnahmen
→ aktueller Kontostand der Stadt: 250 GM
→ durchschnittliches Einkommen der Geschäfte pro Monat: 20 GM
→ durchs. Leute:  10 GM

![8c1ce55ebe96fc66c95fbf562f26a923.jpg](Bergarbeiterb%C3%B6rse%20und%20Finanzamt/8c1ce55ebe96fc66c95fbf562f26a923.jpg)