# Linenes Haus

[Elise Linene Grauwind](https://app.notion.com/p/Elise-Linene-Grauwind-18b60f7443dc801da612de36b219142c?pvs=21) 

[Ylli Daran Edermath](https://app.notion.com/p/Ylli-Daran-Edermath-18b60f7443dc80379170da044143f492?pvs=21)