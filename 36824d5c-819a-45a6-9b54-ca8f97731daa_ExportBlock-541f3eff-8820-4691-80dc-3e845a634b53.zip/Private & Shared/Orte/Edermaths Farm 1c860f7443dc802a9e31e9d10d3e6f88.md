# Edermaths Farm

[Ylli Daran Edermath](https://app.notion.com/p/Ylli-Daran-Edermath-18b60f7443dc80379170da044143f492?pvs=21) 

![2ed96f97a55f5c5a021c65c10de18141.jpg](Edermaths%20Farm/2ed96f97a55f5c5a021c65c10de18141.jpg)