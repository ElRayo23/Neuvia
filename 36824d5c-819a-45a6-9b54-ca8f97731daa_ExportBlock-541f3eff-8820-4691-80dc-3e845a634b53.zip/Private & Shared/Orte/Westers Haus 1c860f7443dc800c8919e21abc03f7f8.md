# Westers Haus

[Harbin Wester, Bürgermeister](https://app.notion.com/p/Harbin-Wester-B-rgermeister-18b60f7443dc80e880f7e4a1b96126a0?pvs=21) 

[Cacio Pepe Wester](https://app.notion.com/p/Cacio-Pepe-Wester-18f60f7443dc80eaa331ebba6751128f?pvs=21) 

[Parme Shan](https://app.notion.com/p/Parme-Shan-1ed60f7443dc80859edffa8ea5fa5b5a?pvs=21)