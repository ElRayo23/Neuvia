# Steinhügelherberge

[Tobias Steinhügel](https://app.notion.com/p/Tobias-Steinh-gel-19860f7443dc80f8a618fb919f0c4e9f?pvs=21) 

[Trilena Steinhügel](https://app.notion.com/p/Trilena-Steinh-gel-1b360f7443dc80bea49fec4e0a777649?pvs=21) 

[Pip](https://app.notion.com/p/Pip-1b360f7443dc80269fbffb0b2ebde084?pvs=21) 

[Elsa Mautherb](https://app.notion.com/p/Elsa-Mautherb-1b360f7443dc80f6b2ccd67ccd70316b?pvs=21) Mitarbeiterin

![2e8e19a5e9a227c2d9e39d8da627a4b2.jpg](Steinh%C3%BCgelherberge/2e8e19a5e9a227c2d9e39d8da627a4b2.jpg)

# **Food, Drink, and Lodging**

| Item | Cost |
| --- | --- |
| *Ale* |  |
| Gallon | 2 sp |
| Mug | 4 cp |
| Banquet (per person) | 10 gp |
| Bread, loaf | 2 cp |
| Cheese, hunk | 1 sp |
| *Inn stay (per day)* |  |
| Poor | 1 sp |
| Modest | 5 sp |
| Comfortable | 8 sp |
| *Meals (per day)* |  |
| Poor | 6 cp |
| Modest | 3 sp |
| Comfortable | 5 sp |
| Meat, chunk | 3 sp |
| *Wine* |  |
| Common (pitcher) | 2 sp |
| Finer-ish (bottle) | 3 gp |