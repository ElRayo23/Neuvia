# Schlafender Riese

[Rotbrenner](https://app.notion.com/p/Rotbrenner-18b60f7443dc801c8fc1c5a6a8a1d7e0?pvs=21) 

![dekogon-studios-1.jpg](Schlafender%20Riese/dekogon-studios-1.jpg)