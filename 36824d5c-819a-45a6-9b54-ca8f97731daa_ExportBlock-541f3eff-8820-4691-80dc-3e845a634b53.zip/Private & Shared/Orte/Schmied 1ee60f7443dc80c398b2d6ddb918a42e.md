# Schmied

[Bogo](https://app.notion.com/p/Bogo-1c860f7443dc80508795dd34dbb770dd?pvs=21) 

![63138459aa3ccd9940249fbccbaacc08.jpg](Schmied/63138459aa3ccd9940249fbccbaacc08.jpg)

![loanne-rosset-edited-smithy.jpg](Schmied/loanne-rosset-edited-smithy.jpg)