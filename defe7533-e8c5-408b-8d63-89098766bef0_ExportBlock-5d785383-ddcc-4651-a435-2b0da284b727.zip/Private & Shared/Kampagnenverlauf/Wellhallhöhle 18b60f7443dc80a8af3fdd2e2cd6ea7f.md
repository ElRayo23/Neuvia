# Wellhallhöhle

- Mienenerkundung
    - Information zu Dybbuks in Buch der Abscheulichen
    - Dybbuk Box
- Kampf gegen [Nezznar, Schwarze Spinne](https://app.notion.com/p/Nezznar-Schwarze-Spinne-18b60f7443dc80c6bf70c3ae598e1204?pvs=21)
    - [Lizznar](https://app.notion.com/p/Lizznar-18b60f7443dc80daadaaec0d82d7eb19?pvs=21) braucht Blut um Körper herzustellen
-