# Phandalin Krieg

- Große Schlacht um Phandalin, beschützt [Nezznar, Schwarze Spinne](https://app.notion.com/p/Nezznar-Schwarze-Spinne-18b60f7443dc80c6bf70c3ae598e1204?pvs=21)

- Phandalin Bewohner
- [Zhentarim](https://app.notion.com/p/Zhentarim-18b60f7443dc80369426d8e1b9b711c7?pvs=21) von [Marlin](https://app.notion.com/p/Marlin-19860f7443dc80f689bcfe4575a4812a?pvs=21) in den Büschen
- [Harfner](https://app.notion.com/p/Harfner-18b60f7443dc804a88c8e97af7ea9ea5?pvs=21) mit Schiff
- [Schroppen](https://app.notion.com/p/Schroppen-18b60f7443dc80929c54f433e239914e?pvs=21) als Captain

- Zombie [Venomfang](https://app.notion.com/p/Venomfang-18b60f7443dc808c8ae0d5c8298612f7?pvs=21)
- Cragmaw Clan
- [Rotbrenner](https://app.notion.com/p/Rotbrenner-18b60f7443dc801c8fc1c5a6a8a1d7e0?pvs=21)
- [Iarno Albrek Glasstab](https://app.notion.com/p/Iarno-Albrek-Glasstab-18b60f7443dc8071b260c08555bc3073?pvs=21)
-