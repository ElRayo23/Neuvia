# Burg Cragmaw

- [Marlin](https://app.notion.com/p/Marlin-19860f7443dc80f689bcfe4575a4812a?pvs=21) Storyline
    - [Halia Thornton](https://app.notion.com/p/Halia-Thornton-18b60f7443dc8071bc06f682ff089711?pvs=21) wird gedrängt, mit Iarno zu verhandeln
    - Halia zeigt die Papiere, Interesse der Zhents an [Nezznar, Schwarze Spinne](https://app.notion.com/p/Nezznar-Schwarze-Spinne-18b60f7443dc80c6bf70c3ae598e1204?pvs=21)
- Truppe erfährt von schwarzer Spinne durch [Marlin](https://app.notion.com/p/Marlin-19860f7443dc80f689bcfe4575a4812a?pvs=21) oder [Rotbrenner](https://app.notion.com/p/Rotbrenner-18b60f7443dc801c8fc1c5a6a8a1d7e0?pvs=21)
- Wildnis

Wurf bei Tag Wurfbei Nacht Ergebnis
1-2 1-3 Blutmücken (lW8 + 2)
4 Ghule (lW4 + l)
3-4 Oger (l)
5-6 5 Goblins (lW6 + 3)
7-8 6 Hobgoblins (lW4 + 2)
9-10 7-8 Orks (lW4 + 2)
11 9-10 Wölfe (lW4 + 2)
12 11-12 Eulenbär (l)

- Ruinen von Donnerbaum von [Qelline Alderblatt](https://app.notion.com/p/Qelline-Alderblatt-18b60f7443dc80ee8043d7ac4e4ebf71?pvs=21)
1. Hütte mit 2 Zweigplagen (stealth für Plagen gegen passive perc)
2. Hütte mit 6 (DC 14)
3. Braunes Pferd 4 Aschezombies mit Aschewolke
4. Druidenwacht, kleines Feuer
→ Dorf wurde vor 30 Jahren verwüstet
- [Hoppi Gallopi](https://app.notion.com/p/Hoppi-Gallopi-18b60f7443dc8048a61bc8ca74157095?pvs=21) ist ein Pegasus

- Alter Eulenbrunnen von [Ylli Daran Edermath](https://app.notion.com/p/Ylli-Daran-Edermath-18b60f7443dc80379170da044143f492?pvs=21) 
→ Begegnung mit [Hamun Kost](https://app.notion.com/p/Hamun-Kost-1bb60f7443dc80d59eb9f9d4821acb0c?pvs=21) 
→ Die Truppe soll Orks in Wyvernkuppe entfernen und Agatha für ihn fragen, wer den Turm erbaut hat

        → [Hamun Kost](https://app.notion.com/p/Hamun-Kost-1bb60f7443dc80d59eb9f9d4821acb0c?pvs=21) kennt sich mit dybbuks aus

- [Agon](https://app.notion.com/p/Agon-1b260f7443dc8001af0fc6fa7a3a0cab?pvs=21) macht Geschäft in Phandalin auf
- trifft auf [Hoppi Gallopi](https://app.notion.com/p/Hoppi-Gallopi-18b60f7443dc8048a61bc8ca74157095?pvs=21)
- Einbruch
    - [Iarno Albrek Glasstab](https://app.notion.com/p/Iarno-Albrek-Glasstab-18b60f7443dc8071b260c08555bc3073?pvs=21) dort (falls novh am leben)