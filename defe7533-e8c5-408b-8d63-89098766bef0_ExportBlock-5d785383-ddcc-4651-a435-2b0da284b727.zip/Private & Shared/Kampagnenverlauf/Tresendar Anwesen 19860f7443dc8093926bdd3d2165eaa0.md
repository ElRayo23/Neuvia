# Tresendar Anwesen

- Conyberry und Agathas Behausung von [Schwester Garaele](https://app.notion.com/p/Schwester-Garaele-18b60f7443dc80409362c38975b383b7?pvs=21) 
→ Agatha DC15 persuasion
→ nur eine Frage wird beantwortet
- Lach game, 1d6 wenn man lachen muss

- Einbruch entweder durch Geheimgang oder Vordertür
- Vorne bewacht von [Shan Tal](https://app.notion.com/p/Shan-Tal-1ae60f7443dc801b856fcf89953614a3?pvs=21) [Annok](https://app.notion.com/p/Annok-1ae60f7443dc809f9818d293b6036c73?pvs=21) [Velik](https://app.notion.com/p/Velik-18e60f7443dc809ab979dcfec895f8f3?pvs=21) [Prasheen](https://app.notion.com/p/Prasheen-1ae60f7443dc8051b350e8e405f388f0?pvs=21) [Asmael Beri](https://app.notion.com/p/Asmael-Beri-18b60f7443dc80a4808dc7acb459ec56?pvs=21)
- Familie Dendrar im Verließ, Frau tot, Mann und Kind am Leben
- wenn sie den Raum von [Iarno Albrek Glasstab](https://app.notion.com/p/Iarno-Albrek-Glasstab-18b60f7443dc8071b260c08555bc3073?pvs=21) finden, castet er Dunkelheit und rennt weg
- in seinem Büro liegen Papiere
→ Brief an [Nezznar, Schwarze Spinne](https://app.notion.com/p/Nezznar-Schwarze-Spinne-18b60f7443dc80c6bf70c3ae598e1204?pvs=21) 
Gestank von Schwefel von Hoppi erkennbar
Info über [Sören Lackmann](https://app.notion.com/p/S-ren-Lackmann-18b60f7443dc80638856ecd65c8bbd87?pvs=21) 
→ Brandweingeschäfte des schlafenden Riesen
→ Handelsrouten und Zeiten der Löwenschild, Barthens und [Halia Thornton](https://app.notion.com/p/Halia-Thornton-18b60f7443dc8071bc06f682ff089711?pvs=21)
→ Bürgermeisterbriefe mit Stempel
- er wird verfolgt bis er die 5 weiteren Rotbrenner draußen findet
- “Meine restliche Truppe ist in der Stadt/schlafen, ich rufe sie” aber wird von Asmas Silence gehindert
- Truppe und Asma vs Iarno und Rotbrenner (5 vs 5)