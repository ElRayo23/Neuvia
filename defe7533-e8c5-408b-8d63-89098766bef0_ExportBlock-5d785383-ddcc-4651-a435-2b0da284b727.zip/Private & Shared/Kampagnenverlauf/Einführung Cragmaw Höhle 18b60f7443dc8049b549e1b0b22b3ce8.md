# Einführung/Cragmaw Höhle

Grob:

- Uky und Schroppen
- Zwerge treffen auf Uky in Jagd
- Tikka Introduction
- Tikka angeheuert
- Uky nach der Jagd
- Uky trifft auf Hoppi
- Treffen vor der Taverne
- Temoe Introduction
- Tavernen Shit happening
→ Ukys Dad
→ Anmache von einer betrunkenen Zwergenfrau Temoe und Uky gegenüber
- Überfall von Goblins
- Ochsen bewegen, losfahren
- Spur nachgehen/Phandalin reisen
- Cragmaw Höhle

Erste Sitzung:

Fühling. Ein metallisches Rostgitter liegt auf dem bewaldeten Boden und eine Spinne krabbelt darauf (Hinweis auf Ende). Spätfrühlingsmorgen, im Wald in einer Hütte wo Rauch raussteigt. (Hütte beschreiben, mit Teich). Ein Tortle sitzt am Terrassentisch und trinkt aus einer Porzellantasse. Aus der Tür in die Terrasse kommt jemand (Uky beschreiben).

„Da ist jemand früh wach.“

Zur Jagd schicken, Im Wald ein Kaninchen AC 13 zum Treffen (Stealth check DC15 dann Vorteil, oder vom Weitem)

![ed97f5d630fcaa28548e8a245c8a05d6.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/ed97f5d630fcaa28548e8a245c8a05d6.jpg)

Sören und Sildar tauchen auf: 

Guter Schütze, gefährlicher Wald aber

 fragen ob du eine Fracht von Niewinter nach Phandalin begleiten kannst, Belohnung 100 GP für die Truppe

Dann heute Abend in der Taverne „Bier um Drei“

![chris-dien-concept-env-pe-market-v3.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/chris-dien-concept-env-pe-market-v3.jpg)

In der hitzigsten Sonne, 2 Stunden später auf dem Markt, diskutiert ein Gallus mit einer Verkäuferin Elfe über den Preis der Äpfel. 4 Silber für 5 Pfund (2,3 Kilo) (Leonies Character).

„Es tut mir leid, unsere Äpfel sind aber vom feinster Auslese, wir können Ihnen nicht weiterhelfen“

Sören und Sildar laufen vorbei und reden : perception check 10 um Gespräch zu hören

(bemerken dich)

Uky reist nach der Jagd zurück zu Schroppen, Mittagssuppe ist fertig mit Kräutern und Weißbrot. Unterhaltung und dann Geschenk Bogen -> neu mit einer kleinen Harfe

Wenn die kleine Mondharfe gespielt wird, gewährt das Truesight

Während du nach draußen läufst in den Nachmittag hinein, begegnet dir ein Pferd auf dem Weg, was regungslos am Straßenrand liegt. (Gallopi Introduction)

Am späten Nachmittag sammeln sich alle vor der Taverne. Nun sind 3 kleine Leute da: Sören, Sildar und Temoe.

In der Taverne:

rappelvoll, viele Zwerge, Schmiede, Schreiner

Unter anderem Ukys Vater [Fauna Gwi](https://app.notion.com/p/Fauna-Gwi-19360f7443dc80308447c4b4b29829a5?pvs=21) bei perception 10

Überhört von nem Tisch von Dieben, über den Waldteil der klingelt, die alle mit Pfeilen abschießr

---

---

schnell handeln

Am nächsten Morgen:

Zettel von Sören: “Zu Barthens Vorräten in Phandalin bringen”

Ochsen bewegen/anleinen/losfahren  DC12 -> der Erfolgreiche muss Wagen lenken

Wagen mit Bergbauausrüstung und Lebensmittel → Gesamtwert: 200GM

Karre langsam, man könnte nebenbei laufen

falls jemand natur beobachtet, beinlose Krähe mit weißem Schnabel sieht sie an während sie ne tote Maus frisst

![210cd4f76dea2b00112f2d65afcd33b5.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/210cd4f76dea2b00112f2d65afcd33b5.jpg)

Den Weg beschreiben, 

Warm, nett
Hoppi eine feder, tut weh wenn man sie zieht

dann die toten Pferde mit schwarzen Pfeilen (investiagtion dc 14)

Biegung: Kampf gegen 4 Goblins, 2 Fernkämpfer (6 HP) und 2 Nahkämpfer (7 HP)

> ***Schlinge**.*
> 

*10 Minuten
Wenn die Charaktere nach Fallen suchen, dann entdeckt der
Charakter an der Spitze der Gruppe die Falle automatisch, wenn
sein passiver Wert in Weisheit (Wahrnehmung) 12 oder höher ist.*

*Ansonsten muss der Charakter einen Wurf auf Weisheit (Wahrnehmung) gegen SG 12 schaffen, um die Falle zu bemerken.
Wenn der Charakter die Falle nicht bemerkt, löst er die Schlinge
aus und muss einen Geschicklichkeitsrettungswurf gegen SG
10 schaffen.* 

*Bei einem Fehlschlag hängt der Charakter kopfüber
3 Meter über dem Boden. Der Charakter ist festgesetzt, bis der
Schlinge 1 oder mehr Hiebschaden zugefügt worden sind. (Die
Auswirkungen des Zustands festgesetzt findest du im Anhang
des Regelbuchs.) Ein Charakter, der nicht vorsichtig herunter
gelassen wird, erleidet 1 W6 Wuchtschaden durch den Sturz.

**Grube**. Weitere 10 Minuten auf dem Pfad später befindet
sich eine Grube, die die Goblins getarnt haben. Die Grube ist 2
Meter breit, 3 Meter tief und wird ausgelöst, wenn eine Kreatur
sich über sie bewegt.* 

*Der Charakter an der Spitze entdeckt die
verborgene Gruppe automatisch, wenn seine passive Weisheit
(Wahrnehmung) bei 15 oder höher liegt.* 

*Ansonsten muss der
Charakter einen Wurf auf Weisheit (Wahrnehmung) gegen SG 15
schaffen, um die verborgene Grube zu bemerken. Wenn die Falle
nicht entdeckt wird, muss der Charakter an der Spitze einen
Geschicklichkeitsrettungswurf gegen SG 10 schaffen, um nicht
in die Grube zu fallen und 1 W6 Wuchtschaden zu erleiden. Die
Wände der Grube sind nicht steil, und es ist kein Attributswurf
notwendig, um wieder heraus zu kommen.*

> *Wenn die Charaktere einen der Goblins hier gefangen nehmen
oder bezaubern, dann kann er überzeugt werden, einige nützliche
1 nformationen herauszugeben:
• In der Höhle leben im Augenblick weniger als 20 Goblins.
• Ihr Anführer ist ein Grottenschrat namens Klarg. Er untersteht
König Grol, dem Häuptling des Cragmaw-Stammes, welcher sich
auf Burg Cragmaw aufhält. (Die Goblins können eine allgemeine
Beschreibung der Lage von Burg Cragmaw liefern. Sie liegt
ungefähr 30 Kilometer nordöstlich des Cragmaw-Verstecks im
Niewinterwald.)
• Klarg hat vor einigen Tagen einen Goblinbotschafter von König
Grol empfangen. Der Botschafter hat ihm gesagt, dass jemand
namens Schwarze Spinne die Cragmaws bezahlt, um nach dem
Zwerg Gundren Felssucher Ausschau zu halten, ihn gefangen zu
nehmen und ihn und alles, was er bei sich trägt, zu König Gral
zu bringen. Klarg folgte diesen Anweisungen. Gundren wurde
überfallen und zusammen mit seinen persönlichen Besitztümern,
darunter auch eine Karte, mitgenommen.
• Der Zwerg und seine Karten wurden wie angewiesen zu König
Grol gebracht. Der menschliche Gefährte des Zwergen wird in der
,,Esshöhle" (Bereich 6) gefangen gehalten.*
> 

https://www.owlbear.rodeo/profile

![2018-07-23-goblin.png](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/2018-07-23-goblin.png)

jacob

Leonie

Basti

Schützen

Leonard

S1 3

![Goblins-34919312-1642193253580.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/Goblins-34919312-1642193253580.jpg)

Je nach Entscheidung, Cragmaw Höhle 

> *Die Cragmaw-Höhle neigt sich steil nach oben. Der Eingang liegt
am Fuße eines großen Hügels und die Höhlen und Durchgänge
befinden sich im Inneren des Hügels selbst.*
> 

***Decken**. Die meisten Höhlen und Durchgänge haben steil
geneigte Decken, die mit Stalaktiten bedeckte Kuppeln 6 bis 9
Meter über dem Boden bilden.*

*Licht. Die Bereiche 1 und 2 liegen im Freien. Der Rest des
Komplexes ist dunkel, wenn nichts anderes erwähnt ist. Die
Textkästen für diese Örtlichkeiten gehen davon aus, dass die
Charaktere Dunkelsicht oder eine Lichtquelle haben.*

***Geröll**. Bereiche von bröckelndem Fels und Geröll sind schwieriges Gelände (siehe „schwieriges Gelände" im Regelbuch).
Geräusche. Die Geräusche des Wassers in der Höhle überdecken Geräusche für alle Kreaturen, die nicht genau hinhören.
Kreaturen können einen Wurf auf Weisheit (Wahrnehmung)
gegen SG 15 ablegen, um zu überprüfen, ob sie in nahen Kammern Aktivität hören können.*

***Stalagmiten**. Diese nach oben zeigenden Felsspitzen können
Deckung bieten (siehe „Deckung" im Regelbuch).*

***Bach**. Der Bach, der durch den Komplex fließt, ist nur ungefähr 60 Zentimeter tief, kalt und langsam, sodass Kreaturen
ohne Probleme hindurch waten können.*

![Cragmaw-Hideout-Thumbnail.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/Cragmaw-Hideout-Thumbnail.jpg)

![ca3c671b03e33c5d53b5b5447c2929aa.jpg](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/ca3c671b03e33c5d53b5b5447c2929aa.jpg)

![original.png](Einf%C3%BChrung%20Cragmaw%20H%C3%B6hle/original.png)

1. Truppe muss Stealth gegen Goblin Passive Perception 9, sonst Angriff
2. Goblins haben halbe Deckung also AC +2
3. 3 Wölfe, Animal Handling DC15 sonst
→ Wölfe sauer, Strength Check der Ketten DC15 dann 10
→ Dünne Spalte zu 8, DC10 athletic oder acrobatics
→ einer der Wölfe ist verwundet und zombiemäßig, lächelt an und mit weißem Kopf [Lizznar](https://app.notion.com/p/Lizznar-18b60f7443dc80daadaaec0d82d7eb19?pvs=21), DC20 um zu erkennen, dass es sich um ein anderes Wesen handelt
→ [Hoppi Gallopi](https://app.notion.com/p/Hoppi-Gallopi-18b60f7443dc8048a61bc8ca74157095?pvs=21) riecht starke Verwesung und Schwefel
4. Hier dunkelsicht → Man sieht Brücke 5
→ Perception Check wenn Stealthy ohne Licht
→ Stealth Check mit Licht (Nachteil)
→ Steingeröll macht es schwer 
5. Brücke 6m hoch, DC15 zu klettern, AC 5, 10 HP
→ Wenn sie fällt, DC10 oder 2d6 fall damage
→ wenn chars von Goblin bemerkt, dann Überflutung
→ Strength Check DC 13 sonst zurück geschwemmt
→ zweite Welle nur, wenn erste Welle Eindringlinge nicht abhält
6. Goblings chill spot, 5 Goblins und 1 Anführer [Yeemik](https://app.notion.com/p/Yeemik-19760f7443dc804dbd81d6a56518128a?pvs=21) mit 12 HP
→ [Sildar Hallwinter](https://app.notion.com/p/Sildar-Hallwinter-18b60f7443dc803fa10dca7c830a25ab?pvs=21) wird hier gefangen gehalten
→ wenn kampf und oberhand, dann drohung sildar umzubringen
→ Verhandlung damit [Klarg, der Grottenschrat](https://app.notion.com/p/Klarg-der-Grottenschrat-19360f7443dc80a1a7ddf36a891c4c89?pvs=21) stirbt, Sildar warnt
→ wenn nicht verhandeln, dann wird Sildar abgestochen
→ Yeemik hat 3 Goldzähne und 15 SM dabei
7. Hier chillt der Wassergoblin
8. Klargs Höhle mit Klarg, Wolf Reißer und 3 Goblins
→ Haufen Säcke und Kisten mit Löwenschild Symbol [Elise Linene Grauwind](https://app.notion.com/p/Elise-Linene-Grauwind-18b60f7443dc801da612de36b219142c?pvs=21) 
→ Klarg wird verabscheut, weil er egomaniac ist
→ Klarg: [König Grol](https://app.notion.com/p/K-nig-Grol-18b60f7443dc8008a296e8e1246b22e3?pvs=21) wird euch vernichten

Loot: Vorräte von Elise zurückbringen 50 GM, Klarg hat Schatz mit 600 GM, 110 SM, zwei Heiltränke und eine Jadestatuette eines Froschs 40 GM wert
→ Nachricht: [Sören Lackmann](https://app.notion.com/p/S-ren-Lackmann-18b60f7443dc80638856ecd65c8bbd87?pvs=21) wird nach Burg Cragmaw beliefert

———- Level up ———————