# Phandalin

![15m.png](Phandalin/15m.png)

![d3f241b31f1f7bc1057011d459448bc0.jpg](Phandalin/d3f241b31f1f7bc1057011d459448bc0.jpg)

Grob: 

- Vision von [Uky Gwi](https://app.notion.com/p/Uky-Gwi-18b60f7443dc8033bb94cb3e4cd3604b?pvs=21) wie er von Velik zsmgeschlagen wird
- Truppe trifft auf [Harbin Wester, Bürgermeister](https://app.notion.com/p/Harbin-Wester-B-rgermeister-18b60f7443dc80e880f7e4a1b96126a0?pvs=21)
→ gemeinsam mit Sildar zum Bürgermeister, um von den Goblins und Sören zu berichten
→ verheimlicht Veliks Anwesenheit DC10 Insight Check
→ “Sildar, hol dir dein Geld (was er später der Truppe gibt) von [Halia Thornton](https://app.notion.com/p/Halia-Thornton-18b60f7443dc8071bc06f682ff089711?pvs=21) ab”
→ “wenn Interesse an Jobs, meldet euch” (Gefahr beseitigen)
→ aufm Marktplatz 4 aufgehängte Puppen mit Schrift “Fremde nicht willkommen”

- [Halia Thornton](https://app.notion.com/p/Halia-Thornton-18b60f7443dc8071bc06f682ff089711?pvs=21) trifft Truppe und [Temoe](https://app.notion.com/p/Temoe-18b60f7443dc80cbae16c30c0102ba20?pvs=21)
→ gibt Sildar sein Geld, schreibt in der Liste
→ fragt Abenteurer, was sie in der Stadt suchen
→ macht Geschäfte der Stadt, Poststation und Finanzamt
→ sie sollen die Rotbrenner nicht verärgern aber falls doch, dann richtig
→ sie sollen Glasstab finden und all seine Briefe/Papiere zu ihr bringen, sie macht Insight Check ⇒ “ich schaue, was ich aus der Stadtkasse locker machen kann(100GM)”
- [Schwester Garaele](https://app.notion.com/p/Schwester-Garaele-18b60f7443dc80409362c38975b383b7?pvs=21) trifft [Sir Tikka Massala](https://app.notion.com/p/Sir-Tikka-Massala-18b60f7443dc8009b859d7a6196e9f7b?pvs=21)
→ am Schrein des Glücks zu finden, pflegt es
→ “Seid willkommen im schönen Phandalin!”
→ Auftrag, das Buch des Abscheulichen ([Arthindol](https://app.notion.com/p/Arthindol-1bb60f7443dc802bbf20e023e78ecdcc?pvs=21)) zu erfragen (Conyberry und Agathas Behausung)
→ Garaele kennt nur Namen des Buchs und dass der Autor ein geskillter Nekromant war
    - Fragt, [Sir Tikka Massala](https://app.notion.com/p/Sir-Tikka-Massala-18b60f7443dc8009b859d7a6196e9f7b?pvs=21) ob er harfe spielt

- Truppe trifft auf [Elise Linene Grauwind](https://app.notion.com/p/Elise-Linene-Grauwind-18b60f7443dc801da612de36b219142c?pvs=21)
→ wenn mit Vorräte, kommt der Vater [Ylli Daran Edermath](https://app.notion.com/p/Ylli-Daran-Edermath-18b60f7443dc80379170da044143f492?pvs=21) und bietet Unterkunft bei [Edermaths Farm](https://app.notion.com/p/Edermaths-Farm-1c860f7443dc802a9e31e9d10d3e6f88?pvs=21)  an
→ Vermeidet Bierhalle Schlafender Riese
→ Löwenschild bietet Waffen
→ Alter Eulenbrunnen wird für die Lieferanten unheimlich; sodass weniger Lieferungen

- Rabe mit weißem Schnabel beobachtet

- Truppe auf [Elmar Barthen](https://app.notion.com/p/Elmar-Barthen-18b60f7443dc801980f6d942e0d9ae6c?pvs=21)
→ größter Handelsposten
→ deckt alltäglichen Bedarf
→ Lehrling [Cacio Pepe Wester](https://app.notion.com/p/Cacio-Pepe-Wester-18f60f7443dc80eaa331ebba6751128f?pvs=21) 
→ ermutigt Truppe, Sören zu finden
→ zwei weitere Felssucher-Brüder, [Nundro](https://app.notion.com/p/Nundro-1b360f7443dc80b683e8ccca5193052a?pvs=21) und [Tharden Felssucher](https://app.notion.com/p/Tharden-Felssucher-1b360f7443dc80579619fabe69ff4265?pvs=21) , irgendwo außerhalb der Stadt kampieren. Barthen hat sie seit zehn Tagen nicht mehr gesehen und rechnet damit, dass sie „jeden Tag" zurückkehren müssten, um neue Vorräte zu kaufen

- Auf der Straße spielen 4 Kinder
→ [Molly](https://app.notion.com/p/Molly-1ed60f7443dc8084a409ff66ad0b6d89?pvs=21)  ”Ich habe den Eingang zum Anwesen der Rotbrenner gefunden und habe dort ein Monster gesehen mit weißem Gesicht”

- Truppe trifft auf [Rotbrenner](https://app.notion.com/p/Rotbrenner-18b60f7443dc801c8fc1c5a6a8a1d7e0?pvs=21) entweder beim Schlafenden Riesen oder auf der Straße
    - Wenn Straße, ist [Pip](https://app.notion.com/p/Pip-1b360f7443dc80269fbffb0b2ebde084?pvs=21) dabei, sein Spielzeug wird kaputtgemacht
    - roter weiter Schal, [Merry](https://app.notion.com/p/Merry-1ae60f7443dc809c88bcf61bf4be5094?pvs=21) [Alma](https://app.notion.com/p/Alma-1ae60f7443dc809f851eea8236f29c55?pvs=21) [Prasheen](https://app.notion.com/p/Prasheen-1ae60f7443dc8051b350e8e405f388f0?pvs=21)  Rotbrenner:
    Und zusätzlich: [Velik](https://app.notion.com/p/Velik-18e60f7443dc809ab979dcfec895f8f3?pvs=21) und die Amsel
    - Velik motzt Uky an “du bist ne Schande, dass du dich hier überhaupt blicken lässt”
    - Nähert sich an aber Amsel stoppt das

- Temoe muss bei Halia Zahlung 100GM von Iarno abholen

→ bevor alle rausgehen, Temoe behalten und sagen “Abschaum erkennt sich gegenseitig”

- “Was machst du hier? Verdächtig, wenn noch ein Zhent hier ist” Insight DC 12 sie ist gestresst
- “Komm mir nicht in die Quere”
- Perception 16
- Briefe von [Marlin](https://app.notion.com/p/Marlin-19860f7443dc80f689bcfe4575a4812a?pvs=21) “Die Zhents werden bald in Phandalin einmarschieren”

- [Tobias Steinhügel](https://app.notion.com/p/Tobias-Steinh-gel-19860f7443dc80f8a618fb919f0c4e9f?pvs=21) Begegnung
    - [Trilena Steinhügel](https://app.notion.com/p/Trilena-Steinh-gel-1b360f7443dc80bea49fec4e0a777649?pvs=21) (Leonard kriegt Flashback) redet [Freda Makka](https://app.notion.com/p/Freda-Makka-1b360f7443dc80e295edfa592cb0022c?pvs=21) über Dendrar (direkt am Anfang von 2 Monaten, eine Woche da, Frau wurde angemacht, Mann hat sich quer gestellt, ganze Familie entführt und Mann zusammengeschlagen)(bei Halia hätten sie sich nicht getraut)
    - [Lanar Makka](https://app.notion.com/p/Lanar-Makka-1b360f7443dc80dabe43ffaa8956efc1?pvs=21) und [Elsa Mautherb](https://app.notion.com/p/Elsa-Mautherb-1b360f7443dc80f6b2ccd67ccd70316b?pvs=21) über Garaele und Edermath Gerüchte

- Eine Nacht, wird die Truppe wach von Alpträumen: [Lizznar](https://app.notion.com/p/Lizznar-18b60f7443dc80daadaaec0d82d7eb19?pvs=21)
    - Tikka:
    - Hoppi:
    - Uky: von [Velik](https://app.notion.com/p/Velik-18e60f7443dc809ab979dcfec895f8f3?pvs=21) geschlagen
    - Temoe:

Nächsten Tag, sind Federn an [Hoppi Gallopi](https://app.notion.com/p/Hoppi-Gallopi-18b60f7443dc8048a61bc8ca74157095?pvs=21) 
[Sir Tikka Massala](https://app.notion.com/p/Sir-Tikka-Massala-18b60f7443dc8009b859d7a6196e9f7b?pvs=21) hat Detect Thoughts

- [Pip](https://app.notion.com/p/Pip-1b360f7443dc80269fbffb0b2ebde084?pvs=21) Spielzeug ist wieder heile, über Nacht
- Schwester Garaele hat Brief von einem der Rotbrenner und soll es weitergeben
    - “Heute Nacht sollen Edermath und Grauwind entführt werden. Sie kommen zu fünft, Nachtschicht im Anwesenkeller sind 2 weitere und Iarno. 10 schlafen in isolierter Reichweite, der Rest verreist. Tut was nötig ist”
- Rotbrenner entführen Familie, wo Truppe unterkommt, während Truppe weg
→ Nachricht “Die Einwohnerzahl darf nicht steigen. Entweder ihr geht aus der Stadt oder diese Familie geht in den Tod.”

![Phandalin-Background.webp](Phandalin/Phandalin-Background.webp)

![Phandalin.webp](Phandalin/Phandalin.webp)