# Dateien/sonstiges

[https://dungeonmastertools.github.io/items.html](https://dungeonmastertools.github.io/items.html) Preise etc

[https://www.aidedd.org/dnd-statblock/index-5e.php](https://www.aidedd.org/dnd-statblock/index-5e.php) stat generator

sollte Summe CR < 1/4 Summe Levels bzw halb über Lvl 5

[Wirtschaft](Dateien%20sonstiges/Wirtschaft%201ee60f7443dc808494fff50628b8113e.md)

[einzuordnen](Dateien%20sonstiges/einzuordnen%2020560f7443dc80efa334cd465a12f255.md)