# Elmar Barthen

![ea47734542168d9fcbaae04c7dc4cece.jpg](Elmar%20Barthen/ea47734542168d9fcbaae04c7dc4cece.jpg)

Redet schnell, Geschäftsmann

mitte 50