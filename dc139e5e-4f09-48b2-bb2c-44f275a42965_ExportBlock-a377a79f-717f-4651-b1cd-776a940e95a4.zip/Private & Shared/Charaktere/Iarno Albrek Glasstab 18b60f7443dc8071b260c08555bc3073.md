# Iarno Albrek Glasstab

![cbc12c0204ceb10c7a3fd5d3593fb804.jpg](Iarno%20Albrek%20Glasstab/cbc12c0204ceb10c7a3fd5d3593fb804.jpg)

[https://5e.tools/bestiary/iarno-glasstaff-albrek-pabtso.html](https://5e.tools/bestiary/iarno-glasstaff-albrek-pabtso.html)

### **Iarno Albrek (CR 2)**

- **Race:** Human
- **Class:** Wizard (Level 3)
- **Challenge Rating (CR):** 2
- **HP:** 21 (6d6)
- **AC:** 12 (with **Mage Armor**)
- **Movement:** 30 feet
- **Gender:** Male

---

### **Attributes:**

- **Strength:** 10 (+0)
- **Dexterity:** 14 (+2)
- **Constitution:** 14 (+2)
- **Intelligence:** 16 (+3)
- **Wisdom:** 11 (+0)
- **Charisma:** 13 (+1)

---

### **Skills:**

- **Saving Throws:** Intelligence +5, Wisdom +2
- **Skills:** Arcana +5, Perception +2

---

### **Spells:**

**Cantrips (Level 0 Spells):**

- **Fire Bolt**: A ranged spell attack dealing **1d10 fire damage**.
- **Mage Hand**: Creates a spectral hand to manipulate objects.
- **Prestidigitation**: Performs minor magical effects like cleaning or lighting small objects.

**1st-Level Spells (4 Spell Slots):**

- **Mage Armor**: Grants the target **+3 AC** for 8 hours (typically cast on himself).
- **Shield**: A reaction spell that adds **+5 AC** for 1 round, making Iarno harder to hit.
- **Magic Missile**: Creates **3 magical darts** that automatically hit, each dealing **1d4+1 force damage**.
- **Detect Magic**: Detects magic within 30 feet for up to 10 minutes.

**2nd-Level Spells (2 Spell Slots):**

- **Mirror Image**: Creates **3 duplicates** of Iarno, making him harder to hit. Attacks have a chance to hit the duplicates instead.
- **Misty Step**: A bonus action spell that teleports Iarno **30 feet** to an unoccupied space he can see.
- Silence:

---

### **Actions:**

- **Dagger (Melee):** +2 to hit, **1d4+2 piercing damage**
- **Spellcasting (Bonus Action):** Iarno can cast **Misty Step** or **Shield** as a bonus action when needed.