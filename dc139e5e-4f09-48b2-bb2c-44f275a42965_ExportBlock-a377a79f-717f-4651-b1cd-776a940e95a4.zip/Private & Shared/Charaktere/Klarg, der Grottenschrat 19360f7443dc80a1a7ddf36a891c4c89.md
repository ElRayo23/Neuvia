# Klarg, der Grottenschrat

Untergeben [König Grol](K%C3%B6nig%20Grol%2018b60f7443dc8008a296e8e1246b22e3.md) 

Herrschaft über Cragmaw Höhle

![4d4df6902acde020f21b601532b5430d.jpg](Klarg,%20der%20Grottenschrat/4d4df6902acde020f21b601532b5430d.jpg)

![bugbear_stat_block.jpg](Klarg,%20der%20Grottenschrat/bugbear_stat_block.jpg)