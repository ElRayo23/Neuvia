# Sildar Hallwinter

![sildar-hallwinter-lost-mine-of-phandelver-v0-w28vd3d1y3gd1.webp](Sildar%20Hallwinter/sildar-hallwinter-lost-mine-of-phandelver-v0-w28vd3d1y3gd1.webp)

- herzensguter menschlicher Mann
- 50 Jahre alt
- Ehrenplatz in Greifenkavallerie von Tiefwasser
- Agent des [Rat der Grafen](https://app.notion.com/p/Rat-der-Grafen-18b60f7443dc802d90fedd3e2028bce9?pvs=21)
- sucht nach [Iarno Albrek Glasstab](Iarno%20Albrek%20Glasstab%2018b60f7443dc8071b260c08555bc3073.md), weil er verschwunden ist als er in [Phandalin](https://app.notion.com/p/Phandalin-18b60f7443dc806e9f05cec6606cd5db?pvs=21) auftauchte
- [Zwergbrüder](https://app.notion.com/p/Zwergbr-der-18b60f7443dc80ff9d7fc4f96b74bbeb?pvs=21) haben [Wellhallhöhle](https://app.notion.com/p/Wellhallh-hle-18b60f7443dc80a8af3fdd2e2cd6ea7f?pvs=21) Eingang gefunden

Nach Überfall/Entführung

- [Klarg, der Grottenschrat](Klarg,%20der%20Grottenschrat%2019360f7443dc80a1a7ddf36a891c4c89.md) hatte Befehl, Sören zu überfallen. Von goblins gehört, dass schwarze Spinne Sören will aber keine Ahnung was schwarze Spinne ist
- Sören hatte Karte mit, aber wurde entwendet und dem [König Grol](K%C3%B6nig%20Grol%2018b60f7443dc8008a296e8e1246b22e3.md) geschickt in [Burg Cragmaw](https://app.notion.com/p/Burg-Cragmaw-18b60f7443dc8098bec3f8e5164ab50b?pvs=21)
- [Iarno Albrek Glasstab](Iarno%20Albrek%20Glasstab%2018b60f7443dc8071b260c08555bc3073.md) Kontaktperson in Phandalin

### **Armor Class**

16 (chain mail)

### **Hit Points**

27 (5d8+5)

### **Speed**

30 ft.

### **STR**

13 (+1)

### **DEX**

10 (0)

### **CON**

12 (+1)

### **INT**

10 (0)

### **WIS**

11 (0)

### **CHA**

10 (0)

### **Saving Throws**

Str +3, Con +3

### **Skills**

Perception +2

### **Languages**

Common

### **Challenge**

1 (200 XP)

### Actions

***Multiattack.*** Sildar makes two melee attacks.

***Longsword.*** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) slashing damage.

***Heavy Crossbow.*** Ranged Weapon Attack: +2 to hit, range 100 ft./400 ft., one target. Hit: 5 (1d10) piercing damage.

### Reactions

***Parry.*** When an attacker hits Sildar with a melee attack and Sildar can see the attacker, he can roll 1d6 and add the number rolled to his AC against the triggering attack, provided that he’s wielding a melee weapon.