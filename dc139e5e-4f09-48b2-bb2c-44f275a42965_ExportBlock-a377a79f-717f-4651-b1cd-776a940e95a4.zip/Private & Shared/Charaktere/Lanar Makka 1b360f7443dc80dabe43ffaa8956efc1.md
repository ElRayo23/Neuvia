# Lanar Makka

![d55960eab65fa2abc3010879028a33c8.jpg](Lanar%20Makka/d55960eab65fa2abc3010879028a33c8.jpg)

ein Bergarbeiter: ,,Ork-Plünderer sind am Ostende des
Dreieber-Pfads gesichtet worden. Der Stadtvorsteher sucht
nach jemandem, der sie vertreiben kann."