# Sir Tikka Massala

[Leonie.pdf](Sir%20Tikka%20Massala/Leonie.pdf)

Kennt  [Schwester Garaele](Schwester%20Garaele%2018b60f7443dc80409362c38975b383b7.md) , [Asmael Beri](Asmael%20Beri%2018b60f7443dc80a4808dc7acb459ec56.md)  und [Schroppen](Schroppen%2018b60f7443dc80929c54f433e239914e.md) , Mitglieder von [Harfner](https://app.notion.com/p/Harfner-18b60f7443dc804a88c8e97af7ea9ea5?pvs=21) 

[Rotbrenner](https://app.notion.com/p/Rotbrenner-18b60f7443dc801c8fc1c5a6a8a1d7e0?pvs=21)  sollen infiltriert/untersucht werden, um Schwachpunkte und Verbindungen auszumachen

 [Schwester Garaele](Schwester%20Garaele%2018b60f7443dc80409362c38975b383b7.md) seit 2 Jahren auf Mission, Suche nach dem Buch-> die letzten 2 Monaten mit Rotbrennern schwierig, daher hat sie um Verstärkung gebeten

[Sir Tikka Massala](Sir%20Tikka%20Massala%2018b60f7443dc8009b859d7a6196e9f7b.md)  und [Asmael Beri](Asmael%20Beri%2018b60f7443dc80a4808dc7acb459ec56.md)  sind sich nach 60 Jahren (letzte Mission mit [Schroppen](Schroppen%2018b60f7443dc80929c54f433e239914e.md) ) begegnet und haben sich als Verstärkung angeboten. Nach der Mission kann Asma Schroppen besuchen, weil die gute Freunde waren

Während Mission: Verbindung zu Harfnern muss geheim gehalten werden. (Harfner Symbol ist eine Harfe mit Mondsichel)-	Tikka Massala kommt den Zwergbrüdern näher, um eine besagte Lieferung zu begleiten und den Koboldüberfällen näher zu kommen (Kobold versteck ausfindig machen indem Kobold gefangen genommen wird)