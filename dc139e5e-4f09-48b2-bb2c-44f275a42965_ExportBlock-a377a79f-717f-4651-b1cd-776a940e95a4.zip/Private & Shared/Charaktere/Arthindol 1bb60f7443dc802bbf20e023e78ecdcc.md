# Arthindol

Erbauer des Turms am Alten Eulenbrunne

Drow

Author von Buch des Abscheulichen

Erzählt von Geschichten vor dem Krieg, wie mutige Helden und Zauberer in der Mine Monster gefangen hatten, die den Menschen nutzten. Unter anderem befand sich in der Mine eine Dybbuk-Box.