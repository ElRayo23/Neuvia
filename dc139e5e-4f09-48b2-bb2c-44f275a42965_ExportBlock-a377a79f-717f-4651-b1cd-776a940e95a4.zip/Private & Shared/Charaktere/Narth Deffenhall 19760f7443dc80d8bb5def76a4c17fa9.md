# Narth Deffenhall

![df35760dae0324bbc3136459653337dc.jpg](Narth%20Deffenhall/df35760dae0324bbc3136459653337dc.jpg)

- ein alter Bauer/Metzger: ,,Schwester Garaele, die sich um den
Schrein des Glücks kümmert, hat vor einigen Tagen die Stadt
verlassen und ist verwundet und erschöpft wiedergekommen."
- lebt mit seiner Enkelin [Molly](Molly%201ed60f7443dc8084a409ff66ad0b6d89.md)