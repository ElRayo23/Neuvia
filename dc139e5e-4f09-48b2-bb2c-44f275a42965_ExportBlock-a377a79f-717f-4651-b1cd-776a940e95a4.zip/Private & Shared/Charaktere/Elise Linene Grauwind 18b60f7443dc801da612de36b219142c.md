# Elise Linene Grauwind

![dbb0e26259be08278c14cb75a8260f91.jpg](Elise%20Linene%20Grauwind/dbb0e26259be08278c14cb75a8260f91.jpg)

- Löwenschild Händlerin
- Handelskompanie, liefern fertige Waren
- Posten leidet unter Banditenüberfälle
- Vater [Ylli Daran Edermath](Ylli%20Daran%20Edermath%2018b60f7443dc80379170da044143f492.md)
- aus Yartar im Osten 150km
- Ehemann führt den Handelsposten in Yartar weiter