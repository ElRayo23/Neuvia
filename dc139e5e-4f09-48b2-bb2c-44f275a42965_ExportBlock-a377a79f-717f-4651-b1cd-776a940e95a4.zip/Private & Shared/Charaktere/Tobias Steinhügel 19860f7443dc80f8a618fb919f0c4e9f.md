# Tobias Steinhügel

![3859a69f4d2336d6700a09292fe12628.jpg](Tobias%20Steinh%C3%BCgel/3859a69f4d2336d6700a09292fe12628.jpg)

Wirt der Steinhügelherberge

Mit Bar offen bis Mitternacht 

Mann von [Trilena Steinhügel](Trilena%20Steinh%C3%BCgel%201b360f7443dc80bea49fec4e0a777649.md)