# Parme Shan

![a603d82be517e9bf49c1b154416153ff.jpg](Parme%20Shan/a603d82be517e9bf49c1b154416153ff.jpg)

- Frau/Verlobte von [Cacio Pepe Wester](Cacio%20Pepe%20Wester%2018f60f7443dc80eaa331ebba6751128f.md)
- sekretärin von [Harbin Wester, Bürgermeister](Harbin%20Wester,%20B%C3%BCrgermeister%2018b60f7443dc80e880f7e4a1b96126a0.md) im [Stadtrat](https://app.notion.com/p/Stadtrat-1ed60f7443dc8061a0d9ea7a5b9f202f?pvs=21)
- Cousine von [Shan Tal](Shan%20Tal%201ae60f7443dc801b856fcf89953614a3.md)