# Breshka

- Frau von [Schroppen](Schroppen%2018b60f7443dc80929c54f433e239914e.md)
- Seele wurde entzogen, als sie auf [Lizznar](Lizznar%2018b60f7443dc80daadaaec0d82d7eb19.md) stoß, im Wald
- Geologin