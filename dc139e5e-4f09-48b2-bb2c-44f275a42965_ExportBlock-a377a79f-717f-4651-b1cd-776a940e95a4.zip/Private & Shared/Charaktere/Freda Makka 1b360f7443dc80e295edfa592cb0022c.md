# Freda Makka

![7c949bc8e45e4d8d54fa13df44934dc2.jpg](Freda%20Makka/7c949bc8e45e4d8d54fa13df44934dc2.jpg)

eine Holzarbeiterin: ,,Die Rotbrenner belästigen alle Geschäfte
in der Stadt, mit Ausnahme von Phandalins Bergarbeiterbörse.
Sie wollen keinen Ärger mit Halia Dornklafter, die sie leitet."