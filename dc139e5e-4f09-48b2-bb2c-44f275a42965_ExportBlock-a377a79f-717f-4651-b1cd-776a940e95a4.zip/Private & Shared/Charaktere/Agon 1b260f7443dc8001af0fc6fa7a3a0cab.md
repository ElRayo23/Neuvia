# Agon

Verkäufer, der von [Hoppi Gallopi](Hoppi%20Gallopi%2018b60f7443dc8048a61bc8ca74157095.md) bestohlen wurde