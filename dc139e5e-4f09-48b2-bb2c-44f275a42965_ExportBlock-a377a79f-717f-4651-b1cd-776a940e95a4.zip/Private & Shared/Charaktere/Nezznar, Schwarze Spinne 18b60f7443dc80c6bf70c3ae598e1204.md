# Nezznar, Schwarze Spinne

![f8d9fb1a9605055452b19c355e4ab809.jpg](Nezznar,%20Schwarze%20Spinne/f8d9fb1a9605055452b19c355e4ab809.jpg)

Vater von [Lizznar](Lizznar%2018b60f7443dc80daadaaec0d82d7eb19.md), will durch magische Schmiede einen Körper für seinen Sohn formen

ehemaliger Kleriker der Matrone
→ wurde von seinem Volk gespottet