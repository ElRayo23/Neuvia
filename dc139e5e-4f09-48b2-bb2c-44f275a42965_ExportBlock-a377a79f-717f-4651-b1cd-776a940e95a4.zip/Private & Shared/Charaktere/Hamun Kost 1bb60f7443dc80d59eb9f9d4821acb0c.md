# Hamun Kost

Nekromant im alten Eulenbrunnen

nicht aggressiv

sucht nach dem Erbauer des Turms, um ihn zu recherchieren

neugierig, hält Nekromantie für Werkzeug