# Harbin Wester, Bürgermeister

feiger Bürgermeister, italian

ehem. Arbeitgeber von Flora Gwi

Vater von [Cacio Pepe Wester](Cacio%20Pepe%20Wester%2018f60f7443dc80eaa331ebba6751128f.md) 

[Stadtrat](https://app.notion.com/p/Stadtrat-1ed60f7443dc8061a0d9ea7a5b9f202f?pvs=21) 

![a7e0f994b860105bc62c4d201cfbf790.jpg](Harbin%20Wester,%20B%C3%BCrgermeister/a7e0f994b860105bc62c4d201cfbf790.jpg)

Kriegt Schweigegeld von [Iarno Albrek Glasstab](Iarno%20Albrek%20Glasstab%2018b60f7443dc8071b260c08555bc3073.md) 

Schublade im Tisch: 450 Gold, Lagebericht von Phandalin, Snitch Brief wegen Truppe