# Trilena Steinhügel

![8efbf04ed8967e064657f620e3a50631.jpg](Trilena%20Steinh%C3%BCgel/8efbf04ed8967e064657f620e3a50631.jpg)

die Frau des Wirts: ,,Thel Dendrar, ein örtlicher
Schnitzer, hat sich vor einem Zehntag mit den Rotbrennern
angelegt, als sie in seinen Laden gekommen sind und seine
Frau lüstern angeschaut haben. Die Schläger haben ihn
umgebracht. Mehrere Stadtbewohner haben es gesehen. Die
Rotbrenner haben sich seine Leiche geschnappt, und jetzt sind
seine Frau, seine Tochter und sein Sohn auch verschwunden."

Frau von [Tobias Steinhügel](Tobias%20Steinh%C3%BCgel%2019860f7443dc80f8a618fb919f0c4e9f.md) 

Mutter von Pip