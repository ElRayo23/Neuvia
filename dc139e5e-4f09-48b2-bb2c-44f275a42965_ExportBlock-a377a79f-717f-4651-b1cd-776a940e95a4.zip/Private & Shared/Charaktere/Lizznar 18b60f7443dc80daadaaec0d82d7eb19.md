# Lizznar

![b11b57d361910ba0f26e0153946bba21.jpg](Lizznar/b11b57d361910ba0f26e0153946bba21.jpg)

Sohn von [Nezznar, Schwarze Spinne](Nezznar,%20Schwarze%20Spinne%2018b60f7443dc80c6bf70c3ae598e1204.md) 

In Wahrheit aber ein namenloser Dämon Loumara von der Sorte Dybbuk, der Nezznar manipuliert. Lizznar hat in der Höhle gespielt und Dämon freigesetzt → Fleisch zerfressen und besessen

sucht perfekten Körper, um zu “genießen”

Nezznar hört und sieht den gestaltlosen Geist seines “Sohnes” und die Schmiede kann einen neuen Körper erschaffen

Telepathie 120 ft

immun zu Elektrizität, acid, fire and resistant to cold

[https://5e.tools/bestiary/dybbuk-mtf.html](https://5e.tools/bestiary/dybbuk-mtf.html)