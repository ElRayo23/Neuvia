# Elsa Mautherb

![dfwe3g4-3a5c4f6d-4641-4e53-9747-9f84b9ea1278.png](Elsa%20Mautherb/dfwe3g4-3a5c4f6d-4641-4e53-9747-9f84b9ea1278.png)

eine geschwätzige Barmaid: ,,Daran Edermath,
der Obstbauer, ist ein ehemaliger Abenteurer."